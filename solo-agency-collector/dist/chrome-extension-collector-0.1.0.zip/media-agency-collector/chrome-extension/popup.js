const fields = [
  "enabled",
  "bridgeBaseUrl",
  "pollMinutes",
  "minDelaySeconds",
  "maxDelaySeconds",
  "maxSourcesPerRun",
  "closeTabsAfterCollect"
];

document.addEventListener("DOMContentLoaded", async () => {
  await refresh();
  document.getElementById("save").addEventListener("click", save);
  document.getElementById("checkNow").addEventListener("click", checkNow);
});

async function refresh() {
  const response = await sendMessage({ type: "get_state" });
  if (!response.ok) {
    setStatus(`Error: ${response.error || "Unable to load state."}`);
    return;
  }
  fillSettings(response.settings || {});
  renderState(response.state || {});
}

async function save() {
  const settings = readSettings();
  const response = await sendMessage({ type: "save_settings", settings });
  if (!response.ok) {
    setStatus(`Save failed: ${response.error || "unknown error"}`);
    return;
  }
  await refresh();
}

async function checkNow() {
  setStatus("Checking local bridge...");
  const response = await sendMessage({ type: "check_now" });
  if (!response.ok) {
    setStatus(`Check failed: ${response.error || "unknown error"}`);
    return;
  }
  await refresh();
}

function fillSettings(settings) {
  for (const field of fields) {
    const el = document.getElementById(field);
    if (!el) continue;
    if (el.type === "checkbox") {
      el.checked = Boolean(settings[field]);
    } else if (settings[field] !== undefined) {
      el.value = settings[field];
    }
  }
}

function readSettings() {
  return {
    enabled: document.getElementById("enabled").checked,
    bridgeBaseUrl: document.getElementById("bridgeBaseUrl").value.trim(),
    pollMinutes: Number(document.getElementById("pollMinutes").value),
    minDelaySeconds: Number(document.getElementById("minDelaySeconds").value),
    maxDelaySeconds: Number(document.getElementById("maxDelaySeconds").value),
    maxSourcesPerRun: Number(document.getElementById("maxSourcesPerRun").value),
    closeTabsAfterCollect: document.getElementById("closeTabsAfterCollect").checked
  };
}

function renderState(state) {
  const lines = [
    `Status: ${state.status || "unknown"}`,
    `Message: ${state.message || ""}`,
    state.runId ? `Run: ${state.runId}` : "",
    state.currentSource ? `Current source: ${state.currentSource}` : "",
    state.updatedAt ? `Updated: ${state.updatedAt}` : ""
  ].filter(Boolean);
  setStatus(lines.join("\n"));
}

function setStatus(text) {
  document.getElementById("status").textContent = text;
}

function sendMessage(message) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(message, (response) => {
      const err = chrome.runtime.lastError;
      if (err) {
        resolve({ ok: false, error: err.message });
      } else {
        resolve(response || { ok: false, error: "empty response" });
      }
    });
  });
}

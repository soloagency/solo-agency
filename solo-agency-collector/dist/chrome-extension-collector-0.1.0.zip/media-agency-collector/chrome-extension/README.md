# Chrome Extension Collector

This is the Chrome Extension MV3 collector for the Media Agency Local Collector.

The user installs it once in the Chrome profile that is already logged in to Facebook, LinkedIn, Reddit, Instagram, TikTok, or other private sources they want monitored.

## What It Does

- Polls `http://127.0.0.1:17321/status`.
- Fetches the current local job from the bridge.
- Opens configured source URLs using the user's existing Chrome session.
- Waits between actions using conservative pacing.
- Reads visible text, URLs, page title, engagement hints, profile URL candidates, and post/current URL candidates.
- Sends structured data back to the local bridge.

## What It Does Not Do

- It does not ask for passwords.
- It does not read cookies directly.
- It does not upload data to cloud services.
- It does not post, comment, react, message, follow, or change account state.
- It does not bypass platform access controls.

## Install For Development

1. Open Chrome.
2. Go to `chrome://extensions`.
3. Enable Developer Mode.
4. Click `Load unpacked`.
5. Select `media-agency-collector/chrome-extension`.

For public release, publish the extension through Chrome Web Store or provide a signed/internal extension package.

## Expected Flow

1. AI agent starts the local bridge.
2. Extension detects the bridge.
3. Extension collects the bridge job.
4. Extension posts results to the bridge.
5. Bridge writes local files.
6. AI agent reads the local files and continues the playbook workflow.

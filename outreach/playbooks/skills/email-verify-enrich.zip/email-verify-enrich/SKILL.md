---
name: outreachcrm-email-verify-enrich
description: >-
  Use during a daily run's enrich step (Stage 4) to VERIFY a contact is still active and
  ENRICH them into a write-ready lead for a deeply personalized cold email. Two tiers: a cheap
  verify pass (still in the business? gather profile URLs) then a proof-of-life pass — gather as
  MANY evidenced public-professional signals as you can find (recent activity, reputation,
  positioning, scale — each with a source URL), never capping at one or three. Writes the dossier
  via tool crm-store. Never guesses an email address, never mines personal life. Loaded after
  Stage 4 / from the daily run's "load new pipeline -> enrich" step.
---

# Email Verify & Enrich (Stage 4 skill)

This is an INDEX. Load the module you need when you reach its step:
`channel_reality.md` (what is actually readable, per source) and `etiquette.md` (what is fair
game vs off-limits). The dossier schema and storage are Stage 7 + `tool crm-store`.

## Hard gates

- **Every usable hook needs an `evidence_url`.** A detail with no source is dropped — Stage 6
  may not write it, and Stage 9 greps for it. `tool crm-store enrich write` enforces this.
- **No guessing.** Never fabricate an email address. If you find a real address (on a website,
  a license record, a roster) store it as a found identity (`source: enrich`). If you find
  none, mark `mark_email_not_found` — do not invent a `first.last@domain` guess (MVP decision).
- **No personal-life mining (anti-creepy stance).** Collect ONLY public, professional signals —
  the dossier feeds a writer who is a dedicated peer that did their homework before a professional
  approach, NOT a surveillant. `public_business` signals only (listings, work posts, reviews,
  awards, market views). Family/health/vacation/children → `sensitivity: personal`, which goes to
  `do_not_mention`, never to email copy. Gather MANY public-professional points, but never a
  dated, itemized log of someone's life — that is exactly what reads as scraped. See `etiquette.md`.
- **Read-only.** Use WebSearch / WebFetch (and a browser tool only where the readability table
  says so). Do not log into anyone's account. Facebook/LinkedIn logged-out = store the URL only
  (Phase 4 Local Collector reads those later).
- **Inherit, don't re-burn.** The dossier belongs to the CONTACT and is reused across that
  client's campaigns. Check `tool crm-store enrich status` first; only enrich/refresh when it says
  so. A `no_verifiable_hook` / `email_not_found` negative cache is inherited — respect its window.

## The Write-Ready gate (3 layers + floor)

Everything below serves ONE target: make each lead **write-ready**. A lead is write-ready for a
deeply personalized message only when it has all three layers (DESIGN §9):

- **Layer A — Reachability (≥1 required):** at least one deliverable channel — a real found email
  (→ email), or a DM-capable social profile / phone (→ messenger/assisted). This is
  `identity.channels_found` + `identity.profiles`.
- **Layer B — Proof-of-Life (≥1 required; MORE IS BETTER — do NOT cap):** evidenced, recent public
  PROFESSIONAL signals — the personalization fuel. Each point is one basis for a conclusion the
  writer weaves. The taxonomy is universal and industry-AGNOSTIC; INFER which sources fit the
  lead's field — never work from a hardcoded per-industry list:
  1. **Recent activity/output** (strongest — proves alive AND gives a hook): a new post / video /
     article / release / listing / project / menu, etc.
  2. **Reputation / social proof:** review count + substance, ratings, testimonials, awards, press,
     verified badge, follower / engagement figures.
  3. **Positioning / identity:** website tagline, bio, "since 20xx", stated specialty / mission.
  4. **Scale / momentum:** volume figures, team / locations, growth story, price range.

  (Those four are the taxonomy, not a source list. Prefer #1/#2 with a recent `observed_date`;
  #3/#4 support the reframe.)
- **Layer C — The Opening (NOT collected here):** the specific gap the campaign's offer resolves.
  The WRITER derives it at write time from Layer B + the offer. Do not try to produce it in the
  dossier; your job is to make Layers A+B rich enough that the writer can.

**The floor.** ≥1 Layer-B point → **write-ready** (deep personalization); the COUNT + quality of
Layer-B points scales `personalization_confidence` (one thin point → review-carefully; ≥3 solid,
fresh, on-goal → high). Springboard exhausted and still 0 Layer-B → **NOT write-ready** →
`mark_no_hook` and let `no_hook_fallback` decide. Layer A fails (no channel) → assisted or skip.
"Use what you have" applies to the CHANNEL and the degraded path — the personalization floor stays
≥1 Layer-B.

**Seed normalization — resolve a REAL identity before the first search.** A search query is built
from a real person/business, NEVER from a URL. **Content-clue seeds come first:** when the lead's
only data is a CONTENT link (`identities.seeds[]` — a reel/video/post/blog URL, status
`unresolved`), identify the AUTHOR. **Read the owner out of the URL FIRST — only open the page when
the URL does not carry it:**

| Seed URL shape | Owner | How |
|---|---|---|
| `/<vanity>/posts/…` | `facebook.com/<vanity>` | **from the URL** — no collector call |
| `/<numeric-id>/posts/…` | `facebook.com/<numeric-id>` | **from the URL** |
| `permalink.php?…&id=<numeric>` · `story.php?…&id=<numeric>` (incl. `m.facebook.com`) | `facebook.com/profile.php?id=<numeric>` | **from the URL** |
| `/reel/<id>` | — | **Local Collector** (the URL has no owner) |
| `/groups/<g>/permalink/…` | — | Local Collector (poster is not in the URL) |

Measured on 19 real seeds: URL-derived owners were right **11/11**, while the collector's DOM
`profile_candidates` on those same post pages was wrong **7/7** (it returned unrelated profiles and
even GROUP urls — e.g. a `fcglawfirm` post resolved to `groups/1722262131424406`), and 4 of the post
pages timed out at 240s. So for posts/permalinks/stories: **parse the URL, do NOT spend a collector
call.** For a `/reel/<id>` the collector IS required and IS reliable (verified 8/8, `url_drifted:false`,
owner taken from the on-page "See Owner"/`sk=reels_tab` link) — never take a reel owner from
`profile_candidates[0]` blindly; prefer the `reels_tab` link and reject any record whose
`url_drifted` is true.

For non-Facebook content (YouTube/TikTok/blogs) open the content in the browser and read the
byline/channel/handle, which links to the profile.
**A content seed IS hook material.** When the lead came from a reel/post the operator saved, that
content is the reason they chose this person: open it, confirm the owner and `url_drifted:false`,
and record the professional detail as a hook whose `evidence_url` IS the seed url. Do not go hunting
a fresh hook while the curated one is unread — `enrich write` flags it and the lead comes back as
`seed_hook_unharvested`, never as a skip.
Record the found profile in `identity.channels_found.profiles` (the store writes it back as a
canonical `identities.socials` entry and marks the seed `resolved`), then continue below as a
profile-seeded lead. **Do not stop at the owner URL.** The reel/post page holds the content and the
owner link and nothing else, so a pass that ends there reports `contacts.emails: []` even when the
address is one click away (`facebook.com/sample.lead` hides `sample.lead@example.com` behind "See more"
in About; `facebook.com/sample.business` prints `info@example.com` in its contact-info block). Open, in order, stopping at
the first hit: **(1)** the profile itself with the bio expanded via "See more", **(2)**
`…/directory_contact_info`, **(3)** `…/directory_intro`, **(4)** `…/directory_basic_info`, **(5)**
`…/directory_links` (no address, but the website is here), **(6)** that website's Contact/Team/About
page and footer, **(7)** the off-platform ladder. About is a CHOOSER, not a page — each sub-page is
its own URL, and rows 1-5 are where a business address almost always is; the website hop is the
exception, not the routine next step. **Rows 1-5 come out of the SAME `fb.profile.enrich` job that
returns the hooks — one page load per profile, never a second:** enqueue `fb.profile.enrich`
against the PROFILE ROOT url (vanity or `profile.php?id=<numeric>`, never `/about`) and it reads
the timeline first, then enters About in the same tab, CLICKING each sub-tab (a fetch of those
returns the app shell with no contact block) and expanding "See more". Copy the contact half of
its record into the dossier as `email_discovery` `{profile_url, emails, websites, found_on,
checked}`, and put any address it found into `identity.channels_found.emails` too — that is the
field that creates the identity. Rows 6-7 stay separate steps, input from `websites`. `enrich
write` refuses `mark_email_not_found` unless `email_discovery.checked` shows the ladder got past
`current_page` (a `directory_*` sub-tab rendered, or `about` with no sub-tab offered — the normal
case for a personal profile). Full contract: `solo-agency-collector/EMAIL_DISCOVERY.md`. Enqueuing
`fb.profile.contacts` after an enrich pass on the same profile is a defect, always: it reads the
same surfaces the enrich record already covered, so an empty `emails` there means Facebook has no
published address — the next and only step is the website (rows 6-7), never a second profile job. **Batch-resolve first on reel-heavy lists:** resolve EVERY unresolved seed
to its owner profile before any deep enrichment — the store auto-consolidates fragments that
share a profile/email (full union: all reels + hooks kept; result reports `consolidated`), so
you deep-enrich each unique person exactly ONCE. Always continue against the returned `lead_id`
(the survivor). A `duplicate_suspected` result means a CONFLICTING record shares that identity
(shared page ≠ same person) — not merged, both held out of queues; surface it to the operator
instead of picking a side yourself. If the only seed is a Facebook/social URL (or the CRM
`name` is blank), FIRST read the profile with the Local Collector's `fb.profile.enrich` — the Phase-4
collector is now LIVE (operator's own logged-in Chrome; bridge `127.0.0.1:17321`, enqueue capability
`fb.profile.enrich` with the profile ROOT URL; see `solo-agency-collector`). Take its `name` + `category`
+ a location signal (city from the header/intro) and build the first query as `"<name>" <category>
<city>`. **Do NOT build a query from a URL path/slug** (e.g. `absellsaz`, or "videos/reels insurance
agent" stitched from URL words) — slug queries return directory junk, not the person. If the header
yields no usable name, pull the person's own words + place-names from the SAME record's `posts[]`
captions (posts and reels are mixed there) before ever falling back to a slug — no second job.
Pass a `profile.php` URL only WITH its `?id=<numeric_id>` — a bare `profile.php` resolves to the
operator, not the lead.

**Running the Facebook people-search — search BROAD, then FILTER. GraphQL only, never the DOM scan.**
Run it through the Local Collector's **`fb.people.search`** capability (source
`capability:"fb.people.search"`). Two rules decide whether this works at all:

1. **The query is the NAME ONLY (2–3 tokens).** Facebook ANDs every token, so a
   name+company+city+state+industry query matches NOBODY. Measured on 89 real searches: 1–3-token
   queries returned results **87%** of the time; **6+ token queries returned 0/56**. Same lead, same
   minute: `Robin Hayes Insurance Kenai AK` → 0 results;
   `Robin Hayes` → 36 results including her. Never paste the CRM's
   company/city/state/industry into the FB query.
   **Ladder** (stop at the first rung that returns records): `First Middle Last` →
   `First Last` (drop the middle name) → `First Last <state>` (only if the name is very common).
   A rung returning `records: null` means that phrasing matched nobody — go to the next rung.
   Exhausted the ladder → genuine no-result; do NOT fabricate and do NOT fall back to the DOM.
2. **Company / city / state are FILTERS, not query tokens.** Pick the right person by matching them
   against each candidate's `name` + `subtitle` in **`records.items`** (`ProfileSummary[]`): accept a
   candidate whose name matches the lead AND whose subtitle corroborates employer, city/region, or
   trade. A name-only match with nothing corroborating is NOT an identity — leave it unresolved
   rather than enrich the wrong person.

Take candidates ONLY from **`records.items`**. **NEVER** use `entity_candidates` /
`new_private_sources` (the DOM scan) — with a Messenger chat open it captures the OPERATOR'S OWN chat
contact as a candidate (one wrong "Bob Nguyen" polluted 32 searches). Never accept a DOM candidate.
(See `channel_reality.md`.)

**The springboard (industry-agnostic, iterative).** From ANY seed — a name, an email, a single URL
— pivot to find the rest and loop until returns diminish: social → website (email + tagline) →
industry / directory page (volume, reviews) → reverse search (email / name → other profiles).
REASON about which sources fit the lead's trade; there is no fixed per-industry list. Keep digging
until Layers A+B are satisfied, then stop.

## The two-tier flow

Run over the leads `tool crm-store enrich due --campaign <slug>` returns.

**Tier 1 — Verify + reachability (cheap).** Confirm the person is still active and collect profile
URLs + any real channel (Layer A). Run the springboard from the seed — these sources are
ILLUSTRATIVE of a real-estate lead, so GENERALIZE them to the lead's actual field rather than
treating them as a fixed list: official license/registry lookup → brokerage/employer roster (email
domain is a hint) → Zillow/realtor.com search snippet → Google Business Profile → the person's own
website (email + tagline). For a different trade you would infer the equivalents (a chef → the
restaurant site + reservation/review platforms; a consultant → their site + LinkedIn URL +
directory listings). If the person is clearly inactive/left the field, set `still_active: inactive`
and STOP — do not run Tier 2 (don't spend the proof-of-life pass on a dead lead).

**Who runs Tier 1.** Tier 1 is lookup and extraction, not judgement, so the mapped extractor tier—Luna on Codex—is its
sub-agent (`playbooks/TEAM_MODEL.md`, brain tiers): one lead — or a small batch —
per sub-agent, fresh context, brief = the seed plus the
springboard paragraph above, output = a file `enrich/tier1/{lead_id}.json` holding
`{profile_urls[], channels[], still_active, evidence[]}` and nothing else — never back through the
chat. The main flow (Team Leader or the campaign Daily Run) reads that file, decides
`still_active`, and runs Tier 2 itself, because Tier 2 is judgement and it ends in `enrich write`,
which only the main flow performs. On Codex, each failed Luna batch may receive at most one Terra retry recorded with the canonical Stage 7 schema in
`daily-content-pipeline/automation/model_routing_log.jsonl`; other runtimes use their mapped next tier. Never run Tier 1 inline in the leader. If
no low-tier agent is available, stop `low_tier_subagent_unavailable`. For more than five leads, or an unknown/unbounded collection that must be exhausted,
run a five-lead extractor canary before batches of at most 40.

**Tier 2 — Profile & proof-of-life (hooks).** Visit the URLs Tier 1 found (see `channel_reality.md`
for what each actually yields) and **gather as MANY evidenced Layer-B proof-of-life points as you
can find — do NOT cap at one or three.** Each point is a conclusion-basis the writer will weave, so
more solid, fresh, on-goal points = a richer message and a higher `personalization_confidence`;
there is no upside to stopping early. **Record the profile's NAME while you are there.** Set
`identity.name` to the name the profile actually shows, `identity.entity_type` to
`person|company|page`, and for a person `identity.name_given` to the single word a greeting uses
(Vietnamese: the LAST word of "Nguyễn Văn An" is "An"; English: the first word of "Charlie Bui" is
"Charlie" — code cannot know the order, you can). This is what stops the CRM showing `c_...` and
what lets a writer greet properly. **Never copy a page's tagline or bio into `name`** — the header
element often holds "Mortgage Broker based in DFW servicing all of Texas" or "🌿 Dược sĩ Diễm Phúc";
`enrich write` refuses those with a reason, and a wrong value would appear as the reader's name in
a real greeting. If the page name embeds a person ("Sống khoẻ cùng Liêm"), the name is the page
name and `name_given` is the person ("Liêm"). `current_company` is the EMPLOYER, never a restatement
of `name`. **Write `summary` in the CONTENT's own language, quoting its
distinctive phrase** (a Vietnamese post gets a Vietnamese summary carrying e.g. "hồ sơ di trú", not
an English paraphrase): the summary is what the draft gate matches against the email body, and an
email in the recipient's language can never overlap a paraphrase in another one — a translated
summary gets a genuinely woven draft refused as `hook_not_woven`. Record each with `type`, `summary`, `evidence_url`,
`observed_date`, `confidence`, and `analysis` where `analysis.sensitivity` gates copy eligibility
and **`analysis.angle` is the conclusion that hook supports** (the implication the writer can draw
from it, e.g. a share count → "people are already passing your version along"). **Always set
`observed_date`** — a usable hook missing it is kept but `enrich write` flags a `problems` note
(recency unverified), and recency is what makes proof-of-life real. **Social BEFORE website, and
reading BEFORE claiming:** a website is a background/confirmation source that goes stale; any lead
with a Facebook profile MUST have it read — ONE `fb.profile.enrich` job on the ROOT url, whose
`posts[]` holds the 3–5 latest posts and reels mixed, each dated with its own permalink — analyzing
them for DATED signals, before that lead can be `high`. Never enqueue `fb.profile.videos` for the
reels: they are already in `posts[]`, and a second job is a second load of the same profile. Saving the profile URL without reading it, or resting on a `website_update`
line, is not proof-of-life — `enrich write` will cap the band and tell you so. `observed_date` is
the CONTENT's publish/update date, never the date you read it. Distill a `writing_brief`: a one-liner, ranked angles (freshness × goal-fit ×
confidence), a `do_not_mention` list, and a `personalization_confidence` set by the **COUNT +
freshness + goal-fit** of the Layer-B points (drives the band: ≥0.7 high, 0.4–0.7 review_carefully,
<0.4 fallback). Selecting which points to actually use is the WRITER's job, not yours — your job is
to find and evidence as many as exist.

## Freshness at write time

Before drafting **step 1**, hooks must be within TTL (`enrich status` handles this). For
**follow-ups** (Stage 10) you do NOT re-enrich per bump: the entry enrichment already gathered
many points, the writer reserves the secondary ones across the sequence, and the campaign's
`message_bank` carries the rotation. A **micro-refresh is opportunistic only** — run it when the
reserved points are used up AND the collector has spare capacity (gated by the send budget); if it
runs, re-run `enrich write` with the refreshed hooks. What stays mandatory for every bump is the
**stale-hook guard**: a time-sensitive hook past TTL is re-verified (that one known URL) or not
referenced (a listing that sold must not be referenced as active).

## Writing the dossier

```sh
<bridge> tool crm-store --client-dir DIR enrich write --contact <lead_id> --campaign <slug> --json '<dossier>'
```

Dossier shape (DESIGN §9.2):
```json
{"identity":{"still_active":"confirmed|inactive|unknown","current_company":"","role":"",
   "profiles":{"zillow":"","website":"","facebook":"","instagram":"","gbp":""},
   "evidence":[{"fact":"","url":"","retrieved_at":""}],
   "channels_found":{"emails":["only REAL found addresses"],"phones":[]}},
 "context":{"market":"","volume_signals":"","specialty":"","content_style":""},
 "hooks":[{"type":"new_listing|social_post|review|award|market_view|website_update",
   "summary":"","analysis":{"topic":"","angle":"","sensitivity":"public_business|personal"},
   "evidence_url":"https://...","observed_date":"YYYY-MM-DD","confidence":0.0}],
 "writing_brief":{"one_liner":"","ranked_angles":[],"do_not_mention":[],"personalization_confidence":0.0},
 "mark_email_not_found": false, "mark_no_hook": false}
```
`hooks[]` is **not capped** — record every evidenced Layer-B point you found, not a curated top few.
`enrich write` stores the full dossier under `campaigns/{slug}/queue/enriched/YYYY-MM-DD/` and a
distilled copy into `contact.enrichment` (inherited by other campaigns). It returns
`usable_hooks`, `confidence_band`, and any `problems` (e.g. a hook it dropped for missing evidence).

## No-hook branch

This is the **floor failing**: the springboard is exhausted and you have **0 Layer-B proof-of-life
points**. (Realistic hit-rate for a deeply-personalized hook is ~30–50%; see `channel_reality.md`.)
Then set `mark_no_hook: true` and let the campaign's `no_hook_fallback` decide: the default `skip`
(a hookless step-1 draft is rejected by `draft write` — evidenced proof-of-life is the reason an
email exists), or the explicit opt-in `generic_honest_opener` (a generic-but-honest opener grounded
only in license/roster facts). Do not pad a thin dossier with unsourced guesses, and do not lower
the floor: **one** evidenced Layer-B point already clears it, so only mark no-hook when there is
genuinely zero.

## No-email branch (email discovery)

A lead an `email_first` campaign queued with no email is here so you can FIND one — check the
website, a license/registry record, a brokerage roster, Google, other public channels. Store any
real address as a found identity (`source: enrich`). If discovery genuinely fails, set
`mark_email_not_found: true` — this writes a 30-day negative cache so a later campaign does not
re-burn the same dead end, and the contact becomes an **assisted-channel candidate** (manual
SMS/Messenger/Zalo). Never fabricate a `first.last@domain` guess.

When any file disagrees with `docs/DESIGN.md`, `docs/DESIGN.md` wins.

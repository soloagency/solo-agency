# Channel reality — what is actually readable (MVP)

Be honest about what a stdlib agent with WebSearch/WebFetch (and a browser tool where noted) can
truly read. Promising a hook from a source you cannot read produces an embarrassing "personalized"
email (a months-old listing, a wrong person). Per hook type, use the reachable source + a fallback.

| Source | Readable now? | How | Notes |
|---|---|---|---|
| Personal website / blog | ✅ full | WebFetch | Best source for a real, current hook. |
| YouTube | ✅ title/description | WebFetch/WebSearch | |
| Instagram / X (public) | ⚠️ best-effort | WebSearch snippet; WebFetch often walled | Store URL if unreadable. |
| Zillow agent profile / agent directory | ✅ via Local Collector | **`zillow.profile.enrich`** on `zillow.com/profile/<screenName>` — ONE record shaped like `fb.profile.enrich`: `name`, `emails[]` (when the agent published one), `phones[]`, `website` + `zillow.socials`, `location[]` (brokerage address), `about_lines[]` (brokerage, licence, years, specialties, service areas, sales stats), `posts[]` = dated reviews + closed sales, `industry:"Real Estate"`, `zillow.team.members[]` on a team profile. Directory pages via **`zillow.agents.list`** (one page per job, caller owns `?name=&page=`). | Contract: `solo-agency-collector/ZILLOW_CAPABILITIES.md`. Read from the operator's logged-in Chrome; Zillow's "Press & Hold" bot check is waited out by the collector (chime → operator passes it → job continues) — never solved by code. Reviews and sales carry real dates, so a "recent sale/review" hook is safe to claim from this record. |
| Zillow / realtor.com listings (as evidence) | ⚠️ snippet mainly | WebSearch snippet; direct fetch often bot-blocked | A "new listing" hook needs a **date in the snippet** — a dateless snippet may be months old; don't claim "just listed". For an AGENT the profile row above is the reliable source. |
| Google Business Profile reviews | ⚠️ JS-rendered | browser tool (Claude in Chrome), not WebFetch | A recent review is a strong hook when you can read it. |
| State license / registry | ⚠️ varies | WebFetch for GET pages; browser tool for ASP.NET/POST forms | Proves "still active"; some states expose a public email. |
| Brokerage roster (e.g. kw.com) | ⚠️ SPA | often an empty shell on WebFetch → browser tool | Presence on the roster ⇒ still there; email domain is a hint, not a guess. |
| Facebook profile (whole lead) | ✅ via Local Collector | **`fb.profile.enrich`** on the ROOT url — ONE record: name/category/header, About section (`about_lines`, `work[]`, `emails`, `websites`, `checked`) AND `posts[]` (posts + reels mixed, dated, permalinks) | Collector is LIVE (operator's logged-in Chrome, `127.0.0.1:17321`). ONE job per profile, never a second load: read the name FIRST from this record, THEN search — never from the URL slug. Submit the ROOT url, never `/about` (timeline only fires on the root). Bare `profile.php` (no `?id=`) resolves to the operator, not the lead. Legacy `fb.profile.header` / `fb.profile.contacts` / `fb.profile.videos` are NOT part of enrichment any more; `fb.profile.posts` (deep pagination) is for monitoring a page over time. |
| Facebook people-search | ✅ via Local Collector (GraphQL) | `fb.people.search` → read **`records.items`** (`ProfileSummary[]`); source `capability:"fb.people.search"`, `inputs.query` = **THE NAME ONLY** | **Query = name only (2–3 tokens).** Facebook ANDs every token, so appending company/city/state/industry matches NOBODY — measured: 1–3-token queries returned results 87% of the time, 6+ token queries **0/56**. The same lead found 0 as `Robin Hayes Insurance Kenai AK` and 36 (incl. herself) as `Robin Hayes`. Use company/city/state to **FILTER `records.items`** (match `subtitle`), never to narrow the query. Take candidates ONLY from `records.items`; **NEVER** `entity_candidates`/`new_private_sources` (DOM — leaks the operator's open Messenger contact; one "Bob Nguyen" polluted 32 searches). `records` null = that query matched nobody → try the next rung of the ladder, then no-result. Never accept a DOM candidate. |
| Facebook post/permalink → OWNER | ✅ from the URL (no fetch) | parse the URL: `/<vanity>/posts/…`, `/<numeric>/posts/…`, `permalink.php`/`story.php?…&id=<numeric>` | **Do NOT call the collector for these.** Measured 19 seeds: URL-derived owner 11/11 correct; the collector's DOM `profile_candidates` on the same post pages 7/7 WRONG (unrelated profiles, even group URLs) and 4 pages timed out at 240s. |
| Facebook reel → OWNER | ✅ via Local Collector | open `/reel/<id>`, take the `sk=reels_tab` "See Owner" link | The reel URL carries no owner, so the collector IS needed here — and is reliable (8/8 verified, `url_drifted:false`). Reject any record with `url_drifted: true`; don't trust `profile_candidates[0]` blindly, prefer the `reels_tab` link. |
| LinkedIn | ❌ logged-out wall | store the URL only | Career-change hooks live here but are unreadable now. |

## Consequences to encode

- Realistically only **personal websites + occasional dated snippets + readable reviews** yield a
  verifiable fresh hook, so plan for a **~30–50% deep-personalization hit-rate**, not 100%. The
  campaign's volume assumptions and the `no_hook_fallback` exist because of this. (That rate is for
  Layer-B **recent activity** (#1); **reputation / positioning / scale** signals (#2–#4) are more
  often readable from the site/snippet/reviews and also clear the ≥1 Layer-B floor — so a lead is
  usually write-ready even when the freshest post is walled.)
- A source marked ❌ here must **never** produce a hook — store the profile URL for later and move
  on. Do not paraphrase a search snippet's guess about a Facebook post as if you read it.
- **Facebook candidates come from GraphQL `records.items` ONLY, never the DOM `entity_candidates`.**
  The DOM entity/candidate scan reads the whole logged-in page, so an open Messenger chat, a "People
  you may know" rail, or a suggested-friends widget leaks the operator's own contacts in as "leads".
  Trust `records` (the typed capability output); if it is null, the search failed — retry or record
  no-result, never fall back to the DOM list.
- When a source needs a browser tool and none is available in the run, record it as unreadable
  this pass (it may become a hook on a later refresh), not a fabricated hook.

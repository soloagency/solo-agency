# 30 · Overlay core — author ANY overlay through the internal vector model (threshold, standard, reuse-photo, apply & verify)

_Version: `modular-1.1` · module of the AI Video Editor Playbook (`SKILL.md`)._

> **⚠ SCOPE (2026 lean model): load this ONLY to fix a proven exceptional overlay defect.** WideCast produces deterministic overlays and guarantees rendering/placement. The agent does not author or visually proofread overlays as a routine gate. Source-copy errors are fixed in authoritative `text`; deterministic output is confirmed through integrity/provenance data. Use the authoring recipes below only when Gate 4 has an unverified exceptional source or a genuine rebuild is otherwise authorized.

> **Module of the AI Video Editor Playbook.** Master index + checklist + critical rules live in `SKILL.md`. **Load this when:** you are going to (re)build or apply ANY overlay. ALWAYS load this first; if the overlay contains any text/title/label/value, load `31_typography.md` too even when the main pattern is a chart/diagram; then load the per-content style guide (`32_charts.md` for charts/diagrams, `33_patterns.md` for the rest).
> Cross-refs: text look→`31_typography.md`+`styles/text_axes.md`; chart/diagram→`32_charts.md`+`styles/chart_axes.md`; other patterns→`33_patterns.md`.

---

> **⭐ LOAD CHAIN — this file is step 1 of TWO–FOUR for any overlay. Before you author, you MUST also `Read`:**
> - **`10_mechanics.md` when `show_narrator=true` / `active_roll="A"`** — A-roll overlay authoring must run the full-canvas-first priority ladder in Gate 4 before the agent accepts, rebuilds, uploads, or layout-fixes the overlay. This is where the narrator/overlay tradeoff is designed; Gate 6 only verifies.
> - **`40_thumbnail_cta.md` when this overlay belongs to the first real scene/opening poster, the immediate thumbnail sync, or the last content/CTA scene.** Endpoint scenes have poster/CTA standards that override normal pattern instincts: choose a named endpoint style and avoid generic centered cards, horizontal text bars, and plain title/subtitle panels.
> - **`styles/design_languages.md` when authoring/rebuilding is actually needed OR when handling an endpoint scene** — a compact style direction layer. Endpoint overlays need a design language even when approving/applying an existing or synced poster. It never overrides the Universal Overlay Design Standard or the preserve gate; it only decides surface, shape, palette, title treatment, density, and decoration.
> - **`31_typography.md` whenever the overlay contains ANY text/title/label/value** (almost every overlay, including charts/diagrams). This is the hero/title/readability standard; skipping it is how dark/muddy/tiny text slips through.
> - the **content module** for the scene's pattern — `31_typography.md` (text-led) · `32_charts.md` (`single_metric`/`bar_chart`/`proportion_chart`/`trend_chart`/`structural_diagram`) · `33_patterns.md` (everything else), **AND**
> - that module's **style recipe lib** — `styles/text_axes.md` or `styles/chart_axes.md` (the diverse looks live ONLY there).
>
> **Load checklist before you draw/approve:** ☐ `30_overlay_core.md` (this) ☐ `10_mechanics.md` if A-roll ☐ `40_thumbnail_cta.md` if endpoint scene ☐ `styles/design_languages.md` if authoring/rebuilding OR endpoint scene ☐ `31_typography.md` if any text appears or will be changed ☐ matching content module `31`/`32`/`33` ☐ its `styles/*.md`. Stopping at this file when you are actually drawing = flat / off-pattern output. Skipping endpoint design language proof = repeated-template risk. Skipping the A-roll ladder before drawing on narrator scenes = wrong narrator/overlay tradeoff. Skipping typography on a chart/diagram with labels = unreadable overlay risk. (Opening a module = a required ACTION, not optional — same rule as the master index.)
>
> **⭐ A-ROLL STARTING-LAYOUT BIAS GUARD.** If an A-roll scene currently shows a shrunken/picture-in-picture/fallback narrator, do not author, accept, or layout-fix the overlay against that small narrator as the baseline. First run the Gate 4 full-canvas candidate from `10_mechanics.md`: treat narrator full canvas as the starting design, then move/resize/simplify/rebuild the overlay around it. The current small narrator layout is only diagnostic evidence, not a design choice.
>
> **⭐ USER-FACING LANGUAGE GATE.** The internal overlay source is SVG, but that is a private implementation detail. In normal user updates, proof blocks, final hand-offs, and error explanations, say **overlay**, **overlay source**, or **overlay preview**. Do not say "SVG", ".svg", "vector conversion", or `svg2spec` unless the user is explicitly debugging the technical pipeline.
>
> **⭐ OVERLAY REPAIR AUTHORIZATION.** Do not add, rebuild, or overwrite an overlay during routine QA. Proceed only when Gate 4 has proven an exceptional non-deterministic/legacy/manual source problem or another explicit user-authorized defect. No endpoint or opening-scene exception exists; `40_thumbnail_cta` is retired.
>
> **⭐ MODULE LOAD PROOF — hard gate before overlay authoring.** Before you write a new overlay source or rebuild an existing overlay, print the master template:
> ```text
> Gate 4 MODULE LOAD PROOF:
> ☑ 30_overlay_core.md — overlay object/upload rules
> ☑ 10_mechanics.md — A-roll layout priority ladder (required when `show_narrator=true`)
> ☑ 40_thumbnail_cta.md — endpoint scene rules (required only for scene 2/opening poster, thumbnail sync, or final CTA)
> ☑ styles/design_languages.md — chosen language: <language_id>
> ☑ 31_typography.md — title/label/readability rules (required because overlay has text)
> ☑ <31_typography.md | 32_charts.md | 33_patterns.md> — content module for pattern=<pattern>
> ☑ `styles/text_axes.md` or `styles/chart_axes.md` — style recipe library
> Decision: <overlay N/A | leave existing overlay | layout-only fix | minor additive fix | text/style preserve fix | extract/reuse current visual then rebuild | full replace>
> ```
> If a required line is missing, **STOP**. Load the missing module first. Do not draw, upload, or mark Gate 4 PASS until the proof is complete and visible in the chat/log.
> 
> **⭐ A-ROLL LAYOUT PRIORITY PROOF — hard Gate 4 gate before overlay decision/authoring/upload.** If `show_narrator=true`, print this before deciding to leave, rebuild, upload, apply, or layout-fix the overlay:
> ```text
> Gate 4 A-ROLL LAYOUT PRIORITY PROOF:
> ☑ 10_mechanics.md — opened for the A-roll priority ladder before overlay decision
> Scene class: <normal | special_endpoint_or_trust>
> Narrator role: <primary | secondary>
> Overlay role: <support | main_subject>
> Current layout read: <full-canvas | shifted-full-canvas | shrunken/fallback | other>
> Overlay adjustments tested: <move | resize | simplify | rebuild | N/A> — current overlay is not fixed evidence
> Full-canvas gate: <PASS|FAIL> — tested narrator full canvas first while moving/resizing/simplifying/rebuilding the overlay as needed; face clear, no dead zones, readable, caption clear
> Priority 2 check: <PASS|FAIL|N/A> — pull narrator down + overlay above head; reason if rejected
> Priority 3 check: <PASS|FAIL|N/A> — push narrator up + overlay over chest; reason if rejected
> Priority 4 fallback check: <PASS|FAIL|N/A> — allowed only after 1–3 fail; narrator as large as possible, face large/clear/in safe_rect, X inside canvas, Y overflow allowed if it improves face size
> Chosen priority: <1 | 2 | 3 | 4>
> Overlay plan: <overlay N/A | leave existing | layout-only fix | minor additive fix | text/style preserve fix | extract/reuse current visual then rebuild | full replace | disable overlay> with placement rationale
> Verdict: <PASS to continue Gate 4 | BLOCKED — revise overlay/narrator plan>
> ```
> If this is A-roll and this proof is missing, **STOP**. A fallback/shrunken narrator layout is never approved from its current state alone; the proof must show full-canvas and shifted-full-canvas options were tested first as joint narrator + overlay + caption compositions and failed with concrete reasons. Do not reject a full-canvas priority just because the old overlay placement touches the face/caption/dead zone; move/resize/simplify/rebuild the overlay first.
>
> **⭐ TITLE GATE PROOF — hard gate after draft, before upload.** Loading `31_typography.md` is not enough. If the overlay has a title or hero text, print this proof and revise on any FAIL:
> ```text
> Gate 4 TITLE GATE PROOF:
> Title copy: "<exact title text>"
> Takeaway source: <exact authoritative `text` span it encodes>
> Source/provenance evidence: <authoritative `text` checked | pending post-upload integrity data>
> Copy correctness check: <PASS|FAIL> — authoritative `text` follows the scene language's spelling/orthography and preserves required script-specific characters/marks, Unicode, casing, punctuation, spacing, numbers, symbols, proper nouns, and domain terms
> Semantic check: <PASS|FAIL> — states the scene takeaway, not just a panel label
> Hierarchy check: <PASS|FAIL> — title is stronger than badges/panel labels
> Weight/card check: <PASS|FAIL> — title uses 900-equivalent / Black typography and is open typography, NOT inside a card/chip/pill/panel/banner/black translucent box
> Face-stack count: <8–15 copies> — same-fill copies inside the same title object; state why this count fits the font/word length; >15 copies = FAIL
> Over-thick visual check: <PASS|FAIL> — rendered title keeps crisp letterforms, open counters/negative space, clean tracking, and any script-specific marks; if duplicate fill makes it muddy/blobby/deformed, reduce count/offset or change font even inside 8–15
> First-second punch check: <PASS|FAIL> — title is not merely readable; it is thick, vivid, high-energy, and graspable immediately at 280×498
> Thickness/stroke check: <PASS|FAIL> — body is thick via 900-equivalent font + 8–15x face stack; visible text stroke is <=2px, thin/controlled, not over-stroked, and the face stack does not over-thicken the glyphs
> Overlay preview check: <shown cheaply | skipped — no cheap renderer | N/A> — if shown, preview appears title-led; if skipped, post-upload composite screenshot remains mandatory for composition
> Integrity/provenance check: <PASS|pending post-upload> — source/current-text hashes match, render succeeds, no truncation or missing glyph is reported, and scene/voice_file identity matches; no poster OCR
> Verdict: <PASS to upload | REVISE title before upload>
> ```
> Any FAIL blocks upload. Fix the overlay/title and repeat the gate. A skipped pre-upload preview is not a FAIL. After upload, confirm source/provenance integrity; a visual check is for the authored design change, not text OCR:
> ```text
> Gate 6 TITLE SCREENSHOT CHECK:
> Composite screenshot shown: <yes|no>
> Screenshot check: <PASS|FAIL> — when this rare authored-design check is applicable, the composite confirms title placement, visibility, hierarchy, face/caption coexistence, and first-second punch; copy correctness comes from authoritative source data
> Verdict: <PASS title | REVISE title/rebuild overlay>
> ```
>
> **⭐ SECONDARY TEXT/LABEL GATE — separate from title.** Title readability and label readability are two different gates. A title can PASS while the card text, chart labels, values, badges, or callouts FAIL. For every non-title text/value/label/card line, print and pass this before upload:
> ```text
> Gate 4 SECONDARY TEXT GATE PROOF:
> Text inventory: <exact non-title strings: values, labels, card text, badge text, callouts>
> Source/provenance evidence: <authoritative `text` checked | pending post-upload integrity data>
> Copy correctness check: <PASS|FAIL> — every required source string follows the scene language's orthography and preserves required numbers/dates/units/currency/%/proper nouns/domain terms and script-specific marks
> Size floor check: <PASS|FAIL> — each non-title text is >= ~30px on the 720 canvas OR deliberately simplified/removed; nothing depends on zoom
> Contrast check: <PASS|FAIL> — each line uses solid high-contrast fill on a clean chip/card/quiet area; secondary text has NO visible stroke/outline; no dark-on-dark card text
> Container/padding check: <PASS|FAIL> — every line fits inside its card/chip/bar area with generous interior padding; no clipped/overflowing words; no text touches, grazes, or visually crosses a border
> Collision/Z-order check: <PASS|FAIL> — labels/values/badges do not overlap or cover each other; badges never sit on top of value labels unless both remain readable
> Overlay preview check: <shown cheaply | skipped — no cheap renderer | N/A> — if shown, preview makes all secondary text appear readable; if skipped, post-upload composite screenshot remains mandatory for composition
> Integrity/provenance check: <PASS|pending post-upload> — source/current-text hashes match, render succeeds, no truncation or missing glyph is reported, and scene/voice_file identity matches; no poster OCR
> Verdict: <PASS to upload | REVISE labels before upload>
> ```
> After upload/layout tuning, use the visual proof only for this rare authored-design change; source/provenance data remains the text-correctness proof:
> ```text
> Gate 6 SECONDARY TEXT SCREENSHOT CHECK:
> Composite screenshot shown: <yes|no>
> Screenshot check: <PASS|FAIL> — composite confirms each secondary label/value/card line is visible, readable at 280×498 without zoom, has no visible outline/stroke, is not dark/muddy, is not overlapped/covered, and has breathing room; do not OCR it for copy correctness
> Verdict: <PASS secondary text | REVISE labels/layout/rebuild overlay>
> ```

### 0.5. How an uploaded overlay becomes objects (the SVG model)

You author the overlay as a **transparent SVG** (§5); `upload_overlay` sends the `.svg` and the server (`svg2spec`) turns it into the Remotion spec. The model is explicit — **no chroma key, no flat background color, no decompose guesswork**:

> **⭐ ONE GROUP = ONE OBJECT.** Every `<g data-wc-object="id">` in the SVG becomes exactly **one** Remotion object: the server renders that group alone on transparency, crops to its alpha bbox, and places it at that exact position (viewBox = the 720×1280 canvas, so the spec reproduces the SVG pixel-for-pixel). A nested *unmarked* `<g>` inside is just visual grouping; a marked group is atomic (not split further).
>
> **⭐ GROUPING IS THE ANIMATION UNIT.** Everything inside one group animates together (one beat); separate groups animate independently. To give a piece its own entry animation, put it in its own `data-wc-object` group — there is **no spacing/merge math** (that was the old raster-decompose model). Per-group entry comes from `data-wc-anim` (bar → growRight/growUp, text → a text-friendly entry, else the mapped hint or `fade`).
>
> **⭐ MAXIMAL GRANULARITY — one atom per object; atomize, NEVER clump.** Push the split as fine as it goes. The title is one object, and **every repeated element gets its OWN object**: a 4-item list is **4+ objects, one per item — NOT a title object plus one object holding all four**. Go finer *inside* an item too — a **check / bullet / number badge is its own object, SEPARATE from the text beside it**; a **bar is separate from its value label**; a **card frame is separate from its contents**; **each axis, connector, pin, legend row** is its own object. Rule of thumb: **if two marks could ever appear, animate, move, or sound at different times, they are TWO objects.** Only fuse marks that form one indivisible glyph. Granularity is free (each is just another `<g data-wc-object>`) and it BUYS per-element reveal, stagger, SFX, and individual editability/movability; clumping throws all of that away — one reveal for the whole clump, no per-item sound, not separately editable. To make several atoms still *appear together*, give them the **same `data-wc-delay`** (or one `data-wc-seq` wrapper) — they stay separate objects sharing a beat; **do NOT merge them into one group just to sync timing.**
>
> **⭐ TRANSPARENT, NOT CHROMA.** The SVG background is real transparency — **never paint a full-canvas background rect** (it would hide the scene video). Colors are free (no "background far from objects" rule). The scene video shows through wherever the SVG is transparent.

---

## 5. Create Overlay → Internal SVG → Remotion Spec

> **An overlay is built ONE way internally: author an SVG source, upload it, and let the server turn it into the Remotion spec.** This is a private implementation contract for agents, not user-facing language. Pre-upload preview is opportunistic. After upload, do not OCR the rendered overlay; confirm the authoritative `text` plus server integrity/provenance invariants. WideCast's `svg2spec` renders deterministic text and animation. **Assume you cannot generate images** — SVG is your internal toolbox for text, numbers, diagrams, charts, callouts, icons, and vector illustration. (A realistic photo you cannot draw is never *created*; it is *reused* — §5.4.)

> **AESTHETICS ARE MANDATORY when a rare rebuild is authorized.** Preserve hierarchy, contrast, spacing, and script integrity. Duplicate fill must not make letters blobby, close counters/negative space, break joins, swallow combining marks, crush tracking, or reduce the premium feel. More than 15 face copies fails, and some writing systems/fonts require fewer copies or a different contrast technique.
> 1. **Canvas 720×1280, NO background — fully transparent.** The scene video shows through; there is **no chroma, no flat key color, no background rect**. The server reads the SVG's real transparency.
> 2. **Each thing that should animate on its own = its own `<g data-wc-object>` group** (§5.1).
> 3. **≥5% outer padding on all four canvas sides** — nothing touches the scene edge (content box **x ∈ [36, 684], y ∈ [128, 960]**). This is only the OUTER margin; text inside cards/chips/bars also needs its own INNER padding.
>
> **⭐ UPLOAD-READY OBJECT SEPARATION BLOCKER.** Before hosting/uploading, inspect the authored source for clumping. If a `data-wc-object` group contains multiple independent atoms, the overlay is **not upload-ready**. Split first, then upload. Correct: title = one group; each checklist row = one group; each row's check/bullet/number badge = its own separate group; each card frame = its own group; each card label/value = its own group; each bar = one group and its value label = another; each connector/pin/axis/legend row = its own group. Wrong: one group holding an entire 4-row checklist; one group holding both comparison cards plus labels; one group holding a chart, all bars, and all values; one group holding a whole diagram. Exception: decorative sub-shapes that form one indivisible mark/glyph/highlight may stay inside the same atom as unmarked nested shapes, but decoration is not an excuse to merge independent text, icons, cards, bars, or labels.
>
> **⭐ TEXT STROKE BLOCKER.** Before hosting/uploading, inspect all authored text. Any visible `<text>` stroke/outline above **2px on the 720 canvas** means the overlay is **not upload-ready**. Secondary text (chart values, labels, card copy, badges, callouts, legends) should have **0px visible stroke**; give it a chip/backplate/quiet area instead. This cap is about letter outlines only: shape/card/icon strokes may be thicker when they are not text.
>
> **⭐ LARGE-TEXT CARD BLOCKER.** Before hosting/uploading, inspect every title/headline/hero quote/primary CTA/hero metric. If any large text is inside a card, chip, pill, rounded rectangle, black translucent box, panel, or banner, the overlay is **not upload-ready**. Large text must be open typography with 900-equivalent weight and <=2px text stroke. For contrast, use shadow/glow, better placement, a loose local scrim/gradient, underline/brackets, or other accent shapes that do not behave like a boxed text container. Secondary labels/values may use cards/chips only when needed and with real padding.
>
> **⭐ TITLE PUNCH / FACE-STACK BLOCKER.** Before hosting/uploading, inspect every title/headline/hero quote/primary CTA/hero metric. Use 8–15 same-fill copies only when the chosen font and writing system tolerate stacking. If duplicate fill makes text muddy/blobby, closes counters, breaks joins, swallows combining marks, or otherwise deforms the script, lower the count or use another compatible heavy-font/contrast technique. More than 15 copies fails.
>
> **⭐ TEXT-CONTAINER PADDING RULE — high aesthetic gate.** A bordered chip/card/pill is **optional for secondary text**, not mandatory. Decide internally: can the label/value sit cleanly as open text on a quiet area, inside the chart panel, or on a subtle no-border backplate? Use a bordered container only when it clearly improves contrast or grouping. If you do place secondary text inside a chip, card, badge, bar, pill, table cell, or panel, it must have visible interior padding on all sides. Minimum target on the 720×1280 SVG canvas: **24–32px horizontal padding** and **14–20px vertical padding** around the rendered text bbox; for large secondary badges/cards, use more. In the 280×498 screenshot this should still look like real air, not a hairline gap. If a word touches/grazes the border, sits on a stroke, gets clipped by rounded corners, or looks crowded even though readable, Gate 4/6 FAILS. Fix by removing the unnecessary border/container, widening the container, shortening/splitting the label, reducing only secondary font size slightly while staying above the mobile floor, moving objects, or rebuilding the SVG. Do not approve "readable but cramped."

### 5.0. WHEN to (re)build an overlay — the threshold (method is always internal SVG)

Before touching a scene's overlay, decide WHETHER an overlay should exist and WHETHER any repair is needed — don't default to "regenerate".

> **⭐ AUTHORITATIVE COPY GATE — before authoring can PASS.** Validate the scene's `text` in whole-video context and according to the scene language: spelling/orthography, applicable script-specific characters/marks, Unicode, casing, punctuation, spacing, STT meaning, proper nouns, domain terms, and numbers/dates/units/%/currency. Do not translate, transliterate, strip marks, or normalize to another locale. The overlay is not an independent copy source to OCR.

> **⭐ DETERMINISTIC RENDER INTEGRITY CHECK — data, not OCR.** After upload/edit, require server evidence that `overlay_source_text_hash == current_text_hash`, `render_status == success`, no truncation or missing glyph was reported, and scene/`voice_file` identity matches. Field names may vary by transport, but all invariants must be proven. If evidence is missing/mismatched or the source is non-deterministic/image-baked, user-uploaded, manually overridden, or legacy, Gate 4 becomes `UNVERIFIED` and may inspect only that exceptional source. A static poster that flattens timed states such as `one_by_one` is never evidence of a text, overlap, timing, or readability defect by itself.

> **⭐ THE AGENT DECIDES — autonomously. The user is NOT present at runtime.** This playbook is only the rails; every decision belongs to the running agent. The user delegated the whole job and reviews only the FINISHED video — so **never block on a question** ("do you want…?", "which one should I use?", "should I rebuild?"), never present options for approval, and never wait for input that won't come. Pick the best action using the master decision protocol, act, and surface anything noteworthy in the final hand-off.

> **⭐ NO-FORCE OVERLAY / TITLE GATE** — absence can be intentional:
> 0. **Eligibility before aesthetics.** If `remotion_spec=="none"`, no overlay exists, or Gate 4 provenance is healthy, overlay repair is N/A. Do not add an overlay or invent a title during routine QA. There is no opening/endpoint exception.
>
> **⭐ PRESERVE-OR-REPAIR THRESHOLD** — the core decision for every scene:
> 1. **Vision gate — can you see images?** **NO (pure-LLM, no vision):** do NOT rebuild the overlay (you can't judge the result) — limit yourself to **safe data-driven layout fixes** (`layout.batch` to clear `narrator_face` when `show_narrator=true`, pull an object out of a dead zone, stop caption overlap); otherwise **leave the overlay as the pipeline made it.** **YES (can see):** pull the screenshot, save it locally, show it visibly to the user, and **only then** look/evaluate it, then gate 2.
> 2. **Preserve gate — is the current visual already good enough?** If the scene already has a good map, realistic image, chart, diagram, timeline, illustration, or other coherent visual that matches the narration, **preserve it by default**. A missing big title, a different style than your last scene, or "I can make something punchier" is not a defect. Background failure, failed search, geo mismatch, or grid fallback is also not an overlay defect. **Full replacement is forbidden** unless the current visual has a serious defect: wrong/off-topic content, broken render, typo/wrong number/wrong term, unreadable or muddy text, dead-zone/caption/face collision that layout cannot fix, severe clutter, or a visual that clearly fails the scene's `visual`/talking point.
> 3. **Repair ladder — use the least destructive passing action:** `LEAVE` → `layout-only fix` → `minor additive fix` (`remotion.add_element`) → `text/style fix while preserving the current visual` → `extract/reuse current visual then rebuild around it` → `full replace`. The last step requires the Gate 4 FULL REPLACE PROOF and must be strictly better than the BEFORE screenshot in both correctness and quality. If the original is a map/realistic image/photo cut-out/complex diagram and it is not seriously defective, do not redraw it as a simpler homemade version.
> 4. **Context** — hook/CTA roles do not create an overlay-repair exception. Preserve healthy deterministic output and follow the same source-text plus provenance rules for every content scene.

**What you can build, and what you can't:**
- **When Gate 4 approves build/repair, you BUILD the overlay internally as SVG — free, full control, server converts.** Text / numbers / diagrams / charts / quotes / lists / callouts / icons / simple vector illustration → all authored as SVG. No image generation, no cost. **Do not expose this format to normal users.** Save the authored source locally; show a pre-upload overlay preview only when cheap. After upload, confirm deterministic integrity/provenance from data; do not OCR an overlay poster.
- **A realistic PHOTO you cannot draw is NOT created.** Either (a) **reuse** an existing one — embed it in the SVG via `<image>` (§5.4) — or (b) step down to an **SVG text/graphic** that carries the same message.
- **The scene BACKGROUND (real footage/grid) is a separate decision — §4** (`search_broll` / `mediaUrl`), not part of overlay authoring. Do not rebuild overlay because background search failed or grid fallback was chosen; preserve realistic overlay photos/maps/complex visuals unless Gate 4 independently proves an overlay defect.
- **Layout-only problem** (position/size/dead-zone, content still right) → don't rebuild; `remotion.object.rect` / `layout.batch` (§5.5).
- **Copy-only problem** originates in the authoritative `text` field: correct it with branch (K), then require updated hash/render/identity integrity. Do not independently rewrite deterministic overlay copy or re-verify it with poster OCR.

### 5.1. The SVG standard — every overlay

- **`viewBox="0 0 720 1280"`, transparent.** Never paint a full-canvas background rect (it would hide the scene). No chroma, no keying.
- **Each logical object = one `<g data-wc-object="id" …>`.** The server maps every marked group → ONE Remotion object (cropped to its bbox, transparent PNG) at its exact position. Group attributes:
  - `data-wc-object="car"` — stable id / name (used later for `layout.batch`).
  - `data-wc-kind="text|object|bar|callout|mark"` — optional; auto-inferred (a group with only `<text>` → `text`).
  - `data-wc-anim="…"` — **entry animation, FULL vocabulary** (12 + 2 bar), any object incl. text. Accepts a friendly alias OR the raw engine name: `fade · slide-up/down/left/right (slideUp/…) · scale(scaleIn) · zoom(zoomIn) · pop/bounce(bounceIn) · spin(rotate) · roll(rollIn) · flip-x/y(flipInX/Y) · grow-x(growRight) · grow-y(growUp)`. Unknown → `fade`. A **bar** is forced to growRight/growUp. Vary the entry between objects/videos for life.
  - `data-wc-z="2"` — paint/stack order (default = document order).
  - **`data-wc-delay="0.6"`** (seconds) — exact reveal time for that object (sequencing / overlap control).
  - **`<g data-wc-seq="0.4">…</g>` — LINE-BY-LINE (accumulate).** Auto-staggers its child `data-wc-object` groups (delay = step × 0,1,2…) so they appear one after another and **STAY** (the full set is visible at the end). Good for building up a sentence/list.
  - **`<svg … data-wc-ani="one_by_one">` — TRUE ONE-BY-ONE (replace).** Only ONE object on screen at a time; each is **replaced** by the next (you end on the LAST one — you never see them together). The engine splits the full scene window into N equal slots, **ignores per-object delays/`objects_duration`, and AUTO-POSITIONS** the lines (top-center safe zone; or `data-wc-textpos="bottom"` = lower band, which **auto-clears an upper narrator face** on A-roll — no manual move needed). `data-wc-hold="0.8"` holds the final line longer. Use for a run of self-contained punches/phrases. (Also: `data-wc-ani="all"` = default accumulate · `focus_zoom` · `breath_pulse` · `data-wc-campan="left_to_right|right_to_left"`.)
  - To reveal **all at once**, set `data-wc-delay="0"` on every object; with **no** delay/seq/ani attrs the server auto-staggers (accumulate) by default.
  - **`data-wc-sfx`** — reveal sound. By default the **top-N largest objects auto-get a sound** mapped from their entry (same engine map as native specs — whoosh/pop/click…). Override per object: `data-wc-sfx="reveal1.mp3"` to force a file, or `data-wc-sfx="none"` to mute.
  - A nested **unmarked** `<g>` inside is fine (visual grouping only); a marked group is **atomic** (the server doesn't split it further).
- **Grouping IS the animation unit.** Everything in ONE group animates together; separate groups animate independently. There is **no spacing/merge math** — grouping is explicit (this replaces the old "space objects apart so they don't merge" rule).
- **Position is exact + reproduces pixel-for-pixel.** viewBox = the 720×1280 canvas, so each group's bbox = its true canvas position. Keep all content in the safe box **x ∈ [36, 684], y ∈ [128, 960]** (5% sides; 128px top dead-zone; 320px bottom reserved for the caption). The server vertically auto-fits the group into the safe band — keep the content **compact**; for an exact vertical spot, set it afterward with `layout.batch` (don't rely on your source y surviving).
- **Composition before anchoring:** for B-roll / faceless / non-face-critical overlays, split placement by content type. If the overlay is `typography_only` / text-only, design the text block near the vertical center of the safe box; do not park text at the top-safe band by habit. If the overlay mixes text with objects/charts/cards/icons, prefer a top-safe title/text band with the object layer below it, all still inside the safe box and visually connected. If that first placement covers an important real background face/product/prop, move the whole text/object group lower/higher within the safe box. Never let objects drift near the caption or detach from the title just because the title is important.
- **Font — use a renderer-supported family that covers every required Unicode code point and correctly shapes the scene's writing system.** Name an available heavy variant when appropriate; do not assume a Latin family, casing rule, or weight suffix works for every language.
- **Colors are free** — there is no chroma constraint. Use any palette (derive the accent — §5.2).
- **Text readability + padding standard:** design for the final 280×498 composite and the scene's writing system. Use a compatible heavy font and contrast treatment that preserves counters, joins, combining marks, and punctuation. A face stack is optional when the script would deform. Keep authored text stroke at 0–2px max; secondary text should have no visible outline and must retain real container padding.

### General drawing rules (apply to every graphic — charts & patterns)

When Gate 4 has approved an exceptional build/repair, use `pattern`/`sub_mode`/`visual` only to determine visual structure. **All displayed copy and anchors must be exact spans derived from the authoritative `text`;** `quote`, `talking_point`, and `visual` are supporting semantics, never independent copy sources. Do not invent or silently paraphrase. Keep each independently animated atom in its own marked group.

- **Spatial specificity:** when the narration names a position/angle/area/point, the visual must depict it (e.g. "T-bone at the right passenger door, 3/4 front-right", a callout onto the exact field) — not a generic placeholder.
- **Callouts / marks** are SVG's home turf: an `<ellipse>`/`<circle>` outline (no fill) + a leader `<line>`/`<path>` + a small `<text>` label, all over the thing being marked — put the whole callout in one `data-wc-object="callout"` group.
- **⭐ Draw every mark / icon / arrow / check as a VECTOR SHAPE (`<path>`/`<polyline>`/`<circle>`), never a font glyph.** The renderer font may not contain `✓ ✗ → ➜ ★ ● ☑` etc. → they render as **tofu boxes** (verified: drew all checks/crosses/arrows as `<polyline>`/`<path>` this session). A check = a 2-segment `<polyline>`; a cross = two `<line>`s; an arrow = a `<path>`/triangle `<polygon>`; a bullet/number badge = a `<circle>` (+ a `<text>` number inside). Plain quote marks `"` `"` and the middot `·` ARE safe in the sans families; emoji/dingbats/arrows are not.
- Keep each text element concise for the scene's language and preserve the authoritative Unicode text exactly; do not strip marks, transliterate, or force another locale's word-count/casing conventions.

### 5.4. Reuse an existing realistic image (NOT creation)

When a scene genuinely needs a **realistic photo you cannot draw** and one already exists, **reuse it inside the SVG** — never claim to create it:
- **⭐ If the existing overlay is GOOD and you only need to ADD a missing label/stat/callout (no restyle, no recompose) → don't rebuild at all: `modify_scene` (M) `remotion.add_element`** (FREE, additive, does NOT overwrite the spec or disturb the photo). This is the cleanest path for the preserve case. Reserve the extract-and-rebuild path below for when you must ALSO restyle/recompose (which requires a full re-author + overwrite).
- **From the current spec** (the narrow "preserve" case — applies when the existing realistic image is good + on-topic and the ONLY problem is missing info): **extract it BEFORE you overwrite.** The spec embeds the image as a base64 PNG — the **longest string** at `elements[].props.objects[].image` (prefix `data:image/png;base64,`). Decode it to a local image file, show that local image to the user, and **only then** inspect/reuse it (it's a clean transparent cut-out), then embed it in your SVG:
  `<g data-wc-object="photo"><image href="data:image/png;base64,…" x="…" y="…" width="…" height="…"/></g>`
  and add missing text/stat groups only from exact authoritative `text` spans. Use `visual` solely to guide structure. Embed preserved images as data URLs so conversion cannot silently drop remote media.
- **From a found asset / user-supplied image:** same — download/save it locally and show it before judging or embedding. Prefer embedding it as a data URL when the image is part of a rebuilt SVG spec, especially for one-off overlays; use an external `<image href="https://…">` only if the final post-upload screenshot proves the remote image actually rendered.
- If no overlay is currently present, leave it absent during routine QA. Opening, thumbnail, and CTA roles do not bypass this rule. A new overlay requires explicit user authorization outside the normal source-text/background audit.
> ⚠️ **ORDER MATTERS:** `upload_overlay` OVERWRITES `{voice_file}_spec.json`. For any scene whose existing photo you want to keep, **extract it FIRST**, then save the new overlay source, optionally show a cheap local overlay preview, then upload the new source. Once overwritten, the original photo is gone from the spec.

### 5.5. Apply & verify

1. **Save the local overlay source; preview only when cheap.** Write the authored SVG source to a local `.svg` file. If the environment can display that file directly or convert it with an already-available lightweight path, show the user a local **overlay preview** before upload. If not, skip pre-upload preview. Do **not** install tools, launch headless browsers, or probe multiple conversion paths just to produce a preview. Do not describe the internal file format to normal users.
2. **Host the internal source, then upload.** Before this step, run the existing authoring blockers and FULL REPLACE PROOF when applicable. `upload_overlay` takes a URL, not raw markup: upload the SVG source, then apply `remotion.upload_overlay` by `voice_file`. The server detects SVG → `svg2spec` → spec + poster. **Do not upload JPG/PNG for deterministic overlay text and do not OCR the poster.** Confirm source/current-text hash, render success, no truncation/missing glyph, and scene/`voice_file` identity from server data.
3. **Fine-tune position/scale** if needed: `modify_scene` (G) layout edits, FREE. Use `layout.batch` wrapping `remotion.object.rect` (`layout_id` from the object id + `x/y/w/h` in preview space) when moving 1–12 specific objects. If you are translating the whole overlay together, or the overlay decomposed into more than 12 objects, use `remotion.group.rect` on the Storyboard group (`element_id:"main"`, `x/y`, `coordinate_space:"preview"`) instead. If the group is too tall for the safe band, do **not** jump straight to rebuild: first try move-only group translation; if that trades a top violation for a bottom violation (or vice versa), use whole-group resize (`w/h`, `resize_mode:"scale_children"`). For B-roll text-only/`typography_only`, prefer moving the text block to the center of `safe_rect`; for mixed text+object overlays, prefer a top-safe title/text band with the object layer below and coherent spacing. Rect edits only **move/resize**; they can't restyle, so after resizing you must re-check title and secondary readability from a local-shown screenshot. **Every layout edit invalidates Gate 6 DEAD-ZONE PROOF; pull fresh `scene_geometry` and repeat the proof before Scene PASS.** Rebuild the overlay only when the resized group makes typography too small/muddy/cramped or otherwise fails the text gates.
   > **⚠️ A-ROLL (`show_narrator=true`) — THE OVERLAY DOES NOT AUTO-AVOID THE FACE.** Unlike the native typography path, an `upload_overlay` SVG is **auto-fit CENTERED in the safe band** → it can land on the narrator's face. So for any A-roll scene you MUST already have the Gate 4 A-ROLL LAYOUT PRIORITY PROOF from `10_mechanics`, then use `scene_geometry` to read `narrator.face` and place/tune the overlay according to the chosen priority: above the head when priority 1/2 selected that upper placement, or below the face/chest band when priority 1/3 selected lower placement. The hard requirement is not "always below the face"; it is **face fully clear + no dead-zone intrusion + readable overlay + caption clear**, proven from the local-shown screenshot. For lower-band placements, keep overlay object tops below `face.y + face.h` with margin and above the caption; for above-head placements, keep overlay bottoms above the face with margin and out of `dead_top`. **Never assume auto-placement cleared the face — use a local-shown screenshot.** **Cleaner for typography:** use `data-wc-ani="one_by_one" data-wc-textpos="bottom"` when the Gate 4 priority chooses a lower text band — the engine then auto-places the lines in the lower band and clears an upper narrator face; for upper-band or static/accumulate overlays, tune via `layout.batch` / `remotion.group.rect` according to the chosen priority.
4. **Verify the rare authored overlay change without OCR.** Use server integrity/provenance data as the text proof. If a composite screenshot is already required for the authored visual change, save/show it before evaluating design only; do not use a static poster to judge animated overlap or copy. Correct source-text errors in `text` with branch (K), then require refreshed hash/render/identity integrity. Only Gate 4 `EXCEPTIONAL_FALLBACK` may inspect an overlay poster, and stacked timed states alone never constitute a failure.
   > **⭐ DEAD-ZONE CHECK — mandatory on every overlay review.** Confirm **NO overlay object or text sits in a dead zone**: `dead_top` (canvas y < 128 / preview y < 49.8) or `dead_bottom` (canvas y > 960 / preview y > 373.5). The authoring safe-box only governs your SOURCE positions — the server **vertically auto-fits** the group, A-roll **auto-centers** it, and any layout edit can push an object out, so content CAN land in a dead zone after upload. Cross-check the local-shown rendered screenshot **against `scene_geometry` object rects vs `safe_zones`** and print the **Gate 6 DEAD-ZONE PROOF** from `03_dod_gates` with object ids/layout_ids checked. If 1–12 individual objects intrude, pull them back into `safe_rect` with `layout.batch` (`remotion.object.rect`). If the whole overlay group intrudes, use the group ladder: **move whole group first; if moving creates the opposite dead-zone violation, resize the whole group; rebuild only if the resized typography fails readability**. Re-verify with another saved/shown local screenshot and repeat Gate 6 DEAD-ZONE PROOF. (The caption owns `dead_bottom` — overlay content stays above it; nothing in the top notch band either.)
5. **Lock the spec**: `remotion_spec` → `{voice_file}_spec.json?v=<ts>`. If `remotion_spec=="none"` (the user disabled the overlay) don't re-enable unless asked.

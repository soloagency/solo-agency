// Solo Agency plan verification (Ed25519, WebCrypto) — see solo_entitlement.js.
importScripts("solo_entitlement.js");
// Platform-module layer (additive, 2026-09-09). core/schema.js is the one canonical record shape;
// core/platform_registry.js describes each platform module as data; platforms/<name>/*_normalize.js
// is that module's own mapping from its typed capability output into the canonical shape. All
// three are pure JSON functions with no chrome.* or DOM dependency, so a load failure here would
// be a syntax error caught by `node --check` before sync, never a runtime surprise.
importScripts("core/schema.js", "core/platform_registry.js", "platforms/facebook/fb_normalize.js", "platforms/zillow/zillow_normalize.js", "platforms/instagram/ig_normalize.js", "platforms/x/x_normalize.js");

// How long one capability may run inside the page before it is killed. Raised from 45s: a tab that
// is never activated is throttled by Chrome and the same About walk took 2-3x longer than in an
// active tab (measured: 6.2->18.3s, 12.3->27.4s, 13.0->29.8s), which left no room under 45s once
// the walk's own budget was spent. It is ONE constant because the run-lock estimate below must
// never be shorter than what a capability is allowed to take — a lock that expires mid-run hands
// the same job to the next poll while the first is still working.
const CAPABILITY_TIMEOUT_MS = 60000;
// The module's cooperative share of that timer. When the kill timer wins the race, every page a
// capability had already fetched is discarded and the bridge receives count:0 — so the
// dispatcher hands each module `time_budget_ms` = the timer minus this margin, and a pagination
// loop that honours it (fb.post.comments, ig.*, x.*) stops on its own with its rows and cursor
// kept, reporting stopped_because:"time_budget". The margin covers script injection, the last
// in-flight request's abort and the normalizer. A job may ask for LESS via inputs.time_budget_ms;
// it can never get more than the kill timer allows.
const CAPABILITY_BUDGET_MARGIN_MS = 10000;

const DEFAULT_SETTINGS = {
  enabled: true,
  bridgeBaseUrl: "http://127.0.0.1:17321",
  pollMinutes: 1,
  pollSeconds: 5,
  minDelaySeconds: 5,
  maxDelaySeconds: 5,
  maxSourcesPerRun: 20,
  sourceConcurrency: 1,
  scrollSteps: 5,
  maxTextChars: 12000,
  closeTabsAfterCollect: true
};

const STATE_KEY = "collector_state";
const SETTINGS_KEY = "collector_settings";
const COMPLETED_RUNS_KEY = "collector_completed_runs";
const ACTIVE_RUN_KEY = "collector_active_run";
const AUDIT_KEY = "collector_audit";
const BUILD_STATE_KEY = "collector_extension_build";
const CAPTURE_FILES = ["collector_helpers.js", "readability.js", "filtering.js", "infinity_loops.js", "contact_extract.js"];
const ACTIVE_RUN_LOCK_MINUTES = 120;
// Read the real manifest version instead of a string someone has to remember to
// bump. It was frozen at "0.2.1-name-and-catalog" across every build since, so the
// bridge reported the same version for three extensions running three different
// builds — and during a live debug there was no way to tell whether a reload had
// even happened. The label is kept as a suffix so existing log greps still match.
const EXTENSION_BUILD = (() => {
  try { return chrome.runtime.getManifest().version + "-platform-modules"; }
  catch (e) { return "0.2.1-platform-modules"; }
})();
const NORMAL_SCROLL_CAP = 10;
const DISCOVERY_SCROLL_CAP = 10;

const inMemoryActiveRuns = new Set();
let clientBindingCache = null;

// Owner decision 2026-09-10: extensions/{client_slug}/ (soon {client_slug}_extension/) is the
// only folder prepare_client_extension.sh ever produces, and it ALWAYS writes a
// client_binding.json into it. So a missing/unreadable client_binding.json at runtime means one
// of two things: this is the SOURCE template folder (solo-agency-collector/chrome-extension/,
// which ships no binding on purpose) loaded by mistake, or a client copy that never finished
// generating / got corrupted. Either way there is no client identity to poll the shared local
// bridge with or to report a job against, so the guard below stops pollBridge before it makes
// any network call and surfaces one English sentence the popup (and any agent walking the
// human through it) can read verbatim.
const NO_CLIENT_BINDING_STATUS = "no_client_binding";
const NO_CLIENT_BINDING_MESSAGE =
  "This is the SOURCE folder, not a client copy. Open the dashboard's Extension page — it " +
  "shows the correct {client_slug}_extension folder path. Load that folder, not this one.";

chrome.runtime.onInstalled.addListener(async () => {
  await resetRunLockAfterBuildChange("installed");
  const settings = await getSettings();
  await chrome.storage.local.set({ [SETTINGS_KEY]: settings });
  chrome.alarms.create("collector_poll", { periodInMinutes: Math.max(1, settings.pollMinutes || 1) });
  scheduleShortPoll(settings);
  await setState({ status: "installed", message: "Collector installed and idle." });
  await pollBridge("installed");
});

chrome.runtime.onStartup.addListener(async () => {
  await resetRunLockAfterBuildChange("startup");
  const settings = await getSettings();
  chrome.alarms.create("collector_poll", { periodInMinutes: Math.max(1, settings.pollMinutes || 1) });
  scheduleShortPoll(settings);
  await pollBridge("startup");
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "collector_poll") {
    pollBridge("alarm").catch((error) => setState({
      status: "error",
      message: String(error && error.message ? error.message : error),
      updatedAt: new Date().toISOString()
    }));
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  (async () => {
    if (message && message.type === "get_state") {
      sendResponse({ ok: true, state: await getState(), settings: await getSettings() });
      return;
    }
    if (message && message.type === "save_settings") {
      const requestedBridgeUrl = String((message.settings || {}).bridgeBaseUrl || "").trim();
      const inUseBridgeUrl = (await getSettings()).bridgeBaseUrl;
      const next = normalizeSettings(message.settings || {});
      // A refusal must not also cost the operator the bridge they are actually running on: an
      // install on a non-default loopback port keeps THAT, not the hardcoded default.
      if (requestedBridgeUrl && !isLoopbackBridgeUrl(requestedBridgeUrl)) {
        next.bridgeBaseUrl = safeBridgeUrl(inUseBridgeUrl, DEFAULT_SETTINGS.bridgeBaseUrl);
      }
      // Saying "saved" over a value that was thrown away is how a refused setting looks like a
      // working one. The popup gets both the flag and the exact string that was refused.
      const bridgeUrlRejected = Boolean(requestedBridgeUrl) && !isLoopbackBridgeUrl(requestedBridgeUrl);
      const bridgeRefusalMessage = bridgeUrlRejected
        ? `Bridge URL refused: ${bridgeHostOf(requestedBridgeUrl)} is not this machine. The collector only ever talks to the local bridge, so ${next.bridgeBaseUrl} was kept.`
        : "";
      await chrome.storage.local.set({ [SETTINGS_KEY]: next });
      chrome.alarms.create("collector_poll", { periodInMinutes: Math.max(1, next.pollMinutes || 1) });
      scheduleShortPoll(next);
      const bridgeConfigSaved = await syncSettingsToBridge(next);
      await setState({
        status: bridgeUrlRejected ? "bridge_url_rejected" : "settings_saved",
        message: (bridgeUrlRejected ? bridgeRefusalMessage + " " : "") + (bridgeConfigSaved === true
          ? "Settings saved locally and to bridge."
          : bridgeConfigSaved === "skipped"
            ? "Settings saved locally. Shared agency config is managed by the agent and bridge."
            : "Settings saved locally. Bridge config was not updated."),
        bridgeConfigSaved
      });
      const pollResult = await pollBridge("settings_saved");
      // pollBridge() writes its own state LAST, and that state can be a real run's result.
      // So the refusal does NOT overwrite status/message (that would report a finished run as a
      // settings error); it rides alongside as its own field, which setState merges and the
      // popup paints red until a valid URL is saved.
      await setState({
        bridgeUrlRejected: bridgeUrlRejected
          ? { host: bridgeHostOf(requestedBridgeUrl), kept: next.bridgeBaseUrl, at: new Date().toISOString() }
          : null
      });
      sendResponse({ ok: true, settings: next, bridgeConfigSaved, pollResult, bridgeUrlRejected, bridgeUrlRejectedValue: bridgeUrlRejected ? requestedBridgeUrl : "" });
      return;
    }
    if (message && message.type === "check_now") {
      const result = await pollBridge("manual");
      sendResponse({ ok: true, result, state: await getState() });
      return;
    }
    if (message && message.type === "manual_capture") {
      sendResponse(await manualCapture());
      return;
    }
    if (message && message.type === "test_scroll_active_tab") {
      sendResponse(await testScrollActiveTab(message));
      return;
    }
    if (message && message.type === "get_audit") {
      sendResponse({ ok: true, audit: await getAudit() });
      return;
    }
    // Reachable from the popup AND from the on-page overlay button: the overlay is injected with
    // chrome.scripting.executeScript and no `world`, so it runs in the ISOLATED world and can call
    // chrome.runtime.sendMessage directly. No web page can reach this listener — the manifest
    // declares no externally_connectable and there is no onMessageExternal handler.
    if (message && message.type === "cancel_run") {
      const state = await getState();
      const runId = message.run_id ? String(message.run_id) : (state && state.runId ? String(state.runId) : "");
      const result = await requestCancel({
        runId: message.all ? "*" : runId,
        reason: message.reason || "cancelled by operator",
        requestedBy: message.requested_by || "extension_ui"
      });
      sendResponse({ ok: true, ...result, run_id: runId });
      return;
    }
    if (message && message.type === "reset_audit") {
      await chrome.storage.local.remove(AUDIT_KEY);
      sendResponse({ ok: true });
      return;
    }
    sendResponse({ ok: false, error: "unknown message" });
  })().catch((error) => sendResponse({ ok: false, error: String(error && error.message ? error.message : error) }));
  return true;
});

// --- cancelling a run in flight -------------------------------------------
// Until now nothing could stop a collection once it started: unchecking "Enabled" only gates the
// NEXT poll, and the run loop never asked the bridge anything — every call inside it is a one-way
// POST whose response is discarded. So an operator who wanted their machine back had no lever at
// all, and an agent had none either.
//
// Cancelling is cooperative and has two halves, because one alone is not enough:
//
//   1. A flag the source loop checks between sources. That stops the run from starting new work.
//   2. Closing the tabs the run opened. That is what makes it FAST. The long waits inside a source
//      are not interruptible — the page capture alone runs 3 to 25 minutes and withTimeout does not
//      abort it, it only stops waiting — but they all hang off a tab. Removing the tab makes the
//      pending executeScript reject immediately, so the current source ends in about a second
//      instead of up to 25 minutes (or up to six hours behind Zillow's human gate).
//
// The cancelled source reports status "cancelled", not "error": it did not fail, it was stopped,
// and a consumer scanning source_status.jsonl for failures must not count it as one.
const CANCEL_KEY = "collector_cancel_request";
let cancelRequest = null;              // { runId | "*", reason, requestedBy, at }
const activeRunTabs = new Map();       // tabId -> runId, so a cancel closes only this run's tabs

// A cancel naming a run applies to that run, whenever it was raised. A blanket "*" cancel applies
// only to a run that was ALREADY IN FLIGHT when it was raised — otherwise a request left in storage
// by a service worker that died mid-run would silently kill the next run, and the next, with the
// operator seeing runs that end instantly for no stated reason.
function cancelAppliesTo(runId, runStartedAt) {
  if (!cancelRequest) return false;
  if (cancelRequest.runId !== "*") return !!runId && cancelRequest.runId === runId;
  if (!runStartedAt) return true;
  return String(cancelRequest.at || "") >= String(runStartedAt);
}

async function loadCancelRequest() {
  // The service worker can be torn down between the popup's click and the next source boundary,
  // so the request is mirrored in storage rather than living only in memory.
  try {
    const stored = await chrome.storage.local.get(CANCEL_KEY);
    if (stored && stored[CANCEL_KEY]) cancelRequest = stored[CANCEL_KEY];
  } catch (error) { /* storage unavailable: the in-memory flag still works */ }
  return cancelRequest;
}

async function requestCancel({ runId, reason, requestedBy }) {
  cancelRequest = {
    runId: runId ? String(runId) : "*",
    reason: String(reason || "cancelled by operator"),
    requestedBy: String(requestedBy || "unknown"),
    at: new Date().toISOString()
  };
  try { await chrome.storage.local.set({ [CANCEL_KEY]: cancelRequest }); } catch (error) { /* ignore */ }

  // Closing the tabs is the part that actually interrupts work in progress. Everything the run is
  // waiting on is anchored to one of these tabs.
  const closed = [];
  for (const [tabId, tabRunId] of Array.from(activeRunTabs.entries())) {
    if (cancelRequest.runId !== "*" && tabRunId !== cancelRequest.runId) continue;
    activeRunTabs.delete(tabId);
    try { await chrome.tabs.remove(tabId); closed.push(tabId); }
    catch (error) { /* already gone */ }
  }
  await setState({
    status: "cancelling",
    message: `Cancelling ${cancelRequest.runId === "*" ? "the active run" : "run " + cancelRequest.runId}: ${cancelRequest.reason}`,
    cancelRequest,
    tabsClosed: closed.length,
    updatedAt: new Date().toISOString()
  });
  return { ok: true, cancel: cancelRequest, tabs_closed: closed.length };
}

async function clearCancelRequest() {
  cancelRequest = null;
  try { await chrome.storage.local.remove(CANCEL_KEY); } catch (error) { /* ignore */ }
}

// A cancel raised anywhere else — an agent hitting the bridge, the CLI, another operator surface —
// reaches the run through this. It is a DEDICATED read-only route, deliberately not /status:
// GET /status has the side effect of CLAIMING the next pending job (handleStatus reaches
// activateQueuedJobForExtension), so polling it from inside a run would start a second run.
async function remoteCancelRequested(bridgeBaseUrl, runId) {
  if (!bridgeBaseUrl || !runId) return null;
  try {
    const res = await fetchJSON(`${bridgeBaseUrl}/jobs/control?run_id=${encodeURIComponent(runId)}`, {}, 4000);
    if (res && res.cancelled) {
      return { reason: String(res.reason || "cancelled on the bridge"), requestedBy: String(res.requested_by || "bridge") };
    }
  } catch (error) {
    // An older bridge has no such route, and a bridge that is down cannot be asked. Neither is a
    // reason to stop collecting — a cancel that never arrives must not look like one that did.
  }
  return null;
}

let shortPollTimer = null;

function scheduleShortPoll(settings) {
  if (shortPollTimer) clearTimeout(shortPollTimer);
  if (!settings || !settings.enabled) return;
  const seconds = clampNumber(settings.pollSeconds, 5, 60, 5);
  shortPollTimer = setTimeout(async () => {
    try {
      await pollBridge("short_poll");
    } finally {
      scheduleShortPoll(await getSettings());
    }
  }, seconds * 1000);
}

async function pollBridge(reason) {
  await resetRunLockAfterBuildChange(reason || "poll");
  const settings = await getSettings();
  const binding = await getClientBinding();
  if (!binding.client_slug) {
    // No readable client_binding.json -- see the guard comment above. Never touch the bridge
    // from here: there is no client identity to poll for or to report a job against.
    await setState({
      status: NO_CLIENT_BINDING_STATUS,
      message: NO_CLIENT_BINDING_MESSAGE,
      reason,
      updatedAt: new Date().toISOString()
    });
    return { status: NO_CLIENT_BINDING_STATUS };
  }
  if (!settings.enabled) {
    await setState({ status: "disabled", message: "Collector disabled.", reason });
    return { status: "disabled" };
  }

  const bridgeBaseUrl = trimSlash(settings.bridgeBaseUrl);
  let status;
  try {
    status = await fetchJSON(`${bridgeBaseUrl}/status`, {
      method: "GET",
      headers: collectorHeaders(binding)
    }, 6000);
  } catch (error) {
    // Two very different failures reach this catch: the bridge is not running (normal, the
    // operator starts it) and fetchJSON REFUSED to send because the URL is not this machine
    // (never normal). Reporting the second as "bridge is offline" would send the operator
    // looking for a process instead of at the setting that is pointing their data elsewhere.
    const refused = !isLoopbackBridgeUrl(bridgeBaseUrl);
    await setState({
      status: refused ? "bridge_url_rejected" : "bridge_offline",
      message: refused
        ? `Bridge URL refused: ${bridgeHostOf(bridgeBaseUrl)} is not this machine. Nothing was sent. Set it back to ${DEFAULT_SETTINGS.bridgeBaseUrl} in the popup.`
        : "Local bridge is not running.",
      bridgeBaseUrl,
      reason,
      updatedAt: new Date().toISOString()
    });
    return { status: refused ? "bridge_url_rejected" : "bridge_offline" };
  }
  const bridgeContactAt = new Date().toISOString();

  if (!status || !status.job_available || status.completed) {
    await setState({
      status: "idle",
      message: "Bridge is online but no unfinished job is available.",
      bridgeStatus: status,
      lastBridgeContactAt: bridgeContactAt,
      reason,
      updatedAt: new Date().toISOString()
    });
    return { status: "idle" };
  }

  const job = await fetchJSON(`${bridgeBaseUrl}/jobs/current`, {
    method: "GET",
    headers: collectorHeaders(binding)
  }, 8000);
  if (!jobMatchesBinding(job, binding)) {
    await setState({
      status: "job_for_other_client",
      message: "Bridge returned a job for a different client or extension.",
      runId: job && job.run_id ? String(job.run_id) : "",
      bridgeStatus: status,
      lastBridgeContactAt: bridgeContactAt,
      reason,
      updatedAt: new Date().toISOString()
    });
    return { status: "job_for_other_client" };
  }
  const session = job.collector_bridge || {};
  // Solo Agency plan: verify the bridge's signed entitlement HERE, with the server's public key.
  // A bridge that cannot present a valid token counts as Free for Pro capabilities (once
  // SOLO_ENTITLEMENT_ENFORCE is on); until then the outcome is only recorded.
  const entitlement = await SoloEntitlement.verify(session.entitlement_token || "", Date.now());
  entitlement.bridgeTier = String(session.entitlement_tier || "");
  entitlement.bridgeMode = String(session.entitlement_mode || "");
  const runId = String(job.run_id || session.run_id || status.run_id || "");
  if (!runId) {
    await setState({ status: "invalid_job", message: "Collector job has no run_id.", reason });
    return { status: "invalid_job" };
  }

  const completedRuns = await getCompletedRuns();
  if (completedRuns[runId] && !job.force) {
    await setState({
      status: "already_completed",
      message: `Run ${runId} was already completed by this extension.`,
      runId,
      bridgeStatus: status,
      lastBridgeContactAt: bridgeContactAt,
      reason,
      updatedAt: new Date().toISOString()
    });
    return { status: "already_completed", runId };
  }

  const runLock = await acquireRunLock(runId, job, status, reason);
  if (!runLock.acquired) {
    await setState({
      status: "already_running",
      message: `Run ${runId} is already being collected. Ignoring ${reason} poll.`,
      runId,
      lockReason: runLock.reason,
      activeLock: runLock.lock || null,
      bridgeStatus: status,
      lastBridgeContactAt: bridgeContactAt,
      reason,
      updatedAt: new Date().toISOString()
    });
    return { status: "already_running", runId, reason: runLock.reason };
  }

  const token = session.write_token;
  if (!token) {
    await releaseRunLock(runId, runLock.owner);
    await setState({ status: "invalid_job", message: "Collector job missing write token.", runId, reason });
    return { status: "invalid_job" };
  }

  try {
    await runJob({ job, token, bridgeBaseUrl, settings, binding, reason, entitlement });
    completedRuns[runId] = new Date().toISOString();
    await chrome.storage.local.set({ [COMPLETED_RUNS_KEY]: trimCompletedRuns(completedRuns) });
    return { status: "completed", runId };
  } finally {
    await releaseRunLock(runId, runLock.owner);
  }
}

async function runJob({ job, token, bridgeBaseUrl, settings, binding, reason, entitlement }) {
  const entitlementView = SoloEntitlement.view(entitlement);
  const runId = String(job.run_id || job.collector_bridge?.run_id || "");
  const runStartedAt = new Date().toISOString();
  // A click that arrived while this worker was asleep lives in storage, not memory.
  await loadCancelRequest();
  const sources = normalizeSources(job.sources || []);
  const pacing = job.pacing || {};
  const maxSources = Math.min(
    Number(pacing.max_sources || settings.maxSourcesPerRun || 20),
    sources.length
  );
  const selectedSources = sources.slice(0, maxSources);
  const sourceConcurrency = Math.min(
    selectedSources.length || 1,
    clampNumber(
      pacing.source_concurrency || pacing.max_parallel_sources || settings.sourceConcurrency,
      1,
      3,
      1
    )
  );
  const counts = {
    dataPoints: 0,
    competitors: 0,
    newPrivateSources: 0
  };

  await setState({
    status: "running",
    message: `Collecting ${selectedSources.length} private sources with ${sourceConcurrency} tab${sourceConcurrency === 1 ? "" : "s"}.`,
    runId,
    entitlement: entitlementView,
    totalSources: selectedSources.length,
    sourceConcurrency,
    dataPointsCollected: counts.dataPoints,
    competitorsDetected: counts.competitors,
    newPrivateSourcesDetected: counts.newPrivateSources,
    reason,
    updatedAt: new Date().toISOString()
  });

  async function processSource(source, index) {
    const sourceLabel = source.name || source.url || `source ${index + 1}`;
    const tabActivationPlan = collectionTabActivationPlan(job, source);
    const tabActivationMode = tabActivationPlan.mode;
    const capabilityId = String(source.capability || "");
    const requiredFeature = SoloEntitlement.featureFor(capabilityId);
    const featureGranted = SoloEntitlement.granted(entitlement, capabilityId, source);
    await postToBridge(bridgeBaseUrl, token, "/collect/source_status", {
      run_id: runId,
      client_slug: job.client_slug || binding.client_slug || "",
      source_name: source.name || "",
      source_url: source.url || "",
      platform: source.platform || "",
      status: "started",
      tab_activation_mode: tabActivationMode,
      window_focus_requested: tabActivationPlan.focusWindow,
      tab_create_active: tabActivationPlan.createActive,
      tab_update_active: tabActivationPlan.updateActive,
      window_focus_policy: tabActivationPlan.focusWindow ? "focus_window" : "keep_window_background",
      capture_overlay: tabActivationMode !== "background_tab",
      index: index + 1,
      total: selectedSources.length,
      source_concurrency: sourceConcurrency,
      captured_at: new Date().toISOString(),
      collector_identity: "chrome-extension-local-collector",
      solo_entitlement: Object.assign({ needs_feature: requiredFeature, granted: featureGranted }, entitlementView)
    }, binding);

    // Paid capability without a verified token carrying its feature: skip (enforce) or just
    // record it (log-only). The skip is reported as its own status so consumers never mistake a
    // plan limit for a broken collector, and the operator sees WHY in the popup.
    if (requiredFeature && !featureGranted) {
      const why = `solo_entitlement_required: ${capabilityId} needs the "${requiredFeature}" feature (this install: ${entitlementView.tier}, ${entitlementView.source}). Upgrade at ${SoloEntitlement.UPGRADE_URL}. Circumventing this limit is not permitted under the Elastic License 2.0.`;
      if (SoloEntitlement.ENFORCE) {
        await postToBridge(bridgeBaseUrl, token, "/collect/source_status", {
          run_id: runId,
          client_slug: job.client_slug || binding.client_slug || "",
          source_name: source.name || "",
          source_url: source.url || "",
          platform: source.platform || "",
          status: "skipped",
          blocker: "solo_entitlement_required",
          issue: why,
          upgrade_url: SoloEntitlement.UPGRADE_URL,
          solo_entitlement: Object.assign({ needs_feature: requiredFeature, granted: false }, entitlementView),
          index: index + 1,
          total: selectedSources.length,
          captured_at: new Date().toISOString(),
          collector_identity: "chrome-extension-local-collector"
        }, binding);
        await setState({
          status: "running",
          message: `Skipped ${index + 1}/${selectedSources.length} (${capabilityId} needs "${requiredFeature}"): ${sourceLabel}`,
          runId,
          currentSource: sourceLabel,
          entitlement: entitlementView,
          entitlementNote: why,
          updatedAt: new Date().toISOString()
        });
        return;
      }
      console.warn("[solo-entitlement] log-only:", why);
      await setState({ entitlementNote: why, entitlement: entitlementView });
    }

    await setState({
      status: "running",
      message: `Collecting ${index + 1}/${selectedSources.length}: ${sourceLabel}`,
      runId,
      currentSource: sourceLabel,
      sourceConcurrency,
      currentScroll: 0,
      maxScrolls: Number(job.pacing?.scroll_steps || settings.scrollSteps || 5),
      dataPointsCollected: counts.dataPoints,
      competitorsDetected: counts.competitors,
      newPrivateSourcesDetected: counts.newPrivateSources,
      updatedAt: new Date().toISOString()
    });

    await delay(randomDelayMs(settings, pacing));

    // Last check before the expensive part. The pacing delay above is several seconds long, which
    // is exactly when an operator watching the overlay decides to stop — checking only at the top
    // of the loop would let one more page load anyway.
    if (await cancelledNow()) {
      await reportCancelledSource(index, "cancelled before the page was opened");
      return;
    }

    try {
      const collected = await collectSource(source, job, settings, binding, index + 1);
      await postToBridge(bridgeBaseUrl, token, "/collect/data_point", collected.dataPoint, binding);
      counts.dataPoints += 1;
      if (isCompetitorSource(source)) {
        await postToBridge(bridgeBaseUrl, token, "/collect/competitor", {
          run_id: runId,
          client_slug: job.client_slug || binding.client_slug || "",
          source_name: source.name || "",
          source_url: source.url || "",
          platform: source.platform || "",
          competitor_type: source.competitor_type || "unknown",
          name_or_page: source.name || collected.dataPoint.title || "",
          profile_url: collected.dataPoint.profile_url || source.url || "unavailable",
          post_url: collected.dataPoint.post_url || collected.dataPoint.current_url || "unavailable",
          current_url: collected.dataPoint.current_url || "",
          location_relevance: source.location_relevance || "",
          audience_overlap: source.audience_overlap || "",
          offer_positioning: "",
          content_themes: "",
          engagement_signal: collected.dataPoint.engagement_hint || "",
          threat_level: "unknown",
          opportunity: "AI agent should review this competitor source and derive positioning opportunities.",
          captured_at: new Date().toISOString(),
          collector_identity: "chrome-extension-local-collector"
        }, binding);
        counts.competitors += 1;
      }
      for (const candidate of collected.newPrivateSources || []) {
        await postToBridge(bridgeBaseUrl, token, "/collect/new_private_source", candidate, binding);
        counts.newPrivateSources += 1;
      }
      // A source can now finish without one — a run that never reached the site has nothing to
      // snapshot. Posting null here would write an empty snapshot record for a page that was
      // never seen.
      if (collected.snapshot) {
        await postToBridge(bridgeBaseUrl, token, "/collect/snapshot", collected.snapshot, binding);
      }
      await postToBridge(bridgeBaseUrl, token, "/collect/source_status", {
        run_id: runId,
        client_slug: job.client_slug || binding.client_slug || "",
        source_name: source.name || "",
        source_url: source.url || "",
        platform: source.platform || "",
        status: "collected",
        tab_activation_mode: tabActivationMode,
        window_focus_requested: tabActivationPlan.focusWindow,
        tab_create_active: tabActivationPlan.createActive,
        tab_update_active: tabActivationPlan.updateActive,
        window_focus_policy: tabActivationPlan.focusWindow ? "focus_window" : "keep_window_background",
        capture_overlay: tabActivationMode !== "background_tab",
        index: index + 1,
        total: selectedSources.length,
        source_concurrency: sourceConcurrency,
        current_url: collected.dataPoint.current_url || "",
        post_url: collected.dataPoint.post_url || collected.dataPoint.current_url || "",
        profile_url: collected.dataPoint.profile_url || "",
        captured_at: new Date().toISOString(),
        collector_identity: "chrome-extension-local-collector"
      }, binding);
      await setState({
        status: "running",
        message: `Collected ${index + 1}/${selectedSources.length}: ${sourceLabel}`,
        runId,
        currentSource: sourceLabel,
        sourceConcurrency,
        currentScroll: collected.dataPoint.scroll_count || 0,
        maxScrolls: collected.dataPoint.max_scrolls || 0,
        dataPointsCollected: counts.dataPoints,
        competitorsDetected: counts.competitors,
        newPrivateSourcesDetected: counts.newPrivateSources,
        updatedAt: new Date().toISOString()
      });
    } catch (error) {
      // A cancel CLOSES the tab, and everything the source was waiting on then rejects — the
      // capture comes back as "No tab with id: 1280133336". That is the cancel working, not the
      // collector breaking, and it lands here in the ordinary error path.
      //
      // Measured live 2026-09-07: a run stopped from the overlay filed its in-flight source as
      // status:"error". The guard that exists for a source cancelled BEFORE its page opened does
      // not cover this one, which is the common case — an operator stops a run because something
      // is ON SCREEN, so there is always a source mid-flight. Consumers scan source_status.jsonl
      // for failures (the harvest loop does exactly that), so a deliberate stop was being counted
      // as a broken collector, and enough of them blow a fuse over a profile nobody has a problem
      // with.
      if (cancelAppliesTo(runId, runStartedAt)) {
        cancelledDuring.add(index);
        // This path can run BEFORE the worker loop's own check, so cancelledBy may still be
        // unset — and then the row lands saying the stop was requested by "unknown", which is
        // the one field an operator reads to answer "who stopped my run?". Measured live: the
        // cancel came from the overlay and the record said unknown.
        if (!cancelledBy && cancelRequest) {
          cancelledBy = { reason: cancelRequest.reason, requestedBy: cancelRequest.requestedBy };
        }
        await reportCancelledSource(index, "cancelled mid-collection: " + String(error && error.message ? error.message : error));
        return;
      }
      await postToBridge(bridgeBaseUrl, token, "/collect/source_status", {
        run_id: runId,
        client_slug: job.client_slug || binding.client_slug || "",
        source_name: source.name || "",
        source_url: source.url || "",
        platform: source.platform || "",
        status: "error",
        tab_activation_mode: tabActivationMode,
        window_focus_requested: tabActivationPlan.focusWindow,
        tab_create_active: tabActivationPlan.createActive,
        tab_update_active: tabActivationPlan.updateActive,
        window_focus_policy: tabActivationPlan.focusWindow ? "focus_window" : "keep_window_background",
        capture_overlay: tabActivationMode !== "background_tab",
        issue: String(error && error.message ? error.message : error),
        index: index + 1,
        total: selectedSources.length,
        source_concurrency: sourceConcurrency,
        captured_at: new Date().toISOString(),
        collector_identity: "chrome-extension-local-collector"
      }, binding);
    }
  }

  let nextIndex = 0;
  let sourcesDone = 0;
  let cancelledBy = null;
  // Sources the cancel interrupted. They are neither done nor failed, and counting them as
  // either makes "stopped after 2 of 6" read wrong in the completion report.
  const cancelledDuring = new Set();
  const workerCount = Math.max(1, sourceConcurrency);

  // One place decides whether this run should stop, so a local click and a bridge-side cancel are
  // honoured identically. The remote check costs one small GET per source, which is nothing beside
  // a page capture, and it is skipped entirely once a cancel is already known.
  async function cancelledNow() {
    if (cancelAppliesTo(runId, runStartedAt)) {
      cancelledBy = cancelledBy || { reason: cancelRequest.reason, requestedBy: cancelRequest.requestedBy };
      return true;
    }
    const remote = await remoteCancelRequested(bridgeBaseUrl, runId);
    if (remote) {
      // Adopt it locally so the tabs get closed too — a bridge-side cancel must interrupt the
      // source in flight, not merely stop the next one from starting.
      await requestCancel({ runId, reason: remote.reason, requestedBy: remote.requestedBy });
      cancelledBy = remote;
      return true;
    }
    return false;
  }

  // A stopped source is NOT a failed one. Reporting it as "error" would make every consumer that
  // scans source_status.jsonl for failures — the harvest loop does exactly that — read a
  // deliberate stop as a broken collector, and eventually blow a fuse over it.
  async function reportCancelledSource(index, note) {
    const source = selectedSources[index] || {};
    await postToBridge(bridgeBaseUrl, token, "/collect/source_status", {
      run_id: runId,
      client_slug: job.client_slug || binding.client_slug || "",
      source_name: source.name || "",
      source_url: source.url || "",
      platform: source.platform || "",
      status: "cancelled",
      issue: note,
      cancel_reason: (cancelledBy && cancelledBy.reason) || "cancelled",
      cancel_requested_by: (cancelledBy && cancelledBy.requestedBy) || "unknown",
      index: index + 1,
      total: selectedSources.length,
      captured_at: new Date().toISOString(),
      collector_identity: "chrome-extension-local-collector"
    }, binding);
  }

  const workers = Array.from({ length: workerCount }, async () => {
    while (nextIndex < selectedSources.length) {
      if (await cancelledNow()) return;
      const index = nextIndex;
      nextIndex += 1;
      const source = selectedSources[index];
      await processSource(source, index);
      if (!cancelledDuring.has(index)) sourcesDone += 1;
    }
  });
  await Promise.all(workers);

  const wasCancelled = !!cancelledBy;
  // The bridge used to be told "completed" no matter what, so a run that stopped after 3 of 20
  // sources was indistinguishable at the file level from one that finished all 20. A cancel makes
  // that gap impossible to ignore, so the completion now carries what actually happened.
  await postToBridge(bridgeBaseUrl, token, "/complete", {
    run_id: runId,
    client_slug: job.client_slug || binding.client_slug || "",
    status: wasCancelled ? "cancelled" : "completed",
    cancelled: wasCancelled,
    cancel_reason: wasCancelled ? cancelledBy.reason : "",
    cancel_requested_by: wasCancelled ? cancelledBy.requestedBy : "",
    sources_done: sourcesDone,
    sources_interrupted: cancelledDuring.size,
    sources_total: selectedSources.length,
    completed_at: new Date().toISOString(),
    collector_identity: "chrome-extension-local-collector"
  }, binding);

  if (wasCancelled) await clearCancelRequest();

  await setState({
    status: wasCancelled ? "cancelled" : "completed",
    message: wasCancelled
      ? `Cancelled run ${runId} after ${sourcesDone}/${selectedSources.length} sources: ${cancelledBy.reason}`
      : `Completed run ${runId}.`,
    runId,
    totalSources: selectedSources.length,
    sourcesDone,
    cancelled: wasCancelled,
    cancelReason: wasCancelled ? cancelledBy.reason : "",
    dataPointsCollected: counts.dataPoints,
    competitorsDetected: counts.competitors,
    newPrivateSourcesDetected: counts.newPrivateSources,
    updatedAt: new Date().toISOString()
  });
}

// Phase 1 hybrid capture (Facebook GraphQL) is ADDITIVE and ON by default.
// Disable per job/config with collector_policy.graphql_capture=false (or a
// top-level graphql_capture=false). When off, collection behaves exactly as
// before this feature existed.
function graphqlCaptureEnabled(job) {
  if (!job || typeof job !== "object") return true;
  if (job.graphql_capture === false) return false;
  if (job.collector_policy && job.collector_policy.graphql_capture === false) return false;
  return true;
}

// A bare `profile.php` (no id), `/me`, etc. resolve to the LOGGED-IN operator,
// not the target — collecting it would pollute leads with the operator's own
// profile. Reject before navigating so the source errors cleanly instead.
// A reel URL opens Facebook's immersive player: scrolling there NAVIGATES to the next
// recommended reel (the address bar changes), so the page must be read without scrolling.
function isImmersivePlayerUrl(rawUrl) {
  return /facebook\.com\/reel\/\d+/i.test(String(rawUrl || ""));
}
// The single item a URL pins to, so we can tell whether the page we actually read is
// still the page that was requested.
function pinnedItemId(rawUrl) {
  // Every CONTENT url shape a seed can take, not just reels: a post/permalink/story seed
  // used to get no drift check at all, so a job that came back with some other tab's
  // content still reported `url_drifted: false` and its hooks could be attributed to the
  // wrong item. Post ids are `pfbid…` (letters+digits), which a digits-only pattern also
  // missed. PROFILE urls are deliberately not pinned: `profile.php?id=<n>` legitimately
  // redirects to the vanity name, and landing on the wrong profile is what
  // `landed_on_self` covers.
  const url = String(rawUrl || "");
  const patterns = [
    /\/reel\/([A-Za-z0-9]+)/,
    /[?&]v=([A-Za-z0-9]+)/,
    /\/videos\/([A-Za-z0-9]+)/,
    /\/posts\/([A-Za-z0-9]+)/,
    /[?&]story_fbid=([A-Za-z0-9]+)/,
    /\/permalink\/([A-Za-z0-9]+)/,
    /[?&]fbid=([A-Za-z0-9]+)/
  ];
  for (const pattern of patterns) {
    const m = url.match(pattern);
    if (m && m[1] && m[1].length >= 6) return m[1];
  }
  return "";
}

function isSelfOrAmbiguousFbUrl(rawUrl) {
  let u;
  try { u = new URL(String(rawUrl)); } catch (e) { return false; }
  if (!/(^|\.)facebook\.com$/i.test(u.hostname)) return false;
  const path = u.pathname.replace(/\/+$/, "").toLowerCase();
  if (path === "/profile.php" && !u.searchParams.get("id")) return true; // the reported bug
  if (path === "/me") return true;
  return false;
}

// A match_text write resolves its target from the PAGE's own feed payload, then this
// layer navigates the tab there. That makes the url attacker-influencable content, so the
// host is checked against an allowlist rather than a /facebook\.com$/ pattern — which
// would also admit l.facebook.com, the link shim that forwards anywhere off-platform.
// gql_actions.js applies the same allowlist in-page; this is the second, independent gate.
// The hosts are the Facebook module's own declaration (core/platform_registry.js), the same
// list gql_actions.js applies in-page.
const FB_PERMALINK_HOSTS = new Set(SoloPlatforms.moduleForHost("www.facebook.com").hosts);
function safeFacebookPermalink(rawUrl) {
  const s = String(rawUrl || "").trim();
  if (!/^https?:\/\//i.test(s)) return "";
  try {
    const u = new URL(s);
    if (!FB_PERMALINK_HOSTS.has(u.hostname.toLowerCase())) return "";
    return u.href;
  } catch (e) { return ""; }
}

async function collectSource(source, job, settings, binding, sourceIndex) {
  if (!source.url || !/^https?:\/\//i.test(source.url)) {
    throw new Error("source url must start with http:// or https://");
  }
  // A self-target write (the registry's selfTarget set, e.g. a post on the operator's own
  // timeline) WANTS the url that resolves to the logged-in operator; the guard is for reads
  // and writes that name somebody else.
  if (isSelfOrAmbiguousFbUrl(source.url) && !SoloPlatforms.selfTarget().has(String(source.capability || ""))) {
    throw new Error(
      "ambiguous Facebook URL resolves to the logged-in operator, not the target: " +
      source.url + " — use profile.php?id=<numeric_id> or the vanity URL facebook.com/<username>"
    );
  }

  const activateCollectionTab = shouldActivateCollectionTab(job, source);
  const captureOverlayText = collectorCaptureOverlayText(job, binding);
  const captureOverlayScope = {
    client: String(job?.client_name || binding?.client_name || job?.client_slug || binding?.client_slug || "").trim(),
    campaign: collectorCaptureOverlayCampaign(job, source),
    runId: String(job?.run_id || "")
  };
  const tabActivationPlan = collectionTabActivationPlan(job, source);
  // The capability's platform module (core/platform_registry.js) decides three things below:
  // whether the page scrolls (info_only), which MAIN-world libraries are injected, and
  // whether a human gate guards the load. "zillow" names the PerimeterX Press & Hold gate,
  // the only gate implemented today; a module opts in by declaring human_gate: "zillow".
  const capabilityId = source.capability ? String(source.capability) : "";
  const capModule = capabilityId ? SoloPlatforms.moduleForCapability(capabilityId) : null;
  const dispatchModule = capabilityId ? SoloPlatforms.dispatchModuleFor(capabilityId) : null;
  const isZillowCapability = !!(capModule && capModule.human_gate === "zillow");
  const gateContext = { job, source, settings, binding, sourceIndex };
  let humanGate = null;
  const tab = await createTab({ url: source.url, active: tabActivationPlan.createActive });
  // Registered BEFORE any await on it: this is the handle a cancel uses to interrupt whatever
  // this source is waiting on, and a cancel arriving one line later must still find it.
  if (tab && typeof tab.id === "number") activeRunTabs.set(tab.id, String(job?.run_id || ""));
  try {
    if (activateCollectionTab) {
      await activateTab(tab, tabActivationPlan);
    }
    const loadReason = await waitForTabLoad(tab.id, 25000);
    // Before anything reads the page, establish whether the navigation reached the site at all.
    // A network drop must be reported as a NETWORK fact, not as an empty profile: the harvest
    // ledger quarantines the Facebook account for three consecutive failures, and a dropped
    // connection produces exactly that on all three collectors at once.
    const reach = await pageReachability(tab);
    if (!reach.reachable) {
      const dp = {
        object: "collector_data_point", record_type: "data_point",
        run_id: String(job.run_id || ""), client_slug: String(job.client_slug || binding?.client_slug || ""),
        source_index: sourceIndex, source_name: source.name || "", source_url: source.url,
        current_url: source.url, capability: String(source.capability || ""),
        captured_at: new Date().toISOString(), read_only: true,
        tab_load: loadReason, source_login_status: "unknown",
        records: {
          available: true, capability: String(source.capability || ""), count: 0, items: [{
            capability: String(source.capability || ""), status: "network_unavailable", verified: false,
            error: "the machine could not reach the site (" + reach.reason + (reach.detail ? ": " + reach.detail : "") + ")"
          }],
          status: "network_unavailable", reason: reach.reason
        }
      };
      // Returned, not posted: collectSource hands its data point to the caller, which owns the
      // bridge url and the token. Posting from here would need both threaded in for one branch.
      return { dataPoint: dp, snapshot: null, newPrivateSources: [] };
    }
    // Zillow may answer the navigation with its PerimeterX "Press & Hold" page instead of the
    // content. Wait for the OPERATOR to pass it (chime + tab to front + heartbeat), then go on
    // as if nothing happened — see zillowHumanGate. Nothing is solved or retried by code.
    if (isZillowCapability) {
      humanGate = await zillowHumanGate(tab, gateContext);
    }
    if (activateCollectionTab) {
      await installCollectorCaptureOverlayOnTab(tab, captureOverlayText, captureOverlayScope);
    }
    await delay(randomDelayMs(settings, job.pacing || {}));
    // Inject the cleaning pipeline (filtering.js + helpers), then run the
    // scroll/capture orchestrator. Same data_point envelope as before; the text
    // fields now carry the cleaned extraction instead of the raw innerText blob.
    await withTimeout(
      chrome.scripting.executeScript({ target: { tabId: tab.id }, files: CAPTURE_FILES }),
      20000,
      "inject_capture_files_timeout_needs_site_access"
    );
    // Write actions must NOT pre-scroll: on a reels/immersive player, scrolling
    // ADVANCES to the next (recommended) reel, drifting the write off-target; on
    // a permalink it just wastes time. Force 0 scroll steps for write actions.
    const WRITE_ACTIONS = SoloPlatforms.writeActions();
    const wantAction = !!source.capability && WRITE_ACTIONS.has(String(source.capability));
    // Content-addressed targeting: the job names the post by TEXT and points `url` at a
    // listing (group feed / profile timeline) instead of a permalink. The match is made in
    // code by gql_actions.js, then THIS layer navigates to the winner — the resolver must
    // never act where it searched, because a feed carries one composer per post.
    const MATCH_RESOLVABLE = SoloPlatforms.matchResolvable();
    const sourceInputs = source.inputs && typeof source.inputs === "object" ? source.inputs : {};
    const wantMatchResolve = wantAction
      && MATCH_RESOLVABLE.has(String(source.capability))
      && !!String(sourceInputs.match_text || "").trim();
    // A single-reel URL opens the IMMERSIVE PLAYER, where a scroll is a NAVIGATION:
    // it advances to the next recommended reel and rewrites the address bar. Reading
    // such a page after scrolling captures a DIFFERENT creator's reel — measured 5/5
    // (100%) drift on enrich runs that opened a reel to identify its owner. So a reel
    // player must not be scrolled on the READ path either, not just for write actions.
    // Profile-INFO capabilities answer "who is this / how do I reach them" from the
    // header, bio and About tabs. Scrolling only pulls in POSTS they never read, which
    // costs ~5 extra scroll cycles and a burst of GraphQL feed requests per profile —
    // pure waste and needless rate-limit exposure on a big email dig. Separate the job
    // kinds explicitly: info tasks never scroll for content.
    // Zillow capabilities read the page's Next.js state, which is complete at load; scrolling
    // adds nothing but time and bot-check exposure — the registry marks that whole module
    // info_only, so one lookup covers both lists.
    const infoOnly = !!capabilityId && SoloPlatforms.isInfoOnly(capabilityId);
    // A match_text write STARTS on a listing page, and that listing is exactly what has to
    // scroll: Facebook only fires the feed GraphQL query the resolver reads once the feed
    // moves. The reason writes never scroll is the reel player, where a scroll is a
    // NAVIGATION to the next recommended reel — that hazard belongs to the target page, and
    // the resolver never writes on the page it scrolled. Immersive players stay excluded.
    const noScrollTarget = (wantAction && !wantMatchResolve) || infoOnly || isImmersivePlayerUrl(source.url);
    const discoveryMode = isDiscoveryCollection(job, source);
    const maxScrollSteps = noScrollTarget ? 0 : maxScrollStepsForCollection(job, source);
    // NOTE: `||` would swallow an explicit 0 (a job asking for "no scrolling" silently
    // got the default 5) — read the number, then fall back only when it is absent.
    const requestedScroll = Number(job.pacing?.scroll_steps);
    const collectOptions = {
      scrollSteps: noScrollTarget ? 0 : (Number.isFinite(requestedScroll) ? requestedScroll : Number(settings.scrollSteps || 5)),
      maxScrollSteps,
      scrollMode: discoveryMode ? "discovery" : "standard",
      stopAfterNoMoveScrolls: discoveryMode ? 3 : 0,
      minDelaySeconds: Number(job.pacing?.min_delay_seconds || settings.minDelaySeconds || 5),
      maxDelaySeconds: Number(job.pacing?.max_delay_seconds || settings.maxDelaySeconds || 5)
    };
    const captureTimeoutMs = captureTimeoutMsForCollection(job, source, settings, collectOptions);
    const [result] = await withTimeout(chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: collectCleanPage,
      args: [collectOptions]
    }), captureTimeoutMs, "capture_timeout_needs_visible_collector_window_or_site_access");

    const cap = result && result.result ? result.result : {};

    // PHASE 1 hybrid: additively read Facebook's internal GraphQL captures that
    // gql_intercept.js recorded in the MAIN world while the page was scrolling.
    // This is purely additive: results go ONLY into new graphql_* fields below;
    // every existing HTML-derived field is untouched. On any failure, or on a
    // non-Facebook page, we simply skip and behave exactly as before.
    let gql = null;
    let gqlRecords = null;
    const isFbPage = /facebook\.com/i.test(String(source.url || cap.url || ""));
    const wantCapability = !!source.capability;
    // Inject the extractor library when we need the Facebook GraphQL layer (FB
    // pages) OR when a capability is requested. Capabilities can be DOM-based and
    // run on ANY site (e.g. web.search on DuckDuckGo, fb.reels.feed), so the
    // dispatch must NOT be gated behind Facebook GraphQL availability. The lib
    // reads window.__soloGql only lazily inside GraphQL extractors, so injecting
    // it on a non-Facebook page is safe.
    // Write actions (react/comment/DM) drive the real UI via DOM through a
    // separate lib. Approval is handled upstream by the daily report — a created
    // job is meant to execute — so this path is not gated on GraphQL capture.
    // (WRITE_ACTIONS / wantAction are defined above so the capture can skip scroll.)
    if ((graphqlCaptureEnabled(job) && (isFbPage || wantCapability)) || wantAction) {
      try {
        if (wantAction) {
          // Surface action failures instead of letting them fall through as a
          // silent null (which reads as "nothing happened" in the report).
          try {
            // Pass the REQUESTED url so the action can verify the page didn't get
            // redirected to different content before it writes (FB reels/permalinks
            // can drift to a recommended item; a write must never hit the wrong one).
            let actionInputs = Object.assign({}, sourceInputs, { _target_url: String(source.url || "") });
            // A DIRECT permalink write (no match_text) had no drift guard at all:
            // driftInfo() pins on targetIdFrom(), which recognises NUMERIC ids only,
            // so a `pfbid…` permalink pinned nothing and every page passed. A deleted
            // post redirects to the group feed, findCommentBox takes the topmost
            // composer, and the comment lands under a stranger's post reporting
            // verified:true. The requested url IS the pin on this path, so say so and
            // let resolvedDrift() — which understands pfbid — do its job. Scoped to the
            // page-surface writes; fb.message.send has its own thread-identity guard.
            const PIN_TARGET = SoloPlatforms.pinTarget();
            if (wantAction && !wantMatchResolve && PIN_TARGET.has(String(source.capability))) {
              actionInputs._resolved_url = String(source.url || "");
            }
            let resolvedMatch = null;
            let refusal = null;
            // collector_policy used to be advertised as a guard and read by nothing but
            // graphql_capture. Enforce it here: the bridge mints the permission from the
            // job's own sources, so a legitimate write arrives with its flag cleared and
            // a discovery job's blanket deny finally means something. Checked BEFORE the
            // resolve phase, so a forbidden write never even navigates.
            const POLICY_FLAG = SoloPlatforms.policyFlags();
            const denyFlag = POLICY_FLAG[String(source.capability)];
            if (denyFlag && job.collector_policy && job.collector_policy[denyFlag] === true) {
              refusal = { available: true, capability: String(source.capability), status: "policy_refused",
                count: 1, items: [{ capability: String(source.capability), status: "policy_refused",
                  verified: false, error: "collector_policy." + denyFlag + " forbids this write — nothing was done" }] };
            }

            if (!refusal && wantMatchResolve) {
              // PHASE 1 — turn "the post that says X" into a permalink, in code. The listing
              // extractor lives in the READ lib, so both libs go into the page here.
              // __soloActResolve is a separate entry point from __soloActRun exactly so this
              // call is structurally incapable of writing on the listing page.
              // The GraphQL intercept only sees what Facebook FETCHES. The top of a feed is
              // server-rendered into the first document, so the newest posts — the ones worth
              // acting on — never appear in a capture: measured on the test group, the
              // listing returned two older posts while the newest was on screen the whole
              // time. filtering.js (already injected, ISOLATED world) reads the rendered feed
              // and pairs each permalink with its BODY, stopping at the first comment
              // boundary. Reuse it rather than re-scraping in the MAIN world, where a
              // hand-rolled scan mistook a comment's article for its post. The two worlds
              // share only the DOM, so the array has to be relayed through here.
              // The resolver reads the listing through GraphQL only. A rendered-feed source
              // was relayed in here for a day and has been removed: it existed to recover a
              // post GraphQL "could not see", and that premise proved wrong — the missing post
              // was ANONYMOUS, which Facebook does not serve through the group feed query at
              // all. What it did add was mispairing, because a comment's article carries the
              // POST's permalink. gql_extract's own ensureCapture already waits and nudges the
              // page when a capture has not arrived yet, so nothing here needs to poll for it.
              await withTimeout(chrome.scripting.executeScript({
                target: { tabId: tab.id }, world: "MAIN", files: SoloPlatforms.dispatchFilesFor(capabilityId, { write: false })
              }), 8000, "inject_gql_extract_timeout");
              await withTimeout(chrome.scripting.executeScript({
                target: { tabId: tab.id }, world: "MAIN", files: SoloPlatforms.dispatchFilesFor(capabilityId, { write: true })
              }), 8000, "inject_gql_actions_timeout");
              const [rres] = await withTimeout(chrome.scripting.executeScript({
                target: { tabId: tab.id },
                world: "MAIN",
                func: async (capId, capInputs, entry) => (entry && typeof window[entry] === "function" ? await window[entry](capId, capInputs) : { __nolib: true }),
                args: [capabilityId, actionInputs, SoloPlatforms.dispatchEntryFor(capabilityId, "resolve")]
              }), 60000, "gql_action_resolve_timeout");
              const rr = rres && rres.result;
              const rItem = rr && Array.isArray(rr.items) ? rr.items[0] : null;
              const targetUrl = rItem && rItem.matched_post ? safeFacebookPermalink(rItem.matched_post.url) : "";

              if (!rr || rr.__nolib) {
                refusal = { available: false, capability: String(source.capability), count: 0, items: [{ status: "error", error: "resolve lib not present (frame navigated before inject?)" }], _debug: { href: source.url } };
              } else if (rr.status !== "resolved") {
                // no_match / ambiguous_match / listing_unavailable: a deliberate refusal, and
                // WHY nothing was written is the entire value of the record. Return verbatim.
                refusal = rr;
              } else if (!targetUrl) {
                if (rItem) {
                  rItem.status = "error";
                  rItem.error = "matched permalink rejected by the host allowlist: " + String((rItem.matched_post && rItem.matched_post.url) || "empty");
                }
                rr.status = "error";
                refusal = rr;
              } else {
                // PHASE 2 — navigate to the winner, then re-inject: a fresh document has no
                // lib. Subscribe to the load BEFORE asking for it; "complete" can fire before
                // a listener attached afterwards would ever see it.
                const navigated = waitForTabLoad(tab.id, 25000);
                await chrome.tabs.update(tab.id, { url: targetUrl });
                await navigated;
                await delay(randomDelayMs(settings, job.pacing || {}));
                resolvedMatch = rItem;
                // _resolved_url is the proof the write is running on the resolved permalink
                // and not on the listing; gql_actions.js refuses a match_text write without it.
                actionInputs = Object.assign({}, actionInputs, { _target_url: targetUrl, _resolved_url: targetUrl });
              }
            }

            if (refusal) {
              gqlRecords = refusal;
            } else {
              await withTimeout(chrome.scripting.executeScript({
                target: { tabId: tab.id },
                world: "MAIN",
                files: SoloPlatforms.dispatchFilesFor(capabilityId, { write: true })
              }), 8000, "inject_gql_actions_timeout");
              const [ares] = await withTimeout(chrome.scripting.executeScript({
                target: { tabId: tab.id },
                world: "MAIN",
                func: async (capId, capInputs, entry) => (entry && typeof window[entry] === "function" ? await window[entry](capId, capInputs) : { __nolib: true }),
                args: [capabilityId, actionInputs, SoloPlatforms.dispatchEntryFor(capabilityId, "act")]
              }), 60000, "gql_action_timeout");
              const ar = ares && ares.result;
              if (ar && ar.__nolib) gqlRecords = { available: false, capability: String(source.capability), count: 0, items: [{ status: "error", error: "action lib not present (frame navigated before inject?)" }], _debug: { href: source.url } };
              else gqlRecords = ar || { available: false, capability: String(source.capability), count: 0, items: [{ status: "error", error: "action returned no result" }], _debug: { href: source.url } };
              // Carry the resolution into the write's own record: which post was picked, out
              // of how many read, from which listing. That IS the audit trail for a write
              // whose target was chosen by the machine rather than named by the caller.
              if (resolvedMatch && gqlRecords && Array.isArray(gqlRecords.items) && gqlRecords.items[0]) {
                const written = gqlRecords.items[0];
                written.matched_post = resolvedMatch.matched_post;
                written.candidates_considered = resolvedMatch.candidates_considered;
                written.match_text = resolvedMatch.match_text;
                written.match_mode = resolvedMatch.match_mode;
                written.list_capability = resolvedMatch.list_capability;
                written.sources_read = resolvedMatch.sources_read;
                written.resolved_from = String(source.url || "");
              }
            }
          } catch (actErr) {
            gqlRecords = { available: false, capability: String(source.capability), count: 0, items: [{ status: "error", error: String(actErr && actErr.message || actErr) }], _debug: { href: source.url } };
          }
        } else {
          // The Facebook read library is injected on every read: besides its capabilities it
          // carries the generic GraphQL layer (graphql_records / graphql_manifest) every
          // Facebook page needs, and it reads window.__soloGql only lazily, so it is inert on
          // any other site. A known wart: that generic layer belongs in core, not in a module.
          const genericReadFiles = SoloPlatforms.dispatchFilesFor("", { write: false });
          await withTimeout(chrome.scripting.executeScript({
            target: { tabId: tab.id },
            world: "MAIN",
            files: genericReadFiles
          }), 8000, "inject_gql_extract_timeout");
          // The capability's own module library (zillow_extract.js today) when it is not the
          // one just injected — only that module's jobs load it, so no other path changes.
          const moduleReadFiles = capabilityId
            ? SoloPlatforms.dispatchFilesFor(capabilityId, { write: false }).filter((f) => genericReadFiles.indexOf(f) === -1)
            : [];
          if (moduleReadFiles.length) {
            await withTimeout(chrome.scripting.executeScript({
              target: { tabId: tab.id },
              world: "MAIN",
              files: moduleReadFiles
            }), 8000, "inject_module_lib_timeout");
          }
          // Facebook-only generic layer (graphql_records + graphql_manifest).
          if (isFbPage) {
            const [gres] = await withTimeout(chrome.scripting.executeScript({
              target: { tabId: tab.id },
              world: "MAIN",
              func: () => (typeof window.__soloGqlExtract === "function" ? window.__soloGqlExtract({}) : null)
            }), 8000, "gql_extract_timeout");
            gql = gres && gres.result ? gres.result : null;
          }
          // Capability dispatch (GraphQL or DOM) — runs on any page. Typed output
          // lands in the new `records` field; additive and best-effort.
          if (wantCapability) {
            const runCapabilityDispatch = async () => {
              const capInputs = source.inputs && typeof source.inputs === "object" ? Object.assign({}, source.inputs) : {};
              const askedBudget = Number(capInputs.time_budget_ms);
              capInputs.time_budget_ms = Math.min(askedBudget > 0 ? askedBudget : Infinity, CAPABILITY_TIMEOUT_MS - CAPABILITY_BUDGET_MARGIN_MS);
              const [cres] = await withTimeout(chrome.scripting.executeScript({
                target: { tabId: tab.id },
                world: "MAIN",
                // The entry points come from the capability's module (core/platform_registry.js):
                // `run`, then `runFallback` when the module declares one. A module with a single
                // entry (zillow) whose library is missing reports a visible error record
                // (available:true) rather than falling through to another module's dispatcher,
                // whose "no_extractor" answer would null the record and hide the failure.
                func: async (capId, capInputs, runEntry, fallbackEntry, moduleName) => {
                  if (runEntry && typeof window[runEntry] === "function") return await window[runEntry](capId, capInputs);
                  if (fallbackEntry && typeof window[fallbackEntry] === "function") return window[fallbackEntry](capId, capInputs);
                  if (runEntry && !fallbackEntry) {
                    return { available: true, capability: String(capId), count: 0, status: "error", items: [{ capability: String(capId), status: "error", error: moduleName + " lib not present (" + runEntry + " missing; did its file fail to inject?)" }] };
                  }
                  return null;
                },
                args: [capabilityId, capInputs,
                  SoloPlatforms.dispatchEntryFor(capabilityId, "run"), SoloPlatforms.dispatchEntryFor(capabilityId, "runFallback"),
                  dispatchModule ? dispatchModule.name : ""]
              }), CAPABILITY_TIMEOUT_MS, "gql_capability_timeout");
              // executeScript can RESOLVE with nothing: the frame navigated or was destroyed while
              // the capability was running, so there is no result and no exception either. That
              // path used to return null, which the bridge writes as records:null — and the
              // harvest ledger then counts it as no_record, the same bucket as "read the page and
              // it was empty". Measured across 976 harvest runs: 101 failures, and every single
              // observable field on the data point was IDENTICAL to a success — tab mode, login
              // status, url_drifted, scroll_count, capture count, title. The record carried no
              // evidence at all, so the failure could not be diagnosed by anyone downstream and
              // was attributed to Facebook throttling for want of anything better.
              if (cres && cres.result) return cres.result;
              return {
                available: true, capability: String(source.capability), count: 0, items: [{
                  capability: String(source.capability), status: "error", verified: false,
                  error: cres
                    ? "capability returned no result (the page navigated or re-rendered while it ran)"
                    : "capability produced no frame result (the tab or frame went away mid-run)"
                }],
                _debug: { href: source.url, had_frame: !!cres }
              };
            };
            gqlRecords = await runCapabilityDispatch();
            // Zillow: the bot check can also land AFTER the pre-load gate (PerimeterX interposes
            // on a navigation the page made itself). The capability reports it as status
            // "blocked"; wait for the operator again, re-inject the lib (the check reloads the
            // document) and read the page once more. Bounded so a check that keeps coming back
            // ends as a blocked record instead of an endless loop.
            for (let attempt = 0; isZillowCapability && gqlRecords && gqlRecords.status === "blocked" && attempt < 2; attempt++) {
              const gate = await zillowHumanGate(tab, gateContext);
              humanGate = mergeHumanGate(humanGate, gate);
              if (!gate.solved) break;
              await withTimeout(chrome.scripting.executeScript({
                target: { tabId: tab.id }, world: "MAIN", files: SoloPlatforms.dispatchFilesFor(capabilityId, { write: false })
              }), 8000, "inject_module_lib_timeout");
              gqlRecords = await runCapabilityDispatch();
            }
            // Re-snapshot the generic GraphQL layer AFTER the capability ran. A capability that
            // has to trigger its own query (a friends list, a timeline, a search) fires it during
            // dispatch, so the manifest taken above never listed it — and the healthcheck's L1
            // sensor then read "no query containing Friends fired" over a record holding 24
            // friends read from exactly that query. Additive: same fields, a fuller list.
            if (isFbPage) {
              try {
                const [gres2] = await withTimeout(chrome.scripting.executeScript({
                  target: { tabId: tab.id },
                  world: "MAIN",
                  func: () => (typeof window.__soloGqlExtract === "function" ? window.__soloGqlExtract({}) : null)
                }), 8000, "gql_extract_timeout");
                if (gres2 && gres2.result) gql = gres2.result;
              } catch (e) { /* keep the pre-dispatch snapshot */ }
            }
          }
        }
      } catch (error) {
        // Best-effort: a failure here must never fail HTML collection. But it must not be
        // INVISIBLE either. This block used to swallow the error and leave gqlRecords null,
        // which the bridge then wrote as records:null — indistinguishable from "the capability
        // ran and found nothing". A slow DOM capability that blew the 45s dispatch timeout
        // therefore looked exactly like an empty profile. Say what happened instead.
        if (!gqlRecords && wantCapability) {
          gqlRecords = {
            available: true, capability: String(source.capability), count: 0, items: [{
              capability: String(source.capability), status: "error", verified: false,
              error: "capability did not complete: " + String(error && error.message || error)
            }], _debug: { href: source.url }
          };
        }
      }
      // --- Canonical layer (additive) --- the platform module's normalizer maps its typed
      // output into core/schema.js's shape and the result rides along as records.canonical.
      // Nothing already in `records` is renamed, removed or reshaped; a normalizer that is
      // missing, returns null (web.search) or throws leaves the record exactly as before.
      if (gqlRecords && wantCapability) attachCanonical(gqlRecords, String(source.capability));
    }
    // A platform module other than Facebook keeps its own capture ring (window.__soloIg,
    // window.__soloX). When the module declares a `manifest` entry, read it so the data
    // point's graphql_manifest — the healthcheck's query sensor and its repair hints — is
    // filled for that page too; when it declares a `login` entry, its own reading of the
    // logged-in state beats the page-text heuristic (a tweet saying "sign in" is not a wall).
    let moduleLogin = null;
    try {
      if (tab && wantCapability && dispatchModule && dispatchModule.entries) {
        const manifestEntry = dispatchModule.entries.manifest || null;
        const loginEntry = dispatchModule.entries.login || null;
        if (manifestEntry || loginEntry) {
          const [mres] = await withTimeout(chrome.scripting.executeScript({
            target: { tabId: tab.id },
            world: "MAIN",
            func: (mEntry, lEntry) => {
              const out = { manifest: null, login: null };
              try { if (mEntry && typeof window[mEntry] === "function") out.manifest = window[mEntry](); } catch (e) { out.manifest = null; }
              try { if (lEntry && typeof window[lEntry] === "function") out.login = window[lEntry](); } catch (e) { out.login = null; }
              return out;
            },
            args: [manifestEntry, loginEntry]
          }), 8000, "module_manifest_timeout");
          const mr = mres && mres.result ? mres.result : null;
          if (mr && mr.manifest && mr.manifest.available && !(gql && gql.available)) gql = mr.manifest;
          if (mr && typeof mr.login === "boolean") moduleLogin = mr.login;
        }
      }
    } catch (e) { /* additive evidence only */ }
    const gqlAvailable = !!(gql && gql.available);

    const now = new Date().toISOString();
    const runId = String(job.run_id || "");
    const maxChars = Number(job.pacing?.max_text_chars || settings.maxTextChars || 12000);
    const text = String(cap.mergedDisplay || cap.merged || "");
    const excerpt = text.slice(0, maxChars);
    const accountUrls = Array.isArray(cap.accountUrls) ? cap.accountUrls : [];
    const postUrls = Array.isArray(cap.postUrls) ? cap.postUrls : [];
    const entityItems = Array.isArray(cap.entityItems) ? cap.entityItems : [];
    const entityProfileUrls = entityItems
      .filter((it) => it && /profile|account/i.test(String(it.type || "")))
      .map((it) => it.url)
      .filter(Boolean);
    const profileCandidates = [];
    const seenProfileCandidates = new Set();
    for (const url of accountUrls.concat(entityProfileUrls)) {
      const key = canonicalSourceKey(url);
      if (!key || seenProfileCandidates.has(key)) continue;
      seenProfileCandidates.add(key);
      profileCandidates.push(url);
    }
    // Structured contacts parsed in-page from the already-captured public text +
    // mailto:/tel: anchors (additive optional field; empty arrays when none found).
    const contacts = cap.contacts && typeof cap.contacts === "object"
      ? {
          emails: Array.isArray(cap.contacts.emails) ? cap.contacts.emails : [],
          phones: Array.isArray(cap.contacts.phones) ? cap.contacts.phones : []
        }
      : { emails: [], phones: [] };
    const pageLike = {
      current_url: cap.url || "",
      title: cap.title || "",
      profile_candidates: profileCandidates,
      post_candidates: postUrls,
      entity_candidates: entityItems,
      raw_visible_text_excerpt: excerpt
    };
    const snapshotNonce = Math.random().toString(36).slice(2, 8);
    const snapshotFilename = `${safeSlug(runId || "run")}_${String(sourceIndex || 0).padStart(2, "0")}_${safeSlug(source.name || source.platform || "source")}_${Date.now()}_${snapshotNonce}.html`;

    return {
      dataPoint: {
        client_slug: job.client_slug || binding.client_slug || "",
        business_slug: job.business_slug || "",
        location_slug: job.location_slug || "",
        run_id: runId,
        extension_instance_id: binding.extension_instance_id || "",
        extension_display_name: binding.extension_display_name || "",
        source_name: source.name || "",
        source_url: source.url || "",
        source_type: source.source_type || source.type || "private",
        platform: source.platform || inferPlatform(source.url),
        priority: source.priority || "",
        scan_cadence: source.scan_cadence || "",
        purpose: source.purpose || "",
        source_index: sourceIndex || 0,
        current_url: cap.url || "",
        // True when the page we actually read is NOT the item that was requested (a
        // reel player can advance to a recommended reel). Everything below then
        // describes a DIFFERENT creator — consumers must reject the record, not use it.
        url_drifted: (() => {
          const want = pinnedItemId(source.url);
          return want ? !String(cap.url || "").includes(want) : false;
        })(),
        // True when Facebook fell back to the OPERATOR's own profile (malformed
        // profile URL / unsupported tab slug). Consumers must reject such a record:
        // its email/phone belong to the operator, not the lead.
        landed_on_self: !!cap.landedOnSelf,
        // For a reel: did the owner link ever render? false means the read was too
        // early (a RETRYABLE timing miss), not that the reel has no owner. Consumers
        // must requeue on false instead of concluding "unresolved".
        owner_resolution: /\/reel\/[A-Za-z0-9]+/.test(String(source.url || ""))
          ? (cap.ownerAffordanceSeen ? "resolved" : "retryable_not_rendered")
          : "n/a",
        // Audit trail for the contact-info dig: how many truncated blocks were
        // expanded and whether the About > Contact info sub-tab was opened. A record
        // with 0/false has NOT exhausted the page — do not conclude "no email".
        expanded_truncations: Number(cap.expandedTruncations || 0),
        opened_contact_tab: !!cap.openedContactTab,
        post_url: postUrls[0] || cap.url || "",
        profile_url: profileCandidates[0] || "",
        profile_candidates: profileCandidates,
        post_candidates: postUrls,
        entity_candidates: entityItems,
        title: cap.title || "",
        visible_text_summary: excerpt.slice(0, 1200),
        raw_visible_text_excerpt: excerpt,
        engagement_hint: extractEngagementHint(text),
        captured_at: now,
        source_login_status: moduleLogin === true ? "available" : (moduleLogin === false ? "logged_out" : detectLoginHint(text)),
        collector_identity: "chrome-extension-local-collector",
        confidence: text ? "medium" : "low",
        scroll_count: cap.scrollStepsUsed || 0,
        max_scrolls: cap.scrollStepsUsed || 0,
        scroll_debug: cap.scrollDebug || [],
        scroll_stopped_reason: cap.scrollStoppedReason || "",
        extraction_engine: cap.engine || "",
        tab_activation_mode: tabActivationPlan.mode,
        window_focus_requested: tabActivationPlan.focusWindow,
        tab_create_active: tabActivationPlan.createActive,
        tab_update_active: tabActivationPlan.updateActive,
        window_focus_policy: tabActivationPlan.focusWindow ? "focus_window" : "keep_window_background",
        capture_overlay: activateCollectionTab,
        capture_overlay_text: activateCollectionTab ? captureOverlayText : "",
        // Recorded as well as shown. The overlay answers "whose run is this" while it is on
        // screen; the data point answers it afterwards, which is when the question is usually
        // asked — several clients harvest at once and a stray record is hard to place later.
        overlay_client: captureOverlayScope.client,
        overlay_campaign: captureOverlayScope.campaign,
        read_only: true,
        // --- Phase 1 hybrid GraphQL layer (additive; null/empty when absent) ---
        graphql_available: gqlAvailable,
        graphql_capture_count: gql && typeof gql.captureCount === "number" ? gql.captureCount : 0,
        graphql_records: gqlAvailable ? { posts: gql.posts || [], entities: gql.entities || [] } : null,
        graphql_manifest: gqlAvailable ? (gql.manifest || []) : [],
        // --- Phase 2 capability layer (typed, per-screen; null when no capability) ---
        capability: source.capability || "",
        // A record that EXISTS is never discarded. Gating on `available` is what turned "the feed
        // did not render in a hidden tab" into records:null on seven capabilities at once, which
        // reads exactly like a crash. Only a genuinely absent result is null now.
        records: gqlRecords || null,
        // --- Structured contact layer (additive; emails/phones parsed from the
        // already-captured public page text + mailto:/tel: anchors) ---
        contacts: contacts,
        // --- Human gate (Zillow bot check) — present ONLY when a gate ran for this source:
        // {engaged, solved, waited_ms, wait_ceiling_minutes, ...}. engaged:false = the page
        // opened cleanly; solved:true = the operator passed the check and the read continued.
        ...(humanGate ? { human_gate: humanGate } : {})
      },
      newPrivateSources: entityItems
        .filter((it) => it && /group|community|page|channel|profile|account/i.test(String(it.type || "")))
        // DISCOVERY must keep ALL captured candidates (a big account can surface 100s of
        // groups) — the old hardcoded .slice(0, 20) silently dropped them, so the raw
        // entity_candidates held 152 while new_private_sources.jsonl got only 20. That 20
        // is NOT the monitoring cap (pacing.max_sources, which limits SOURCES scanned);
        // it was an incidental token-saving cap for normal runs. Keep a small cap only for
        // non-discovery collections; discovery keeps everything (override via max_candidates).
        .slice(0, discoveryMode
          ? Number(job.pacing?.max_candidates || settings.maxDiscoveryCandidates || 1000)
          : Number(job.pacing?.max_candidates || 20))
        .map((it) => ({
          run_id: runId,
          client_slug: job.client_slug || binding.client_slug || "",
          extension_instance_id: binding.extension_instance_id || "",
          extension_display_name: binding.extension_display_name || "",
          platform: source.platform || inferPlatform(source.url),
          source_type: String(it.type || "group"),
          source_name: it.name || it.url || "",
          profile_or_group_url: it.url || "unavailable",
          current_recommendation_url: cap.url || "unavailable",
          detected_while_scanning: source.name || source.url || "",
          why_relevant: "Visible platform recommendation collected for human review.",
          related_content_pillar: "",
          estimated_priority: "medium",
          suggested_scan_cadence: "weekly",
          status: "needs_human_review",
          captured_at: now,
          collector_identity: "chrome-extension-local-collector"
        })),
      snapshot: {
        run_id: runId,
        client_slug: job.client_slug || binding.client_slug || "",
        extension_instance_id: binding.extension_instance_id || "",
        extension_display_name: binding.extension_display_name || "",
        filename: snapshotFilename,
        source_name: source.name || "",
        source_url: source.url || "",
        current_url: cap.url || "",
        captured_at: now,
        html: buildSnapshotHTML({ source, job, page: pageLike, capturedAt: now })
      }
    };
  } finally {
    // A gate that engaged for this source must never leave the chime playing (error paths,
    // tab closed by the operator, dispatch timeout). Idempotent, per-source refcounted.
    if (isZillowCapability) {
      try { await operatorAlertRelease(gateContext); } catch (error) { /* ignore */ }
    }
    if (tab && typeof tab.id === "number") activeRunTabs.delete(tab.id);
    if (settings.closeTabsAfterCollect) {
      try {
        await chrome.tabs.remove(tab.id);
      } catch (error) {
        // Ignore tab close races.
      }
    }
  }
}


// ---------------------------------------------------------------------------------------------
// Operator alert + human gate. Today's only user is Zillow's PerimeterX "Press & Hold" bot check
// (ZILLOW_CAPABILITIES.md §5), but nothing here is Zillow-specific except the probe.
//
// The service worker cannot play audio and a tab the collector opened has had no user gesture
// (its AudioContext would stay suspended), so the chime is played by the extension's OFFSCREEN
// document (offscreen.html/js, permission "offscreen"), which is exempt from autoplay policy.
// The gate itself lives here in background.js because a capability injected into the page is
// killed after 45 s, while a human may take an hour: it polls the tab every 4 s, keeps the run
// alive on the bridge with a source_status heartbeat, and resumes the normal flow the moment
// the check is gone. Nothing solves, retries or spoofs the check — the operator does.
const OPERATOR_ALERT_MSG = "solo_operator_alert";
const operatorAlertHolders = new Set();

function operatorAlertKey(ctx) {
  return `${(ctx && ctx.job && ctx.job.run_id) || ""}#${(ctx && ctx.sourceIndex) || 0}#${(ctx && ctx.source && ctx.source.url) || ""}`;
}
async function ensureOffscreenDocument() {
  if (!(chrome.offscreen && typeof chrome.offscreen.createDocument === "function")) return false;
  try {
    if (typeof chrome.offscreen.hasDocument === "function" && await chrome.offscreen.hasDocument()) return true;
  } catch (error) { /* fall through and try to create */ }
  try {
    await chrome.offscreen.createDocument({
      url: "offscreen.html",
      reasons: ["AUDIO_PLAYBACK"],
      justification: "Plays a gentle repeating chime while a collection job waits for the operator to pass a site's human check (e.g. Zillow Press & Hold)."
    });
    return true;
  } catch (error) {
    // "Only a single offscreen document may be created" = it already exists → fine.
    return /single offscreen|already|exists/i.test(String(error && error.message || error));
  }
}
async function operatorAlertMessage(payload) {
  // The document may still be booting right after createDocument; a few short retries.
  let lastError = null;
  for (let i = 0; i < 6; i++) {
    try { return await chrome.runtime.sendMessage(Object.assign({ type: OPERATOR_ALERT_MSG }, payload)); }
    catch (error) { lastError = error; await delay(250); }
  }
  return { ok: false, error: String(lastError && lastError.message || lastError) };
}
async function operatorAlertAcquire(ctx, reason, detail) {
  operatorAlertHolders.add(operatorAlertKey(ctx));
  if (!(await ensureOffscreenDocument())) return { ok: false, error: "offscreen document unavailable (Chrome too old or permission missing)" };
  return operatorAlertMessage({ action: "start", reason, detail });
}
async function operatorAlertRelease(ctx) {
  operatorAlertHolders.delete(operatorAlertKey(ctx));
  if (operatorAlertHolders.size > 0) return { ok: true, still_held: operatorAlertHolders.size };
  const res = await operatorAlertMessage({ action: "stop" });
  try {
    if (chrome.offscreen && typeof chrome.offscreen.hasDocument === "function" && await chrome.offscreen.hasDocument()) {
      await chrome.offscreen.closeDocument();
    }
  } catch (error) { /* ignore */ }
  return res;
}

// Runs INSIDE the tab (serialized by chrome.scripting): is this the PerimeterX block page?
// Mirrors zillow_extract.js blockedReason() and the operator's gubo-browser detectCaptcha():
// a VISIBLE #px-captcha, the block page title, or a short document carrying the challenge text.
function zillowBotCheckProbe() {
  try {
    const px = document.querySelector("#px-captcha, #px-captcha-wrapper");
    if (px) {
      const r = typeof px.getBoundingClientRect === "function" ? px.getBoundingClientRect() : null;
      if (!r || r.width > 0 || r.height > 0 || px.offsetParent !== null) return { blocked: true, why: "px-captcha" };
    }
    if (/access to this page has been denied/i.test(String(document.title || ""))) return { blocked: true, why: "title" };
    const body = String((document.body && document.body.innerText) || "").trim();
    if (body.length < 2500) {
      const lower = body.toLowerCase();
      if (lower.indexOf("press & hold to confirm") !== -1 || lower.indexOf("press and hold to confirm") !== -1 || lower.indexOf("human verification challenge") !== -1) {
        return { blocked: true, why: "text" };
      }
    }
    return { blocked: false, why: "" };
  } catch (error) {
    return { blocked: false, why: "probe_error" };
  }
}
// → true | false | "loading" (document mid-navigation, ask again) | null (tab is gone)
async function zillowTabBlocked(tabId) {
  let tab = null;
  try { tab = await chrome.tabs.get(tabId); } catch (error) { return null; }
  try {
    const [res] = await withTimeout(chrome.scripting.executeScript({ target: { tabId }, func: zillowBotCheckProbe }), 8000, "bot_check_probe_timeout");
    return !!(res && res.result && res.result.blocked);
  } catch (error) {
    if (tab && tab.status === "loading") return "loading";
    return false;
  }
}
async function waitForTabSettled(tabId, timeoutMs) {
  const until = Date.now() + (timeoutMs || 20000);
  while (Date.now() < until) {
    try {
      const t = await chrome.tabs.get(tabId);
      if (t && t.status === "complete") return true;
    } catch (error) { return false; }
    await delay(500);
  }
  return false;
}
function mergeHumanGate(prev, next) {
  if (!prev) return next;
  if (!next) return prev;
  return Object.assign({}, prev, next, {
    engaged: !!(prev.engaged || next.engaged),
    waited_ms: Number(prev.waited_ms || 0) + Number(next.waited_ms || 0),
    gates: Number(prev.gates || 1) + 1
  });
}
// Wait until the tab is NOT on the bot-check page. Returns
//   { engaged, solved, waited_ms, wait_ceiling_minutes, alert }:
//   engaged:false            — the page opened cleanly, nothing happened (the common case)
//   engaged:true solved:true — the operator passed the check; the caller continues normally
//   engaged:true solved:false— the ceiling (pacing.zillow_human_wait_minutes / inputs.human_wait_minutes,
//                              default 360, max 1440) passed; the caller goes on and the
//                              capability will report status:"blocked" for this page.
// Throws only when the tab disappears (the operator closed it = "skip this one").
async function zillowHumanGate(tab, ctx) {
  const { job, source, settings, binding, sourceIndex } = ctx;
  const inputs = source && source.inputs && typeof source.inputs === "object" ? source.inputs : {};
  const waitMinutes = clampNumber(Number(inputs.human_wait_minutes || (job.pacing && job.pacing.zillow_human_wait_minutes) || 360), 1, 1440, 360);
  const maxWaitMs = waitMinutes * 60000;
  const runId = String(job.run_id || (job.collector_bridge && job.collector_bridge.run_id) || "");
  const bridgeBaseUrl = trimSlash(settings.bridgeBaseUrl);
  const token = job.collector_bridge && job.collector_bridge.write_token ? job.collector_bridge.write_token : "";
  const label = source.name || source.url || "";
  const info = { engaged: false, solved: null, waited_ms: 0, wait_ceiling_minutes: waitMinutes, alert: null };
  const started = Date.now();
  let lastHeartbeat = 0;
  const post = async (status, extra) => {
    if (!token) return;
    try {
      await postToBridge(bridgeBaseUrl, token, "/collect/source_status", Object.assign({
        run_id: runId, client_slug: job.client_slug || binding.client_slug || "",
        source_name: source.name || "", source_url: source.url || "", platform: source.platform || "",
        status, index: sourceIndex || 0, captured_at: new Date().toISOString(),
        collector_identity: "chrome-extension-local-collector"
      }, extra || {}), binding);
    } catch (error) { /* a briefly unreachable bridge must not end the wait */ }
  };
  for (;;) {
    const blocked = await zillowTabBlocked(tab.id);
    if (blocked === null) {
      if (info.engaged) await operatorAlertRelease(ctx);
      throw new Error("zillow tab closed while waiting for the operator to pass the bot check (closing the tab skips the source)");
    }
    if (blocked === false) break;
    if (blocked === "loading") { await delay(1500); continue; }
    if (!info.engaged) {
      info.engaged = true;
      // Bring the check in front of the operator ONCE (the chime says "look at Chrome").
      try { await chrome.tabs.update(tab.id, { active: true }); } catch (error) { /* ignore */ }
      try { await chrome.windows.update(tab.windowId, { focused: true, drawAttention: true }); } catch (error) { /* ignore */ }
      info.alert = await operatorAlertAcquire(ctx, "zillow_bot_check", { url: source.url || "", run_id: runId, source: label });
      await setState({
        status: "waiting_for_operator",
        message: `Zillow bot check — please Press & Hold in the Zillow tab (${label}). The collector resumes by itself when the page loads.`,
        runId, currentSource: label, updatedAt: new Date().toISOString()
      });
      await post("waiting_for_human_captcha", { message: "Zillow bot check (Press & Hold) — waiting for the operator; chime playing", waited_ms: 0, wait_ceiling_minutes: waitMinutes, alert: info.alert });
      lastHeartbeat = Date.now();
    } else if (Date.now() - lastHeartbeat >= 120000) {
      // Heartbeat: keeps the bridge's run alive (it extends the job's expiry on this status).
      await post("waiting_for_human_captcha", { message: "still waiting for the operator", waited_ms: Date.now() - started, wait_ceiling_minutes: waitMinutes });
      lastHeartbeat = Date.now();
    }
    if (Date.now() - started >= maxWaitMs) {
      info.solved = false;
      info.waited_ms = Date.now() - started;
      await operatorAlertRelease(ctx);
      await post("human_captcha_wait_expired", { waited_ms: info.waited_ms, wait_ceiling_minutes: waitMinutes });
      await setState({ status: "running", message: `Bot check not passed within ${waitMinutes} min — moving on (${label})`, runId, updatedAt: new Date().toISOString() });
      return info;
    }
    await delay(4000);
  }
  info.waited_ms = Date.now() - started;
  if (info.engaged) {
    info.solved = true;
    await operatorAlertRelease(ctx);
    await post("human_captcha_solved", { waited_ms: info.waited_ms });
    await setState({ status: "running", message: `Bot check passed — resuming ${label}`, runId, currentSource: label, updatedAt: new Date().toISOString() });
    // The check reloads the document into the real page; let it finish before reading it.
    await waitForTabSettled(tab.id, 20000);
    await delay(1500);
  }
  return info;
}

async function fetchJSON(url, options, timeoutMs) {
  // LAYER 2 of the bridge-URL guard (see isLoopbackBridgeUrl). Every call site of fetchJSON is a
  // bridge call — /status, /jobs/current, /jobs/control and postToBridge's /collect/* — so this
  // is the last line the collector's payload crosses before it leaves the browser, and it will
  // not cross it for anything but the local bridge. A value checked on save can still arrive here
  // unchecked: storage edited directly, a packaged client_binding.json, a future call site. One
  // URL parse per request is the whole cost.
  if (!isLoopbackBridgeUrl(url)) {
    throw new Error("refused: the collector only talks to the local bridge on this machine, not " + bridgeHostOf(url));
  }
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs || 10000);
  try {
    // `redirect` goes AFTER the spread on purpose: no call site may relax it. Measured
    // 2026-09-12 with the real fetchJSON against a loopback server answering 307 — the default
    // "follow" re-sent the POST body AND the X-Collector-Token header to the external host, so
    // checking the URL alone left the payload one redirect away from anywhere. The local bridge
    // never redirects, so treating a 3xx as an error costs nothing and closes that door.
    const response = await fetch(url, { ...options, signal: controller.signal, redirect: "error" });
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }
    return await response.json();
  } finally {
    clearTimeout(timer);
  }
}

async function postToBridge(baseUrl, token, path, payload, binding) {
  const body = { ...(payload || {}) };
  if (binding && binding.client_slug && !body.client_slug) body.client_slug = binding.client_slug;
  if (binding && binding.extension_instance_id && !body.extension_instance_id) body.extension_instance_id = binding.extension_instance_id;
  if (binding && binding.extension_display_name && !body.extension_display_name) body.extension_display_name = binding.extension_display_name;
  return fetchJSON(`${trimSlash(baseUrl)}${path}`, {
    method: "POST",
    headers: collectorHeaders(binding, {
      "Content-Type": "application/json",
      "X-Collector-Token": token
    }),
    body: JSON.stringify(body)
  }, 12000);
}

async function syncSettingsToBridge(settings) {
  return "skipped";
}

function createTab(createProperties) {
  return new Promise((resolve, reject) => {
    chrome.tabs.create(createProperties, (tab) => {
      const err = chrome.runtime.lastError;
      if (err) reject(new Error(err.message));
      else resolve(tab);
    });
  });
}

function collectionTabActivationPlan(job, source) {
  const active = shouldActivateCollectionTab(job, source);
  const asked = (
    explicitTrue(job?.background_tab) || explicitTrue(job?.allow_background_tab) ||
    explicitTrue(job?.pacing?.background_tab) || explicitTrue(job?.pacing?.allow_background_tab) ||
    explicitTrue(source?.background_tab) || explicitTrue(source?.allow_background_tab) ||
    explicitFalse(job?.activate_tab) || explicitFalse(job?.pacing?.activate_tab) ||
    explicitFalse(source?.activate_tab)
  );
  if (!active) {
    return {
      mode: "background_tab",
      createActive: false,
      updateActive: false,
      focusWindow: false
    };
  }

  const pacing = job && typeof job === "object" ? job.pacing || {} : {};
  const focusWindow = (
    explicitTrue(job?.focus_collection_window) ||
    explicitTrue(job?.focus_window) ||
    explicitTrue(pacing?.focus_collection_window) ||
    explicitTrue(pacing?.focus_window) ||
    explicitTrue(source?.focus_collection_window) ||
    explicitTrue(source?.focus_window)
  );

  return {
    // When the operator asked for a hidden tab and the capability overrode it, SAY so. Otherwise
    // the flag looks ignored, and the next person to debug it starts from the wrong place.
    mode: asked && capabilityNeedsActiveTab(source)
      ? "active_tab_required_by_capability"
      : (focusWindow ? "active_tab_with_window_focus" : "active_tab_no_window_focus"),
    createActive: focusWindow,
    updateActive: true,
    focusWindow
  };
}

async function activateTab(tab, plan = {}) {
  if (!tab || typeof tab.id !== "number") return;
  try {
    if (plan.updateActive !== false) {
      await chrome.tabs.update(tab.id, { active: true });
    }
    if (plan.focusWindow && typeof tab.windowId === "number") {
      await chrome.windows.update(tab.windowId, { focused: true });
    }
  } catch (error) {
    // Capture can still proceed if activating is blocked. Metadata records
    // whether the run requested window focus or only tab activation.
  }
}

async function installCollectorCaptureOverlayOnTab(tab, text, meta) {
  if (!tab || typeof tab.id !== "number") return false;
  try {
    await withTimeout(chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: installCollectorCaptureOverlay,
      args: [{ text, client: (meta && meta.client) || "", campaign: (meta && meta.campaign) || "",
               runId: (meta && meta.runId) || "" }]
    }), 8000, "install_capture_overlay_timeout");
    return true;
  } catch (error) {
    return false;
  }
}

// The campaign a run belongs to, when the job says. Several producers name it differently and no
// single field is guaranteed: live jobs from the harvest loop carry `harvest_campaign`
// ("leads-from-friends-list"), while an ad-hoc run_now job carries none at all. Absent is normal,
// and an empty "Campaign:" line is worse than no line — it looks like the value was lost.
function collectorCaptureOverlayCampaign(job, source) {
  const raw = String(
    job?.campaign_name || job?.campaign || job?.campaign_slug || job?.harvest_campaign ||
    source?.campaign_name || source?.campaign || source?.campaign_slug || ""
  ).trim();
  return raw.slice(0, 60);
}

function collectorCaptureOverlayText(job, binding) {
  const clientName = String(
    job?.client_name ||
    job?.client_display_name ||
    binding?.client_name ||
    ""
  ).trim();
  if (clientName) {
    return `${clientName} - Solo Agency Collector`;
  }
  const displayName = String(
    binding?.extension_display_name ||
    job?.extension_display_name ||
    "Solo Agency Collector"
  ).replace(/\s*-\s*/g, " ").trim();
  return displayName || "Solo Agency Collector";
}

function installCollectorCaptureOverlay(options) {
  const overlayId = "solo-agency-collector-capture-overlay";
  const styleId = "solo-agency-collector-capture-overlay-style";
  const label = String(options && options.text ? options.text : "Solo Agency Collector");
  try {
    const existing = document.getElementById(overlayId);
    if (existing) existing.remove();
    if (!document.getElementById(styleId)) {
      const style = document.createElement("style");
      style.id = styleId;
      style.textContent = `
@keyframes soloAgencyCollectorRecordBlink {
  0%, 100% { opacity: 1; transform: scale(1); box-shadow: 0 0 0 0 rgba(255, 0, 0, 0.72); }
  45% { opacity: 0.36; transform: scale(0.82); box-shadow: 0 0 0 18px rgba(255, 0, 0, 0); }
}
	#${overlayId} {
	  position: fixed !important;
	  top: 18px !important;
	  right: 18px !important;
	  z-index: 2147483647 !important;
	  display: flex !important;
	  flex-direction: column !important;
	  align-items: stretch !important;
	  gap: 10px !important;
	  width: min(380px, calc(100vw - 28px)) !important;
	  max-height: min(52vh, 430px) !important;
	  padding: 12px !important;
	  border: 1px solid rgba(248, 113, 113, 0.36) !important;
	  border-radius: 10px !important;
	  background: linear-gradient(180deg, rgba(17, 24, 39, 0.96), rgba(7, 10, 18, 0.94)) !important;
	  color: #f8fafc !important;
	  box-shadow: 0 16px 44px rgba(0, 0, 0, 0.34), 0 0 0 1px rgba(255, 255, 255, 0.08) inset !important;
	  pointer-events: none !important;
	  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Arial, sans-serif !important;
	  line-height: 1.25 !important;
	  letter-spacing: 0 !important;
	  text-align: left !important;
	  backdrop-filter: blur(10px) saturate(1.15) !important;
	}
	#${overlayId} .solo-agency-collector-record-head {
	  display: flex !important;
	  align-items: flex-start !important;
	  gap: 10px !important;
	}
	#${overlayId} .solo-agency-collector-record-dot {
	  width: 18px !important;
	  height: 18px !important;
	  min-width: 18px !important;
	  margin-top: 2px !important;
	  border-radius: 999px !important;
	  background: radial-gradient(circle at 35% 35%, #fecaca 0, #ef4444 38%, #991b1b 100%) !important;
	  animation: soloAgencyCollectorRecordBlink 0.9s infinite !important;
	}
	#${overlayId} .solo-agency-collector-stop {
	  margin-left: auto !important;
	  flex: 0 0 auto !important;
	  /* The overlay as a whole is click-through so it never steals a click from the page being
	     collected. This one control opts back IN — it is the only thing here meant to be pressed. */
	  pointer-events: auto !important;
	  cursor: pointer !important;
	  appearance: none !important;
	  border: 1px solid rgba(248, 113, 113, 0.55) !important;
	  border-radius: 7px !important;
	  background: rgba(127, 29, 29, 0.55) !important;
	  color: #fee2e2 !important;
	  font-family: inherit !important;
	  font-size: 11px !important;
	  font-weight: 700 !important;
	  letter-spacing: 0.3px !important;
	  padding: 4px 9px !important;
	  line-height: 1.1 !important;
	  white-space: nowrap !important;
	}
	#${overlayId} .solo-agency-collector-stop:hover {
	  background: rgba(185, 28, 28, 0.75) !important;
	  color: #ffffff !important;
	}
	#${overlayId} .solo-agency-collector-stop[disabled] {
	  opacity: 0.6 !important;
	  cursor: default !important;
	}
	#${overlayId} .solo-agency-collector-title-stack {
	  display: flex !important;
	  flex-direction: column !important;
	  gap: 4px !important;
	  min-width: 0 !important;
	}
	#${overlayId} .solo-agency-collector-record-label {
	  color: #ffffff !important;
	  font-size: 15px !important;
	  font-weight: 800 !important;
	  line-height: 1.2 !important;
	  letter-spacing: 0 !important;
	  white-space: nowrap !important;
	  overflow: hidden !important;
	  text-overflow: ellipsis !important;
	  max-width: 320px !important;
	}
	#${overlayId} .solo-agency-collector-scope {
	  margin-top: 3px !important;
	  font-size: 11px !important;
	  font-weight: 600 !important;
	  color: #bfdbfe !important;
	  letter-spacing: 0.2px !important;
	  word-break: break-word !important;
	}
	#${overlayId} .solo-agency-collector-record-subtitle {
	  color: #cbd5e1 !important;
	  font-size: 11px !important;
	  font-weight: 600 !important;
	  line-height: 1.3 !important;
	  letter-spacing: 0 !important;
	}
	#${overlayId} .solo-agency-collector-privacy {
	  color: #fecaca !important;
	  font-size: 10px !important;
	  font-weight: 700 !important;
	  line-height: 1.25 !important;
	  letter-spacing: 0 !important;
	}
	#${overlayId} .solo-agency-collector-stream-title {
	  display: flex !important;
	  justify-content: space-between !important;
	  align-items: center !important;
	  gap: 10px !important;
	  color: #e2e8f0 !important;
	  font-size: 11px !important;
	  font-weight: 800 !important;
	  letter-spacing: 0 !important;
	  text-transform: uppercase !important;
	}
	#${overlayId} .solo-agency-collector-stream-count {
	  color: #94a3b8 !important;
	  font-size: 10px !important;
	  font-weight: 700 !important;
	  text-transform: none !important;
	}
	#${overlayId} .solo-agency-collector-stream-box {
	  min-height: 92px !important;
	  max-height: min(30vh, 220px) !important;
	  overflow: hidden !important;
	  padding: 8px !important;
	  border: 1px solid rgba(148, 163, 184, 0.22) !important;
	  border-radius: 8px !important;
	  background: rgba(2, 6, 23, 0.62) !important;
	}
	#${overlayId} .solo-agency-collector-stream {
	  display: flex !important;
	  flex-direction: column !important;
	  gap: 6px !important;
	  max-height: min(28vh, 204px) !important;
	  overflow: hidden !important;
	  color: #dbeafe !important;
	  font-size: 11px !important;
	  font-weight: 500 !important;
	  line-height: 1.35 !important;
	  white-space: pre-wrap !important;
	}
	#${overlayId} .solo-agency-collector-stream-row {
	  padding: 6px 7px !important;
	  border-left: 2px solid rgba(248, 113, 113, 0.78) !important;
	  background: rgba(15, 23, 42, 0.72) !important;
	  border-radius: 6px !important;
	}
	#${overlayId} .solo-agency-collector-stream-meta {
	  display: block !important;
	  margin-bottom: 3px !important;
	  color: #fca5a5 !important;
	  font-size: 9px !important;
	  font-weight: 800 !important;
	  letter-spacing: 0 !important;
	  text-transform: uppercase !important;
	}
`;
      (document.head || document.documentElement).appendChild(style);
    }
    const overlay = document.createElement("div");
    overlay.id = overlayId;
    overlay.setAttribute("role", "status");
    overlay.setAttribute("aria-live", "polite");
    const head = document.createElement("div");
    head.className = "solo-agency-collector-record-head";
    const dot = document.createElement("span");
    dot.className = "solo-agency-collector-record-dot";
	    const text = document.createElement("span");
	    text.className = "solo-agency-collector-record-label";
	    text.textContent = label;
	    const stack = document.createElement("div");
	    stack.className = "solo-agency-collector-title-stack";
	    const subtitle = document.createElement("div");
	    subtitle.className = "solo-agency-collector-record-subtitle";
	    subtitle.textContent = "Capturing approved visible-page data locally";
	    const privacy = document.createElement("div");
	    privacy.className = "solo-agency-collector-privacy";
	    privacy.textContent = "No username, password, cookie, token, or account secret is collected or sent out.";
	    stack.appendChild(text);
	    stack.appendChild(subtitle);
	    // WHOSE run this is. The header already names the client; this says which campaign it is
	    // working for, which is the question the operator actually has when a tab opens by itself
	    // while several clients are being harvested at once. Rendered only when the job carries a
	    // campaign — an ad-hoc run has none, and a blank "Campaign:" reads as a lost value.
	    const client = String((options && options.client) || "").trim();
	    const campaign = String((options && options.campaign) || "").trim();
	    if (client || campaign) {
	      const who = document.createElement("div");
	      who.className = "solo-agency-collector-scope";
	      const parts = [];
	      if (client) parts.push("Client: " + client);
	      if (campaign) parts.push("Campaign: " + campaign);
	      who.textContent = parts.join("   ·   ");
	      stack.appendChild(who);
	    }
	    stack.appendChild(privacy);
	    head.appendChild(dot);
	    head.appendChild(stack);
	    // Stopping where you can SEE it is running. The alternative is hunting for the extension popup
	    // while the page you wanted back is still being driven.
	    const stop = document.createElement("button");
	    stop.className = "solo-agency-collector-stop";
	    stop.type = "button";
	    stop.textContent = "Stop";
	    stop.title = "Cancel this collection run";
	    stop.addEventListener("click", function () {
	      stop.disabled = true;
	      stop.textContent = "Stopping\u2026";
	      try {
	        chrome.runtime.sendMessage({
	          type: "cancel_run",
	          run_id: String((options && options.runId) || ""),
	          reason: "stopped from the page overlay",
	          requested_by: "overlay"
	        });
	      } catch (error) {
	        // The service worker may already be gone, which means the run is too.
	        stop.textContent = "Stopped";
	      }
	    });
	    head.appendChild(stop);
	    const streamTitle = document.createElement("div");
	    streamTitle.className = "solo-agency-collector-stream-title";
	    const streamTitleText = document.createElement("span");
	    streamTitleText.textContent = "Live data preview";
	    const streamCount = document.createElement("span");
	    streamCount.className = "solo-agency-collector-stream-count";
	    streamCount.textContent = "0 items";
	    streamTitle.appendChild(streamTitleText);
	    streamTitle.appendChild(streamCount);
    const streamBox = document.createElement("div");
    streamBox.className = "solo-agency-collector-stream-box";
    const stream = document.createElement("div");
    stream.className = "solo-agency-collector-stream";
    const initialRow = document.createElement("div");
    initialRow.className = "solo-agency-collector-stream-row";
    initialRow.textContent = "Waiting for visible page text...";
    stream.appendChild(initialRow);
    streamBox.appendChild(stream);
    overlay.appendChild(head);
    overlay.appendChild(streamTitle);
    overlay.appendChild(streamBox);
    (document.body || document.documentElement).appendChild(overlay);
    window.__soloAgencyCollectorUpdateOverlay = function(payload) {
      try {
	        const target = document.querySelector(`#${overlayId} .solo-agency-collector-stream`);
	        const box = document.querySelector(`#${overlayId} .solo-agency-collector-stream-box`);
	        const count = document.querySelector(`#${overlayId} .solo-agency-collector-stream-count`);
	        if (!target || !box) return;
	        const data = payload && typeof payload === "object" ? payload : {};
        const row = document.createElement("div");
        row.className = "solo-agency-collector-stream-row";
        const meta = document.createElement("span");
        meta.className = "solo-agency-collector-stream-meta";
        const step = data.step != null && data.total != null ? `step ${data.step}/${data.total}` : "collector";
        meta.textContent = `${step} - ${String(data.phase || "capturing")}`;
        const body = document.createElement("span");
        const raw = String(data.text || data.message || "").replace(/\s+/g, " ").trim();
	        body.textContent = raw ? raw.slice(-520) : "Collecting visible page text...";
	        row.appendChild(meta);
	        row.appendChild(body);
	        target.appendChild(row);
	        while (target.children.length > 8) target.removeChild(target.firstChild);
	        if (count) {
	          const itemCount = Math.max(0, target.children.length - 1);
	          count.textContent = `${itemCount} item${itemCount === 1 ? "" : "s"}`;
	        }
	        box.scrollTop = box.scrollHeight;
        target.scrollTop = target.scrollHeight;
      } catch (error) {
        // Overlay preview is informational only; never block collection.
      }
    };
    return { ok: true, text: label };
  } catch (error) {
    return { ok: false, error: String(error && error.message ? error.message : error) };
  }
}

// Resolves with "complete" or "timeout". It used to resolve with nothing either way, so a page
// that never loaded was indistinguishable from one that did — and the capability then ran against
// whatever was on screen and reported an empty profile. Callers that ignore the reason behave
// exactly as before; the ones that care can now tell.
function waitForTabLoad(tabId, timeoutMs) {
  return new Promise((resolve) => {
    let done = false;
    const timer = setTimeout(() => finish("timeout"), timeoutMs || 25000);
    function finish(reason) {
      if (done) return;
      done = true;
      clearTimeout(timer);
      chrome.tabs.onUpdated.removeListener(listener);
      resolve(reason);
    }
    function listener(updatedTabId, changeInfo) {
      if (updatedTabId === tabId && changeInfo.status === "complete") {
        finish("complete");
      }
    }
    chrome.tabs.onUpdated.addListener(listener);
  });
}

// Did the navigation actually reach the site? Chrome renders its own error document for a dropped
// connection, and that document loads perfectly well — status "complete", no exception, a real
// page. The capability then reads it, finds no profile, and the harvest ledger counts a failure
// against the Facebook ACCOUNT for what was a few seconds of wifi.
//
// This matters because the three collectors share one machine and one connection. Measured over
// 976 harvest runs: 75 of 102 failures fell in clusters where two or three DIFFERENT clients
// failed inside the same ten minutes. Three independent Facebook accounts do not get throttled in
// lockstep four times a day; a machine does.
async function pageReachability(tab) {
  try {
    const [res] = await withTimeout(chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => ({
        online: navigator.onLine !== false,
        // Chrome's net-error document. Stable across versions and locales, unlike its text.
        errorPage: !!document.querySelector("#main-frame-error, .neterror, #error-information-popup-container"),
        errorCode: (document.querySelector(".error-code") || {}).textContent || "",
        href: location.href,
        title: document.title || ""
      })
    }), 5000, "reachability_probe_timeout");
    const r = (res && res.result) || null;
    if (!r) return { reachable: true, reason: "" };          // cannot tell: do not accuse
    if (r.errorPage) return { reachable: false, reason: "chrome_error_page", detail: (r.errorCode || r.title || "").slice(0, 80) };
    if (!r.online) return { reachable: false, reason: "browser_offline", detail: "" };
    return { reachable: true, reason: "" };
  } catch (error) {
    // The probe failing is not evidence of anything. Never turn an inability to check into a
    // verdict — that is how a diagnostic becomes a new source of false failures.
    return { reachable: true, reason: "" };
  }
}

async function withTimeout(promise, timeoutMs, label) {
  const original = Promise.resolve(promise);
  let timer = null;
  try {
    return await Promise.race([
      original,
      new Promise((_, reject) => {
        timer = setTimeout(() => {
          reject(new Error(`${label || "operation_timeout"} after ${Math.round((timeoutMs || 0) / 1000)}s`));
        }, timeoutMs || 30000);
      })
    ]);
  } finally {
    if (timer) clearTimeout(timer);
    original.catch(() => {});
  }
}

function captureTimeoutMsForCollection(job, source, settings, options) {
  const maxScrollSteps = maxScrollStepsForCollection(job, source);
  const scrollSteps = clampNumber(options?.scrollSteps, 0, maxScrollSteps, settings.scrollSteps || DEFAULT_SETTINGS.scrollSteps);
  const maxDelaySeconds = clampNumber(options?.maxDelaySeconds, 1, 60, settings.maxDelaySeconds || DEFAULT_SETTINGS.maxDelaySeconds);
  const perStepMs = (maxDelaySeconds * 1000) + 25000;
  const estimatedMs = 90000 + Math.max(1, scrollSteps) * perStepMs;
  const capMs = isDiscoveryCollection(job, source) ? 25 * 60 * 1000 : 12 * 60 * 1000;
  return Math.max(3 * 60 * 1000, Math.min(capMs, estimatedMs));
}

// Injected orchestrator for the AUTOMATED collector. Requires CAPTURE_FILES to
// already be injected (defines window.__collectorCapture). Scrolls scrollSteps
// times, accumulating the cleaned capture across scrolls, returns the final result.
async function collectCleanPage(opts) {
  const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
  // NOTE: use Number.isFinite, NOT `|| default` — an explicit 0 (write actions,
  // which must NOT scroll a reel player off-target) is falsy and would wrongly
  // fall back to the default, causing exactly the reel-drift bug.
  const maxSteps = clamp(Number.isFinite(Number(opts.maxScrollSteps)) ? Number(opts.maxScrollSteps) : 10, 0, 80);
  const steps = clamp(Number.isFinite(Number(opts.scrollSteps)) ? Number(opts.scrollSteps) : 5, 0, maxSteps);
  const scrollMode = String(opts.scrollMode || "standard");
  const stopAfterNoMoveScrolls = clamp(Number(opts.stopAfterNoMoveScrolls) || 0, 0, 10);
  const minD = clamp(Number(opts.minDelaySeconds) || 5, 1, 30);
  const maxD = clamp(Number(opts.maxDelaySeconds) || 5, minD, 60);
  const randomBetween = (lo, hi) => lo + Math.random() * (hi - lo);
  const delayMs = () => {
    const baseSeconds = minD + Math.random() * (maxD - minD);
    const jitter = minD === maxD ? randomBetween(0.72, 1.32) : randomBetween(0.9, 1.16);
    return Math.floor(clamp(baseSeconds * jitter, 1, 60) * 1000);
  };
  const accountUrls = [];
  const postUrls = [];
  const entityItems = [];
  const seenAccountUrls = new Set();
  const seenPostUrls = new Set();
  const seenEntityItems = new Set();
  const scrollDebug = [];

  function elementLabel(el) {
    if (!el) return "unknown";
    if (el === document.scrollingElement || el === document.documentElement || el === document.body) return "document";
    const role = el.getAttribute && el.getAttribute("role");
    const id = el.id ? `#${el.id}` : "";
    const cls = el.className && typeof el.className === "string" ? `.${el.className.trim().split(/\s+/).slice(0, 2).join(".")}` : "";
    return `${String(el.tagName || "element").toLowerCase()}${id}${cls}${role ? `[role=${role}]` : ""}`;
  }

  function scrollTopOf(target) {
    if (!target || target.kind === "document") {
      const root = document.scrollingElement || document.documentElement || document.body;
      return Math.max(window.scrollY || 0, root ? root.scrollTop || 0 : 0, document.documentElement ? document.documentElement.scrollTop || 0 : 0, document.body ? document.body.scrollTop || 0 : 0);
    }
    return Number(target.el.scrollTop || 0);
  }

  function scrollMaxOf(target) {
    if (!target || target.kind === "document") {
      const root = document.scrollingElement || document.documentElement || document.body;
      const scrollHeight = Math.max(root ? root.scrollHeight || 0 : 0, document.documentElement ? document.documentElement.scrollHeight || 0 : 0, document.body ? document.body.scrollHeight || 0 : 0);
      const clientHeight = window.innerHeight || (root ? root.clientHeight || 0 : 0);
      return Math.max(0, scrollHeight - clientHeight);
    }
    return Math.max(0, Number(target.el.scrollHeight || 0) - Number(target.el.clientHeight || 0));
  }

  function scrollCandidates() {
    const candidates = [];
    const root = document.scrollingElement || document.documentElement || document.body;
    if (root) {
      candidates.push({
        kind: "document",
        el: root,
        label: "document",
        viewport: window.innerHeight || root.clientHeight || 800,
        score: scrollMaxOf({ kind: "document", el: root }) + 1000000
      });
    }
    const selector = [
      "main",
      "section",
      "div",
      "[role='main']",
      "[role='feed']",
      "[role='list']",
      "[data-pagelet]"
    ].join(",");
    for (const el of Array.from(document.querySelectorAll(selector))) {
      if (!el || el === root || el === document.body || el === document.documentElement) continue;
      const scrollable = Number(el.scrollHeight || 0) - Number(el.clientHeight || 0);
      if (scrollable < 300) continue;
      const rect = el.getBoundingClientRect();
      if (!rect || rect.width < 220 || rect.height < 240) continue;
      const style = window.getComputedStyle ? window.getComputedStyle(el) : null;
      if (style && (style.visibility === "hidden" || style.display === "none")) continue;
      const viewportOverlap = Math.max(0, Math.min(rect.bottom, window.innerHeight || rect.bottom) - Math.max(rect.top, 0));
      const centerBonus = rect.top < (window.innerHeight || 800) * 0.75 && rect.bottom > (window.innerHeight || 800) * 0.25 ? 50000 : 0;
      candidates.push({
        kind: "element",
        el,
        label: elementLabel(el),
        viewport: Math.max(300, Math.min(rect.height, window.innerHeight || rect.height || 800)),
        score: scrollable + viewportOverlap * 10 + centerBonus
      });
    }
    return candidates
      .filter((target) => scrollMaxOf(target) - scrollTopOf(target) > 10)
      .sort((a, b) => b.score - a.score)
      .slice(0, 8);
  }

  function setScrollTopOf(target, top) {
    const nextTop = Math.max(0, Math.min(scrollMaxOf(target), Number(top) || 0));
    if (!target || target.kind === "document") {
      const root = document.scrollingElement || document.documentElement || document.body;
      if (root) root.scrollTop = nextTop;
      window.scrollTo(0, nextTop);
      return;
    }
    target.el.scrollTop = nextTop;
  }

  function humanDurationMs(baseMs) {
    return Math.round(clamp(Number(baseMs) * randomBetween(0.72, 1.38), 420, 1450));
  }

  function humanScrollDistance(viewport, multiplier) {
    const base = Math.max(680, Math.floor((viewport || window.innerHeight || 800) * multiplier));
    return Math.round(base * randomBetween(0.84, 1.12));
  }

  function dispatchScrollHints(target, distance) {
    const node = target && target.kind === "element" ? target.el : document.scrollingElement || document.documentElement || document.body;
    try {
      const wheel = new WheelEvent("wheel", {
        bubbles: true,
        cancelable: true,
        deltaY: Math.max(120, Number(distance) || 0),
        view: window
      });
      (node || document).dispatchEvent(wheel);
    } catch (error) {
      // Synthetic input hints are best-effort only.
    }
    try {
      (target && target.kind === "element" ? target.el : window).dispatchEvent(new Event("scroll", { bubbles: true }));
    } catch (error) {
      // Ignore pages that block synthetic events.
    }
  }

  async function moveScrollTarget(target, toTop, durationMs) {
    const from = scrollTopOf(target);
    const max = scrollMaxOf(target);
    const to = Math.max(0, Math.min(max, Number(toTop) || 0));
    if (Math.abs(to - from) < 1) return;
    const duration = Math.max(260, Number(durationMs) || 760);
    if (Math.abs(to - from) > 240) {
      setScrollTopOf(target, from + (to - from) * 0.58);
      dispatchScrollHints(target, to - from);
      await wait(Math.round(clamp(duration / 7, 60, 180)));
    }
    setScrollTopOf(target, to);
    dispatchScrollHints(target, to - from);
  }

  async function tryScrollTarget(target, distance) {
    const before = scrollTopOf(target);
    const nextTop = Math.min(scrollMaxOf(target), before + distance);
    const durationMs = humanDurationMs(scrollMode === "discovery" ? 850 : 700);
    await moveScrollTarget(target, nextTop, durationMs);
    await wait(Math.round(randomBetween(60, 170)));
    const after = scrollTopOf(target);
    return {
      target: target.label,
      before: Math.round(before),
      after: Math.round(after),
      delta: Math.round(after - before),
      requested_distance: Math.round(distance),
      duration_ms: durationMs,
      max: Math.round(scrollMaxOf(target))
    };
  }

  async function performCollectorScroll() {
    const multiplier = scrollMode === "discovery" ? 0.95 : 0.85;
    const targets = scrollCandidates();
    let best = null;
    for (const target of targets) {
      const distance = humanScrollDistance(target.viewport || window.innerHeight || 800, multiplier);
      const report = await tryScrollTarget(target, distance);
      if (!best || Math.abs(report.delta) > Math.abs(best.delta || 0)) best = report;
      if (Math.abs(report.delta) >= 120) return report;
    }
    if (best) return best;
    const fallbackDistance = humanScrollDistance(window.innerHeight || 800, multiplier);
    const fallbackTarget = { kind: "document", el: document.scrollingElement || document.documentElement || document.body, label: "window-fallback" };
    const durationMs = humanDurationMs(scrollMode === "discovery" ? 850 : 700);
    await moveScrollTarget(fallbackTarget, scrollTopOf(fallbackTarget) + fallbackDistance, durationMs);
    await wait(Math.round(randomBetween(60, 170)));
    return {
      target: "window-fallback",
      before: null,
      after: Math.round(window.scrollY || 0),
      delta: null,
      requested_distance: Math.round(fallbackDistance),
      duration_ms: durationMs,
      max: Math.round(scrollMaxOf({ kind: "document", el: document.scrollingElement || document.documentElement || document.body }))
    };
  }

  function urlKey(value) {
    try {
      const parsed = new URL(String(value || ""), location.href);
      parsed.hash = "";
      return parsed.href.replace(/\/+$/, "").toLowerCase();
    } catch (error) {
      return String(value || "").trim().replace(/\/+$/, "").toLowerCase();
    }
  }

  function addUniqueUrl(target, seen, values) {
    if (!Array.isArray(values)) return;
    for (const value of values) {
      if (!value) continue;
      const key = urlKey(value);
      if (!key || seen.has(key)) continue;
      seen.add(key);
      target.push(value);
    }
  }

  function entityKey(item) {
    if (!item || typeof item !== "object") return "";
    if (item.url) return urlKey(item.url);
    return `${String(item.type || "").toLowerCase()}:${String(item.name || "").trim().toLowerCase()}`;
  }

  function addEntityItems(values) {
    if (!Array.isArray(values)) return;
    for (const item of values) {
      const key = entityKey(item);
      if (!key || seenEntityItems.has(key)) continue;
      seenEntityItems.add(key);
      entityItems.push(item);
    }
  }

  function compactOverlayText(value) {
    return String(value || "").replace(/\s+/g, " ").trim().slice(-1800);
  }

  function overlayTextFromCapture(capture) {
    if (!capture) return "";
    if (capture.error) return `Capture warning: ${String(capture.error)}`;
    const text = capture.mergedDisplay || capture.merged || capture.display || capture.text || "";
    return compactOverlayText(text);
  }

  function updateCollectorOverlay(payload) {
    try {
      if (typeof window.__soloAgencyCollectorUpdateOverlay === "function") {
        window.__soloAgencyCollectorUpdateOverlay(payload || {});
      }
    } catch (error) {
      // The on-page preview is informational only; never block collection.
    }
  }

  let prev = "";
  let last = null;
  let scrollStepsUsed = 0;
  let consecutiveNoMove = 0;
  let stoppedReason = "";
  updateCollectorOverlay({
    phase: "starting",
    step: 0,
    total: steps,
    text: `Preparing local capture for ${location.href}`
  });
  // Facebook TRUNCATES long bio/About/post text behind a "See more" toggle, so the
  // rest of that text is not in the DOM at all and never reaches the capture — a
  // profile with its email in the bio (e.g. sample.lead@example.com) read as having no
  // email, while a profile whose email fits the untruncated bio was found fine.
  // Expanding is a UI toggle on ALREADY-PUBLIC text the viewer can see; it does not
  // open a private/hidden section and does not navigate (anchors are skipped).
  // Facebook streams the intro/About card in AFTER first paint, so expanding straight
  // away only clicks the toggles that happen to exist yet. Measured: the same profile
  // expanded 4 toggles when run alone but only 1 inside a 15-source batch (slower
  // render), and its address stayed hidden — that, not scrolling, is what made email
  // discovery flaky. Wait until the visible text stops growing before clicking.
  async function waitForContentSettled(maxMs) {
    let last = -1, stable = 0, waited = 0;
    while (waited < (maxMs || 6000)) {
      const len = (document.body && document.body.innerText ? document.body.innerText.length : 0);
      if (len === last && len > 0) { stable += 1; if (stable >= 2) return len; } else { stable = 0; }
      last = len;
      await wait(400); waited += 400;
    }
    return last;
  }

  async function expandTruncatedText() {
    // Match the START of the label, not the whole string: a profile's bio expander is
    // labelled "See more about <Name>", so an exact-match test silently skipped the one
    // button that reveals the address. Kept to a small set of expander verbs so this
    // never clicks a navigating control ("See all photos", "See friendship" …).
    const LABELS = /^\s*(?:…\s*)?(see more|show more|xem thêm|see more about|xem thêm về)\b/i;
    await waitForContentSettled(6000);
    let clicked = 0;
    for (let pass = 0; pass < 4 && clicked < 12; pass += 1) {
      const nodes = document.querySelectorAll('[role="button"], span[tabindex], div[tabindex]');
      let hitThisPass = 0;
      for (const node of nodes) {
        if (clicked >= 12) break;
        if (node.tagName === "A" || node.closest("a")) continue; // never follow a link
        const label = (node.innerText || "").replace(/\s+/g, " ").trim();
        if (!LABELS.test(label)) continue;
        const box = node.getBoundingClientRect();
        if (box.width <= 0 || box.height <= 0) continue;
        try { node.click(); clicked += 1; hitThisPass += 1; } catch (error) { /* keep going */ }
      }
      // Keep going even when a pass found nothing: a later chunk of the profile may
      // still be streaming in, and that chunk is often the one holding the address.
      await wait(hitThisPass ? 700 : 900);
    }
    return clicked;
  }
  // On a profile's About tab the address usually lives under the "Contact info"
  // SUB-TAB, which is a separate in-page view: reading /about alone returns no email
  // even though the address is two clicks away. Clicking the sub-tab is more reliable
  // than guessing a URL, because the numeric-profile URL forms silently bounce to the
  // operator's own page. Same profile, same tab strip — it never navigates away.
  async function openContactInfoTab() {
    const LABELS = /^(contact info|contact and basic info|contact & basic info|thông tin liên hệ|thông tin liên hệ và cơ bản)$/i;
    const nodes = document.querySelectorAll('a[role="link"], [role="tab"], [role="button"], [role="listitem"] a');
    for (const node of nodes) {
      const label = (node.innerText || node.getAttribute("aria-label") || "").replace(/\s+/g, " ").trim();
      if (!LABELS.test(label)) continue;
      const box = node.getBoundingClientRect();
      if (box.width <= 0 || box.height <= 0) continue;
      try { node.click(); await wait(1800); return true; } catch (error) { /* keep looking */ }
    }
    return false;
  }
  let openedContactTab = false;
  try {
    if (/facebook\.com/i.test(location.hostname) && /\/about|sk=about|directory_contact_info/i.test(location.href)) {
      openedContactTab = await openContactInfoTab();
    }
  } catch (error) { /* optional */ }
  let expandedCount = 0;
  try { expandedCount = await expandTruncatedText(); } catch (error) { /* optional */ }
  // Facebook silently falls back to the LOGGED-IN operator's own profile when a
  // profile URL is malformed or a tab slug is unsupported — verified: both
  // `profile.php?id=<X>/about` and `profile.php?id=<X>&sk=about_contact_and_basic_info`
  // landed on the operator's own page (only `&sk=about` stays on the target). Reading
  // that page would harvest the OPERATOR's email/phone and attribute it to the lead,
  // so detect it from the page itself (an own-profile view offers editing controls)
  // rather than trusting the URL, which still looks correct.
  function landedOnOwnProfile() {
    try {
      const SELF = /^(edit profile|chỉnh sửa trang cá nhân|edit public details|add to story|thêm vào tin)$/i;
      const nodes = document.querySelectorAll('[role="button"], a[role="link"], [aria-label]');
      for (const node of nodes) {
        const label = (node.getAttribute("aria-label") || node.innerText || "").replace(/\s+/g, " ").trim();
        if (SELF.test(label)) return true;
      }
    } catch (error) { /* best effort */ }
    return false;
  }
  // On a reel the OWNER affordance ("See Owner" → a link carrying sk=reels_tab) renders
  // after the player itself. Reading before it appears yields a record with no owner at
  // all: 178 of 737 reel jobs came back that way, and 99% of the successful ones had
  // "See Owner" present versus 1% of the failures — while a Messenger panel was open in
  // 67% of the SUCCESSES too, so the chat overlay was noise, not the cause. Wait for the
  // affordance, and report whether it ever arrived so the caller can retry a timing miss
  // instead of recording "this reel has no owner".
  let ownerAffordanceSeen = false;
  if (/\/reel\/[A-Za-z0-9]+/.test(location.pathname)) {
    for (let attempt = 0; attempt < 20; attempt += 1) {
      if (document.querySelector('a[href*="reels_tab"]')) { ownerAffordanceSeen = true; break; }
      await wait(400);
    }
  }
  const landedSelf = landedOnOwnProfile();
  for (let i = 0; i <= steps; i += 1) {
    try {
      last = (typeof window.__collectorCapture === "function") ? window.__collectorCapture(prev, {}) : last;
    } catch (error) {
      last = { error: String(error && error.message ? error.message : error) };
    }
    if (last) {
      addUniqueUrl(accountUrls, seenAccountUrls, last.accountUrls);
      addUniqueUrl(postUrls, seenPostUrls, last.postUrls);
      addEntityItems(last.entityItems);
    }
    if (last && last.merged) prev = last.merged;
    updateCollectorOverlay({
      phase: "capturing",
      step: Math.min(i, steps),
      total: steps,
      text: overlayTextFromCapture(last) || `Captured visible page state at ${location.href}`
    });
    if (i < steps) {
      const scrollReport = await performCollectorScroll();
      scrollStepsUsed += 1;
      scrollReport.pause_ms = delayMs();
      scrollDebug.push(scrollReport);
      updateCollectorOverlay({
        phase: "scrolling",
        step: scrollStepsUsed,
        total: steps,
        text: `Scrolled ${scrollReport.target || "page"} by ${scrollReport.delta == null ? "unknown" : scrollReport.delta} px. Waiting ${Math.round(scrollReport.pause_ms / 1000)}s for new visible data to load.`
      });
      if (!scrollReport || Math.abs(Number(scrollReport.delta || 0)) < 80) {
        consecutiveNoMove += 1;
      } else {
        consecutiveNoMove = 0;
      }
      if (stopAfterNoMoveScrolls > 0 && consecutiveNoMove >= stopAfterNoMoveScrolls) {
        stoppedReason = `no_scroll_movement_${consecutiveNoMove}_times`;
        updateCollectorOverlay({
          phase: "stopping",
          step: scrollStepsUsed,
          total: steps,
          text: `Stopping local capture: ${stoppedReason}.`
        });
        break;
      }
      await wait(scrollReport.pause_ms);
    }
  }
  if (last) {
    last.scrollStepsUsed = scrollStepsUsed;
    last.expandedTruncations = expandedCount;
    last.landedOnSelf = landedSelf;
    last.ownerAffordanceSeen = ownerAffordanceSeen;
    last.openedContactTab = openedContactTab;
    last.requestedScrollSteps = steps;
    last.scrollStoppedReason = stoppedReason;
    last.scrollDebug = scrollDebug.slice(-20);
    last.accountUrls = accountUrls;
    last.postUrls = postUrls;
    last.entityItems = entityItems;
    // ADDITIVE: structured business email/phone extraction over the cleaned
    // visible text plus live mailto:/tel: anchors. Best-effort and self-contained
    // (contact_extract.js is injected via CAPTURE_FILES); never blocks capture.
    try {
      if (typeof window.__soloExtractContacts === "function") {
        last.contacts = window.__soloExtractContacts(last.mergedDisplay || last.merged || prev || "", document);
      }
    } catch (error) {
      // Contact extraction is optional; ignore and keep the rest of the capture.
    }
  }
  updateCollectorOverlay({
    phase: "completed",
    step: scrollStepsUsed,
    total: steps,
    text: "Local visible-page capture completed. Saving collected data to the Local Collector app on this computer."
  });
  return last || {};
}

function extractEngagementHint(text) {
  const m = String(text || "").match(/[0-9][0-9.,KM]*\s*(reactions?|likes?|comments?|shares?|views?|replies|reply|reposts?|retweets?|answers?)/gi);
  return m ? Array.from(new Set(m)).slice(0, 12).join("; ") : "";
}

function detectLoginHint(text) {
  const lower = String(text || "").toLowerCase();
  if (lower.includes("log in") || lower.includes("sign in") || lower.includes("login")) return "maybe_logged_out";
  return text ? "available" : "unknown";
}

function collectVisiblePage(source, job, options) {
  const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
  const minDelay = clamp(Number(options.minDelaySeconds || 5), 5, 20);
  const maxDelay = clamp(Number(options.maxDelaySeconds || 5), minDelay, 30);
  const delayMs = () => Math.floor((minDelay + Math.random() * (maxDelay - minDelay)) * 1000);
  const maxTextChars = clamp(Number(options.maxTextChars || 12000), 1000, 30000);
  const scrollSteps = clamp(Number(options.scrollSteps || 5), 0, 10);

  function cleanText(text) {
    return String(text || "").replace(/\s+/g, " ").trim();
  }

  function textFromVisibleBody() {
    const body = document.body;
    if (!body) return "";
    return cleanText(body.innerText || body.textContent || "");
  }

  function collectLinks() {
    const anchors = Array.from(document.querySelectorAll("a[href]"));
    return anchors.slice(0, 300).map((a) => {
      let href = a.href || "";
      try {
        const parsed = new URL(href, location.href);
        parsed.hash = "";
        href = parsed.toString();
      } catch (error) {
        // Keep original href.
      }
      return {
        text: cleanText(a.innerText || a.getAttribute("aria-label") || a.title || "").slice(0, 160),
        href
      };
    }).filter((item) => item.href && /^https?:\/\//i.test(item.href));
  }

  function inferProfileCandidates(links) {
    const platform = String(source.platform || "").toLowerCase();
    const sourceURL = String(source.url || "");
    const candidates = [];
    if (sourceURL) candidates.push(sourceURL);
    for (const link of links) {
      const href = link.href || "";
      if (platform === "facebook" && /facebook\.com\/(profile\.php\?id=|people\/|pages\/|[A-Za-z0-9_.-]+\/?$)/.test(href)) candidates.push(href);
      if (platform === "linkedin" && /linkedin\.com\/(in|company)\//.test(href)) candidates.push(href);
      if (platform === "instagram" && /instagram\.com\/[A-Za-z0-9_.]+\/?$/.test(href)) candidates.push(href);
      if (platform === "tiktok" && /tiktok\.com\/@/.test(href)) candidates.push(href);
      if (platform === "reddit" && /reddit\.com\/(user|r)\//.test(href)) candidates.push(href);
      if ((platform === "x" || platform === "twitter") && /(x|twitter)\.com\/[A-Za-z0-9_]+\/?$/.test(href)) candidates.push(href);
    }
    return Array.from(new Set(candidates)).slice(0, 20);
  }

  function inferPostCandidates(links) {
    const candidates = [location.href];
    for (const link of links) {
      const href = link.href || "";
      if (/\/posts\/|\/permalink\/|\/videos\/|\/reel\/|\/status\/|\/comments\/|\/comment\//i.test(href)) candidates.push(href);
      if (/reddit\.com\/r\/[^/]+\/comments\//i.test(href)) candidates.push(href);
      if (/linkedin\.com\/feed\/update\//i.test(href)) candidates.push(href);
    }
    return Array.from(new Set(candidates)).slice(0, 20);
  }

  function inferNewPrivateSourceCandidates(links) {
    const candidates = [];
    for (const link of links) {
      const href = link.href || "";
      const text = link.text || "";
      if (!href) continue;
      const isLikelyGroup =
        /facebook\.com\/groups\//i.test(href) ||
        /linkedin\.com\/groups\//i.test(href) ||
        /reddit\.com\/r\//i.test(href);
      const isLikelyPage =
        /facebook\.com\/pages\//i.test(href) ||
        /linkedin\.com\/company\//i.test(href);
      const hasRecommendationText = /suggest|recommend|related|similar|groups?|communities|pages?/i.test(text);
      if ((isLikelyGroup || isLikelyPage) && (hasRecommendationText || text.length > 2)) {
        candidates.push({
          text: text || href,
          href,
          source_type: isLikelyGroup ? "group" : "page"
        });
      }
    }
    return Array.from(new Map(candidates.map((item) => [item.href, item])).values()).slice(0, 20);
  }

  function engagementHint(text) {
    const matches = text.match(/\b([0-9][0-9,.]*\s*(comments?|likes?|shares?|views?|reactions?|replies?|saves?))\b/gi);
    return matches ? Array.from(new Set(matches)).slice(0, 10).join("; ") : "";
  }

  function loginHint(text) {
    const lower = text.toLowerCase();
    if (lower.includes("log in") || lower.includes("sign in") || lower.includes("login")) {
      return "maybe_logged_out";
    }
    return "available";
  }

  return (async () => {
    for (let i = 0; i < scrollSteps; i += 1) {
      window.scrollBy({ top: Math.max(300, Math.floor(window.innerHeight * 0.75)), left: 0, behavior: "smooth" });
      await wait(delayMs());
    }
    const rawText = textFromVisibleBody();
    const links = collectLinks();
    const profileCandidates = inferProfileCandidates(links);
    const postCandidates = inferPostCandidates(links);
    const newPrivateSourceCandidates = inferNewPrivateSourceCandidates(links);
    const excerpt = rawText.slice(0, maxTextChars);
    return {
      title: document.title || "",
      current_url: location.href,
      profile_url: profileCandidates[0] || "",
      post_url: postCandidates[0] || location.href,
      profile_candidates: profileCandidates,
      post_candidates: postCandidates,
      visible_text_summary: excerpt.slice(0, 1200),
      raw_visible_text_excerpt: excerpt,
      engagement_hint: engagementHint(rawText),
      login_hint: loginHint(rawText),
      link_count: links.length,
      scroll_count: scrollSteps,
      max_scrolls: scrollSteps,
      new_private_source_candidates: newPrivateSourceCandidates,
      sample_links: links.slice(0, 80)
    };
  })();
}

function buildSnapshotHTML({ source, job, page, capturedAt }) {
  const safe = escapeHTML;
  const links = [
    ...(page.profile_candidates || []).map((url) => ({ label: "Profile candidate", url })),
    ...(page.post_candidates || []).map((url) => ({ label: "Post/current candidate", url }))
  ].slice(0, 40);

  return `<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>${safe(source.name || page.title || "Collector snapshot")}</title>
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; margin: 24px; line-height: 1.45; color: #17202a; }
    main { max-width: 920px; margin: 0 auto; }
    section { border: 1px solid #d8dee4; border-radius: 8px; padding: 16px; margin: 16px 0; }
    h1 { font-size: 22px; }
    h2 { font-size: 16px; margin-top: 0; }
    pre { white-space: pre-wrap; word-break: break-word; background: #f6f8fa; padding: 12px; border-radius: 6px; }
    a { color: #0969da; word-break: break-word; }
    .meta { color: #57606a; font-size: 13px; }
  </style>
</head>
<body>
  <main>
    <h1>${safe(source.name || "Collector snapshot")}</h1>
    <p class="meta">Captured at ${safe(capturedAt)} by Chrome Extension Local Collector. This is a local verification snapshot, not a cloud upload.</p>
    <section>
      <h2>Source</h2>
      <p><strong>Client:</strong> ${safe(job.client_slug || "")}</p>
      <p><strong>Platform:</strong> ${safe(source.platform || "")}</p>
      <p><strong>Configured URL:</strong> <a href="${safe(source.url || "")}">${safe(source.url || "")}</a></p>
      <p><strong>Current URL:</strong> <a href="${safe(page.current_url || "")}">${safe(page.current_url || "")}</a></p>
    </section>
    <section>
      <h2>Candidate URLs</h2>
      <ul>${links.map((link) => `<li>${safe(link.label)}: <a href="${safe(link.url)}">${safe(link.url)}</a></li>`).join("")}</ul>
    </section>
    <section>
      <h2>Visible Text Excerpt</h2>
      <pre>${safe(page.raw_visible_text_excerpt || "")}</pre>
    </section>
  </main>
</body>
</html>`;
}

function normalizeSources(sources) {
  if (!Array.isArray(sources)) return [];
  const seen = new Set();
  const normalized = [];
  for (const source of sources) {
    if (!source || typeof source !== "object" || !source.url) continue;
    const sourceUrl = String(source.url || "").trim();
    const key = canonicalSourceKey(sourceUrl);
    if (!key || seen.has(key)) continue;
    seen.add(key);
    normalized.push({
      ...source,
      url: sourceUrl,
      platform: source.platform || inferPlatform(sourceUrl)
    });
  }
  return normalized;
}

// ---- bridge URL guard -------------------------------------------------------------------
// Everything this collector reads — pages, comments, profiles, the client's lead PII — is POSTed
// to `bridgeBaseUrl`. That bridge is ALWAYS a process on THIS machine: setup writes
// http://127.0.0.1:17321 and the Go binary binds loopback only. So a bridgeBaseUrl that is not
// loopback has exactly one meaning, and it is never a legitimate one.
//
// Nothing on a web page can reach this setting today — the manifest declares no
// externally_connectable, there is no onMessageExternal handler, and the page-world content
// scripts have no chrome.* APIs — so the realistic path is a human talked into pasting a URL
// into the popup's "Local bridge URL" box. The value is therefore checked TWICE: on the way in
// (normalizeSettings, which every save and every read passes through) and again on the way out
// (fetchJSON), because chrome.storage can be edited directly, client_binding.json is a file on
// disk, and a future call site could build its own URL.
//
// Measured against the URL parser on 2026-09-12 — this is what makes a substring test useless:
//   ACCEPTED (every one of these normalises to a loopback host):
//     http://127.0.0.1:17321 · http://localhost:17321 · http://[::1]:17321 · http://LOCALHOST
//     http://127.1 · http://2130706433 · http://0x7f000001 · http://127.000.000.001 → 127.0.0.1
//   REFUSED (and every one of them would pass an indexOf("127.0.0.1") > -1 style check):
//     http://127.0.0.1.evil.com   the host merely STARTS with the loopback literal
//     http://localhost.evil.com   ...or contains it
//     http://evil.com/127.0.0.1   the path is not the host
//     http://127.0.0.1@evil.com   userinfo: reads as loopback, resolves to evil.com
//     http://0.0.0.0:17321        "every interface", not a destination
//     javascript: · data: · file: not a destination for collected data at all
function isLoopbackBridgeUrl(value) {
  let url;
  try { url = new URL(String(value || "")); } catch (error) { return false; }
  // http is what the bridge speaks. https is allowed ONLY because the host check below still
  // applies, so a future TLS-on-loopback bridge needs no code change; everything else
  // (javascript:, data:, file:, chrome-extension:) is refused outright.
  if (url.protocol !== "http:" && url.protocol !== "https:") return false;
  // "http://127.0.0.1@evil.com" resolves to evil.com. "http://evil.com@127.0.0.1" does reach
  // loopback, but it is a shape this product never writes. Neither is accepted.
  if (url.username || url.password) return false;
  // hostname arrives lowercased and normalised: IPv4 shorthand is expanded to a dotted quad and
  // IPv6 keeps its brackets. A trailing dot names the same host.
  const host = url.hostname.replace(/\.$/, "");
  if (host === "localhost") return true;
  if (host === "[::1]") return true;
  const quad = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.exec(host);
  if (!quad) return false;
  const octets = quad.slice(1).map(Number);
  if (octets.some((n) => n > 255)) return false;
  return octets[0] === 127;   // the whole 127.0.0.0/8 range, not just 127.0.0.1
}

// The value to actually use: the caller's when it is loopback, otherwise the fallback — which is
// itself checked, so a poisoned fallback cannot sneak through either.
function safeBridgeUrl(value, fallback) {
  const asked = trimSlash(String(value == null ? "" : value).trim());
  if (isLoopbackBridgeUrl(asked)) return asked;
  if (asked) console.warn("[solo-agency] bridge URL refused (not this machine):", bridgeHostOf(asked));
  const spare = trimSlash(String(fallback == null ? "" : fallback).trim());
  return isLoopbackBridgeUrl(spare) ? spare : DEFAULT_SETTINGS.bridgeBaseUrl;
}

// The host alone, for messages and logs — a full bridge URL can carry a run id or a query string.
function bridgeHostOf(value) {
  try { return new URL(String(value || "")).host || "an empty host"; }
  catch (error) { return "an unparseable URL"; }
}

function normalizeSettings(input) {
  const next = { ...DEFAULT_SETTINGS, ...input };
  next.enabled = Boolean(next.enabled);
  // LAYER 1 of the bridge-URL guard (see isLoopbackBridgeUrl): a non-loopback URL never reaches
  // storage. On its own this function has no memory, so it falls back to the DEFAULT; the
  // save_settings handler is what substitutes the URL currently in use, so an operator on a
  // non-default loopback port does not lose it to a typo. The popup says it was refused.
  next.bridgeBaseUrl = safeBridgeUrl(next.bridgeBaseUrl, DEFAULT_SETTINGS.bridgeBaseUrl);
  next.pollMinutes = clampNumber(next.pollMinutes, 1, 60, 1);
  next.pollSeconds = clampNumber(next.pollSeconds, 5, 60, 5);
  next.minDelaySeconds = clampNumber(next.minDelaySeconds, 5, 20, 5);
  next.maxDelaySeconds = clampNumber(next.maxDelaySeconds, next.minDelaySeconds, 30, 5);
  next.maxSourcesPerRun = clampNumber(next.maxSourcesPerRun, 1, 50, 20);
  next.sourceConcurrency = clampNumber(next.sourceConcurrency, 1, 3, 1);
  next.scrollSteps = clampNumber(next.scrollSteps, 0, 10, 5);
  next.maxTextChars = clampNumber(next.maxTextChars, 1000, 30000, 12000);
  next.closeTabsAfterCollect = Boolean(next.closeTabsAfterCollect);
  return next;
}

function normalizeClientBinding(input) {
  const raw = input && typeof input === "object" ? input : {};
  return {
    client_slug: String(raw.client_slug || "").trim(),
    client_name: String(raw.client_name || "").trim(),
    extension_instance_id: String(raw.extension_instance_id || "").trim(),
    extension_display_name: String(raw.extension_display_name || raw.client_name || "").trim(),
    bridge_base_url: raw.bridge_base_url ? trimSlash(String(raw.bridge_base_url)) : ""
  };
}

async function getClientBinding() {
  if (clientBindingCache) return clientBindingCache;
  try {
    const response = await fetch(chrome.runtime.getURL("client_binding.json"), { cache: "no-store" });
    if (response.ok) {
      clientBindingCache = normalizeClientBinding(await response.json());
      return clientBindingCache;
    }
  } catch (error) {
    // Falls through to the empty binding below -- this is also where a 404 (no file at all,
    // request never throws) lands, since it fails the `response.ok` check above. Either way,
    // pollBridge()'s NO_CLIENT_BINDING_STATUS guard is what actually acts on an empty
    // client_slug; this function just reports what it found.
  }
  clientBindingCache = normalizeClientBinding({});
  return clientBindingCache;
}

function collectorHeaders(binding, extra) {
  const headers = {
    "X-Collector-Extension": "media-agency-local-collector",
    "X-Collector-Extension-Version": EXTENSION_BUILD,
    ...(extra || {})
  };
  if (binding && binding.client_slug) headers["X-Collector-Client-Slug"] = binding.client_slug;
  if (binding && binding.extension_instance_id) headers["X-Collector-Extension-Instance"] = binding.extension_instance_id;
  if (binding && binding.extension_display_name) headers["X-Collector-Extension-Name"] = binding.extension_display_name;
  return headers;
}

function jobMatchesBinding(job, binding) {
  if (!job || !binding) return true;
  const jobClient = String(job.client_slug || "").trim();
  if (jobClient && binding.client_slug && jobClient !== binding.client_slug) return false;
  if (jobClient && !binding.client_slug) return false;
  const jobExtension = String(job.extension_instance_id || "").trim();
  if (jobExtension && binding.extension_instance_id && jobExtension !== binding.extension_instance_id) return false;
  if (jobExtension && !binding.extension_instance_id) return false;
  const allowed = Array.isArray(job.allowed_extension_instance_ids)
    ? job.allowed_extension_instance_ids.map((item) => String(item || "").trim()).filter(Boolean)
    : [];
  if (allowed.length > 0) {
    return Boolean(binding.extension_instance_id && allowed.includes(binding.extension_instance_id));
  }
  return true;
}

async function getSettings() {
  const data = await chrome.storage.local.get(SETTINGS_KEY);
  const binding = await getClientBinding();
  const settings = normalizeSettings(data[SETTINGS_KEY] || DEFAULT_SETTINGS);
  if (binding.bridge_base_url && (!data[SETTINGS_KEY] || !data[SETTINGS_KEY].bridgeBaseUrl)) {
    // client_binding.json is packaged by prepare_client_extension.sh and never hand-edited, but
    // it is still a file on disk: it gets the same loopback check as anything typed in the popup.
    settings.bridgeBaseUrl = safeBridgeUrl(binding.bridge_base_url, settings.bridgeBaseUrl);
  }
  return settings;
}

async function getState() {
  const data = await chrome.storage.local.get(STATE_KEY);
  return data[STATE_KEY] || { status: "idle", message: "Collector idle." };
}

async function getAudit() {
  const data = await chrome.storage.local.get(AUDIT_KEY);
  return data[AUDIT_KEY] || null;
}

// Manual single-scroll capture for the audit panel. The operator opens a page,
// clicks Capture, scrolls, clicks Capture again -- each call injects the
// capture modules into the active tab, serializes the current DOM (feed vs
// website routed by platform), and merges with the text accumulated so far for
// the same URL. This mirrors what the automated collector does per scroll step.
async function manualCapture() {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  const tab = tabs && tabs[0];
  if (!tab || !tab.id) return { ok: false, error: "No active tab." };

  const tabUrl = tab.url || "";
  if (!/^https?:\/\//i.test(tabUrl)) {
    return { ok: false, error: "Active tab is not an http(s) page." };
  }

  try {
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: CAPTURE_FILES });
  } catch (error) {
    return { ok: false, error: "Inject failed: " + (error && error.message ? error.message : error) };
  }

  const audit = await getAudit();
  const samePage = audit && audit.url === tabUrl;
  const prevText = samePage ? (audit.text || "") : "";

  let out;
  try {
    const [res] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: (prev) => window.__collectorCapture(prev, {}),
      args: [prevText]
    });
    out = res && res.result ? res.result : null;
  } catch (error) {
    return { ok: false, error: "Capture failed: " + (error && error.message ? error.message : error) };
  }

  if (!out) return { ok: false, error: "No capture result." };
  if (out.error) return { ok: false, error: "Capture error: " + out.error };

  const prevCount = samePage ? (audit.count || 0) : 0;
  const prevCaptures = samePage ? (audit.captures || []) : [];
  const nextAudit = {
    url: tabUrl,
    title: out.title || tab.title || "",
    platform: out.platform,
    branch: out.branch,
    engine: out.engine || "",
    count: prevCount + 1,
    text: out.merged,                 // absolute-URL accumulator (next prevText)
    displayText: out.mergedDisplay || out.merged, // shortened, LLM-facing / audit view
    lastCaptureText: out.captureText,
    captures: prevCaptures.concat([{
      n: prevCount + 1,
      engine: out.engine || "",
      scrollY: out.scrollY,
      captureChars: out.captureChars,
      captureUrls: out.captureUrls,
      mergedChars: out.mergedChars,
      mergedUrls: out.mergedUrls,
      droppedUnits: out.droppedUnits || 0,
      keptUnits: out.keptUnits || 0,
      capturedAt: new Date().toISOString()
    }]),
    updatedAt: new Date().toISOString()
  };
  await chrome.storage.local.set({ [AUDIT_KEY]: nextAudit });
  return { ok: true, audit: nextAudit };
}

async function testScrollActiveTab(message) {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  const tab = tabs && tabs[0];
  if (!tab || !tab.id) return { ok: false, error: "No active tab." };
  const tabUrl = tab.url || "";
  if (!/^https?:\/\//i.test(tabUrl)) {
    return { ok: false, error: "Active tab is not an http(s) page." };
  }
  const steps = clampNumber(message.steps, 1, 20, 8);
  const delayMs = clampNumber(message.delay_ms, 250, 5000, 900);
  try {
    const [result] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: runVisibleScrollTest,
      args: [{ steps, delayMs }]
    });
    const payload = result && result.result ? result.result : {};
    return {
      ok: true,
      url: tabUrl,
      steps_requested: steps,
      steps_used: payload.stepsUsed || 0,
      debug: payload.debug || []
    };
  } catch (error) {
    return { ok: false, error: String(error && error.message ? error.message : error) };
  }
}

async function runVisibleScrollTest(opts) {
  const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, Number(v) || 0));
  const steps = clamp(opts && opts.steps, 1, 20);
  const delayMs = clamp(opts && opts.delayMs, 250, 5000);
  const randomBetween = (lo, hi) => lo + Math.random() * (hi - lo);
  const debug = [];

  function elementLabel(el) {
    if (!el) return "unknown";
    if (el === document.scrollingElement || el === document.documentElement || el === document.body) return "document";
    const role = el.getAttribute && el.getAttribute("role");
    const id = el.id ? `#${el.id}` : "";
    const cls = el.className && typeof el.className === "string" ? `.${el.className.trim().split(/\s+/).slice(0, 2).join(".")}` : "";
    return `${String(el.tagName || "element").toLowerCase()}${id}${cls}${role ? `[role=${role}]` : ""}`;
  }

  function scrollTopOf(target) {
    if (!target || target.kind === "document") {
      const root = document.scrollingElement || document.documentElement || document.body;
      return Math.max(window.scrollY || 0, root ? root.scrollTop || 0 : 0, document.documentElement ? document.documentElement.scrollTop || 0 : 0, document.body ? document.body.scrollTop || 0 : 0);
    }
    return Number(target.el.scrollTop || 0);
  }

  function scrollMaxOf(target) {
    if (!target || target.kind === "document") {
      const root = document.scrollingElement || document.documentElement || document.body;
      const scrollHeight = Math.max(root ? root.scrollHeight || 0 : 0, document.documentElement ? document.documentElement.scrollHeight || 0 : 0, document.body ? document.body.scrollHeight || 0 : 0);
      const clientHeight = window.innerHeight || (root ? root.clientHeight || 0 : 0);
      return Math.max(0, scrollHeight - clientHeight);
    }
    return Math.max(0, Number(target.el.scrollHeight || 0) - Number(target.el.clientHeight || 0));
  }

  function scrollCandidates() {
    const candidates = [];
    const root = document.scrollingElement || document.documentElement || document.body;
    if (root) {
      candidates.push({
        kind: "document",
        el: root,
        label: "document",
        viewport: window.innerHeight || root.clientHeight || 800,
        score: scrollMaxOf({ kind: "document", el: root }) + 1000000
      });
    }
    const selector = [
      "main",
      "section",
      "div",
      "[role='main']",
      "[role='feed']",
      "[role='list']",
      "[data-pagelet]"
    ].join(",");
    for (const el of Array.from(document.querySelectorAll(selector))) {
      if (!el || el === root || el === document.body || el === document.documentElement) continue;
      const scrollable = Number(el.scrollHeight || 0) - Number(el.clientHeight || 0);
      if (scrollable < 300) continue;
      const rect = el.getBoundingClientRect();
      if (!rect || rect.width < 220 || rect.height < 240) continue;
      const style = window.getComputedStyle ? window.getComputedStyle(el) : null;
      if (style && (style.visibility === "hidden" || style.display === "none")) continue;
      const viewportOverlap = Math.max(0, Math.min(rect.bottom, window.innerHeight || rect.bottom) - Math.max(rect.top, 0));
      const centerBonus = rect.top < (window.innerHeight || 800) * 0.75 && rect.bottom > (window.innerHeight || 800) * 0.25 ? 50000 : 0;
      candidates.push({
        kind: "element",
        el,
        label: elementLabel(el),
        viewport: Math.max(300, Math.min(rect.height, window.innerHeight || rect.height || 800)),
        score: scrollable + viewportOverlap * 10 + centerBonus
      });
    }
    return candidates
      .filter((target) => scrollMaxOf(target) - scrollTopOf(target) > 10)
      .sort((a, b) => b.score - a.score)
      .slice(0, 8);
  }

  function setScrollTopOf(target, top) {
    const nextTop = Math.max(0, Math.min(scrollMaxOf(target), Number(top) || 0));
    if (!target || target.kind === "document") {
      const root = document.scrollingElement || document.documentElement || document.body;
      if (root) root.scrollTop = nextTop;
      window.scrollTo(0, nextTop);
      return;
    }
    target.el.scrollTop = nextTop;
  }

  function humanDurationMs(baseMs) {
    return Math.round(clamp(Number(baseMs) * randomBetween(0.72, 1.38), 420, 1450));
  }

  function humanPauseMs(baseMs) {
    return Math.round(clamp(Number(baseMs) * randomBetween(0.72, 1.34), 250, 5000));
  }

  function humanScrollDistance(viewport) {
    const base = Math.max(680, Math.floor((viewport || window.innerHeight || 800) * 0.95));
    return Math.round(base * randomBetween(0.84, 1.12));
  }

  function dispatchScrollHints(target, distance) {
    const node = target && target.kind === "element" ? target.el : document.scrollingElement || document.documentElement || document.body;
    try {
      const wheel = new WheelEvent("wheel", {
        bubbles: true,
        cancelable: true,
        deltaY: Math.max(120, Number(distance) || 0),
        view: window
      });
      (node || document).dispatchEvent(wheel);
    } catch (error) {
      // Synthetic input hints are best-effort only.
    }
    try {
      (target && target.kind === "element" ? target.el : window).dispatchEvent(new Event("scroll", { bubbles: true }));
    } catch (error) {
      // Ignore pages that block synthetic events.
    }
  }

  async function moveScrollTarget(target, toTop, durationMs) {
    const from = scrollTopOf(target);
    const max = scrollMaxOf(target);
    const to = Math.max(0, Math.min(max, Number(toTop) || 0));
    if (Math.abs(to - from) < 1) return;
    const duration = Math.max(260, Number(durationMs) || 850);
    if (Math.abs(to - from) > 240) {
      setScrollTopOf(target, from + (to - from) * 0.58);
      dispatchScrollHints(target, to - from);
      await wait(Math.round(clamp(duration / 7, 60, 180)));
    }
    setScrollTopOf(target, to);
    dispatchScrollHints(target, to - from);
  }

  async function tryScrollTarget(target, distance) {
    const before = scrollTopOf(target);
    const nextTop = Math.min(scrollMaxOf(target), before + distance);
    const durationMs = humanDurationMs(850);
    await moveScrollTarget(target, nextTop, durationMs);
    await wait(Math.round(randomBetween(60, 170)));
    const after = scrollTopOf(target);
    return {
      target: target.label,
      before: Math.round(before),
      after: Math.round(after),
      delta: Math.round(after - before),
      requested_distance: Math.round(distance),
      duration_ms: durationMs,
      max: Math.round(scrollMaxOf(target))
    };
  }

  async function performScroll() {
    const targets = scrollCandidates();
    let best = null;
    for (const target of targets) {
      const distance = humanScrollDistance(target.viewport || window.innerHeight || 800);
      const report = await tryScrollTarget(target, distance);
      if (!best || Math.abs(report.delta) > Math.abs(best.delta || 0)) best = report;
      if (Math.abs(report.delta) >= 120) return report;
    }
    return best || { target: "none", before: 0, after: 0, delta: 0, max: 0 };
  }

  for (let i = 0; i < steps; i += 1) {
    const report = await performScroll();
    report.pause_ms = humanPauseMs(delayMs);
    debug.push(report);
    await wait(report.pause_ms);
  }
  return { stepsUsed: debug.length, debug };
}

async function setState(patch) {
  const current = await getState();
  await chrome.storage.local.set({
    [STATE_KEY]: {
      ...current,
      ...patch,
      updatedAt: patch.updatedAt || new Date().toISOString()
    }
  });
}

async function getCompletedRuns() {
  const data = await chrome.storage.local.get(COMPLETED_RUNS_KEY);
  return data[COMPLETED_RUNS_KEY] || {};
}

async function acquireRunLock(runId, job, bridgeStatus, reason) {
  const now = Date.now();
  if (inMemoryActiveRuns.size > 0) {
    const hasSameRun = inMemoryActiveRuns.has(runId);
    if (!hasSameRun && shouldReplaceStaleRunLock(runId, job, bridgeStatus)) {
      inMemoryActiveRuns.clear();
    } else {
      return { acquired: false, reason: "in_memory_active_run" };
    }
  }

  const lockData = await chrome.storage.local.get(ACTIVE_RUN_KEY);
  if (inMemoryActiveRuns.size > 0) {
    const hasSameRun = inMemoryActiveRuns.has(runId);
    if (!hasSameRun && shouldReplaceStaleRunLock(runId, job, bridgeStatus)) {
      inMemoryActiveRuns.clear();
    } else {
      return { acquired: false, reason: "in_memory_active_run" };
    }
  }

  let currentLock = lockData[ACTIVE_RUN_KEY] || null;
  const lockExpiresAt = currentLock && Date.parse(currentLock.expiresAt || "");
  if (currentLock && Number.isFinite(lockExpiresAt) && lockExpiresAt > now) {
    if (currentLock.runId !== runId && shouldReplaceStaleRunLock(runId, job, bridgeStatus)) {
      await chrome.storage.local.remove(ACTIVE_RUN_KEY);
      currentLock = null;
    }
  }
  if (currentLock && Number.isFinite(lockExpiresAt) && lockExpiresAt > now) {
    return { acquired: false, reason: "storage_active_run", lock: currentLock };
  }

  const owner = `${runId}-${now}-${Math.random().toString(36).slice(2)}`;
  const lock = {
    runId,
    owner,
    reason,
    bridgeRunId: String(bridgeStatus?.run_id || ""),
    acquiredAt: new Date(now).toISOString(),
    expiresAt: new Date(now + activeRunLockMs(job)).toISOString()
  };

  inMemoryActiveRuns.add(runId);
  await chrome.storage.local.set({ [ACTIVE_RUN_KEY]: lock });

  const verifyData = await chrome.storage.local.get(ACTIVE_RUN_KEY);
  const verified = verifyData[ACTIVE_RUN_KEY] || {};
  if (verified.owner !== owner) {
    inMemoryActiveRuns.delete(runId);
    return { acquired: false, reason: "storage_lock_lost", lock: verified };
  }

  return { acquired: true, owner, lock };
}

function shouldReplaceStaleRunLock(runId, job, bridgeStatus) {
  if (!runId) return false;
  const bridgeRunId = String(bridgeStatus?.run_id || "");
  if (bridgeRunId && bridgeRunId !== runId) return false;
  return Boolean(job?.force || job?.run_now || job?.active_tab_diagnostic || job?.activate_tab_for_test);
}

async function releaseRunLock(runId, owner) {
  inMemoryActiveRuns.delete(runId);
  const lockData = await chrome.storage.local.get(ACTIVE_RUN_KEY);
  const currentLock = lockData[ACTIVE_RUN_KEY] || null;
  if (currentLock && currentLock.runId === runId && currentLock.owner === owner) {
    await chrome.storage.local.remove(ACTIVE_RUN_KEY);
  }
}

async function resetRunLockAfterBuildChange(reason) {
  const data = await chrome.storage.local.get(BUILD_STATE_KEY);
  if (data[BUILD_STATE_KEY] === EXTENSION_BUILD) return false;
  inMemoryActiveRuns.clear();
  await chrome.storage.local.remove(ACTIVE_RUN_KEY);
  await chrome.storage.local.set({ [BUILD_STATE_KEY]: EXTENSION_BUILD });
  await setState({
    status: "updated",
    message: `Collector extension updated to ${EXTENSION_BUILD}; stale run lock cleared.`,
    reason,
    extensionBuild: EXTENSION_BUILD,
    updatedAt: new Date().toISOString()
  });
  return true;
}

function trimCompletedRuns(runs) {
  const entries = Object.entries(runs).slice(-100);
  return Object.fromEntries(entries);
}

function activeRunLockMs(job) {
  const pacing = job?.pacing || {};
  const sources = normalizeSources(job?.sources || []);
  const maxSources = Math.min(
    Number(pacing.max_sources || DEFAULT_SETTINGS.maxSourcesPerRun || 20),
    sources.length || Number(pacing.max_sources || DEFAULT_SETTINGS.maxSourcesPerRun || 20)
  );
  const scrollCap = isDiscoveryCollection(job) ? DISCOVERY_SCROLL_CAP : NORMAL_SCROLL_CAP;
  const scrollSteps = clampNumber(pacing.scroll_steps, 0, scrollCap, DEFAULT_SETTINGS.scrollSteps);
  const maxDelaySeconds = clampNumber(pacing.max_delay_seconds, 5, 30, DEFAULT_SETTINGS.maxDelaySeconds);
  const estimatedMs = maxSources * ((scrollSteps + 2) * maxDelaySeconds * 1000 + CAPABILITY_TIMEOUT_MS);
  const fallbackMs = ACTIVE_RUN_LOCK_MINUTES * 60 * 1000;
  return Math.max(30 * 60 * 1000, Math.min(fallbackMs, estimatedMs || fallbackMs));
}

function textLooksLikeDiscovery(value) {
  return /\b(discover|discovery|joined|joins|member|membership|following|subscriptions?|recommendation|source[_ -]?discovery|group[_ -]?discovery)\b/i.test(String(value || ""));
}

function urlLooksLikeDiscovery(url) {
  const value = String(url || "").toLowerCase();
  return (
    /facebook\.com\/groups\/joins\b/.test(value) ||
    /facebook\.com\/groups\/discover\b/.test(value) ||
    /reddit\.com\/subreddits\/mine\b/.test(value) ||
    /linkedin\.com\/mynetwork\b/.test(value) ||
    /youtube\.com\/feed\/subscriptions\b/.test(value)
  );
}

function sourceLooksLikeDiscovery(source) {
  if (!source || typeof source !== "object") return false;
  return (
    urlLooksLikeDiscovery(source.url) ||
    textLooksLikeDiscovery(source.name) ||
    textLooksLikeDiscovery(source.source_type) ||
    textLooksLikeDiscovery(source.type) ||
    textLooksLikeDiscovery(source.purpose) ||
    textLooksLikeDiscovery(source.scan_mode) ||
    textLooksLikeDiscovery(source.collection_mode)
  );
}

function isDiscoveryCollection(job, source) {
  if (sourceLooksLikeDiscovery(source)) return true;
  if (!job || typeof job !== "object") return false;
  if (
    textLooksLikeDiscovery(job.job_type) ||
    textLooksLikeDiscovery(job.mode) ||
    textLooksLikeDiscovery(job.purpose) ||
    textLooksLikeDiscovery(job.collection_mode) ||
    textLooksLikeDiscovery(job.scan_mode)
  ) {
    return true;
  }
  return normalizeSources(job.sources || []).some(sourceLooksLikeDiscovery);
}

function maxScrollStepsForCollection(job, source) {
  return isDiscoveryCollection(job, source) ? DISCOVERY_SCROLL_CAP : NORMAL_SCROLL_CAP;
}

// Capabilities whose data survives a tab that is never shown. MEASURED, not reasoned: hiding a tab
// is a convenience and data is not, so a capability is on this list only after a run proved it
// loses nothing — everything else activates, including anything not listed.
//
// What separates them is whether the page has to RENDER for the data to exist. Facebook defers feed
// work on document.visibilityState, so a hidden tab never fires the timeline query: measured on two
// profiles, fb.profile.enrich came back with posts_available:false and posts_seen:0 while its About
// half was perfect. Anything reading a feed — timeline, newsfeed, group posts, reels, videos — has
// the same dependency. The About section, a profile header, a hovercard fetched by entity_id and
// Zillow's __NEXT_DATA__ are all present without being looked at.
// Declared per capability (hideable: true) in core/platform_registry.js, where the measurement
// behind each entry is recorded next to it.
const HIDEABLE_CAPABILITIES = SoloPlatforms.hideable();

// attachCanonical: ask the capability's platform module (core/platform_registry.js) for its
// normalizer, run it over the capability result, validate the canonical block against
// core/schema.js and attach it as records.canonical. Validation only LOGS — a field the schema
// dislikes is a bug to fix in the module's normalizer, not a reason to drop data the operator
// paid a page load for. Problems are also recorded on the record (records.canonical_validation)
// so the bridge and the healthcheck can see them without a console.
function attachCanonical(records, capId) {
  try {
    const P = self.SoloPlatforms, S = self.SoloSchema;
    if (!P || !S || !records || typeof records !== "object") return;
    const entry = P.entryFor(capId, "normalize");
    const normalize = entry && typeof self[entry] === "function" ? self[entry] : null;
    if (!normalize) return;
    const canonical = normalize(capId, records, { captured_at: S.nowIso() });
    if (!canonical) return;
    const verdict = S.validateCanonical(canonical);
    records.canonical = canonical;
    if (!verdict.ok || verdict.warnings.length) {
      records.canonical_validation = { ok: verdict.ok, errors: verdict.errors.slice(0, 20), warnings: verdict.warnings.slice(0, 20) };
      if (!verdict.ok) console.warn("[canonical] " + capId + ": " + verdict.errors.length + " problem(s)", verdict.errors.slice(0, 5));
    }
  } catch (e) {
    console.warn("[canonical] normalize failed for " + capId + ": " + String(e && e.message || e));
  }
}

function capabilityNeedsActiveTab(source) {
  const cap = source && source.capability ? String(source.capability) : "";
  if (!cap) return false;                 // no capability: generic extraction, nothing to render
  return !HIDEABLE_CAPABILITIES.has(cap);
}

function shouldActivateCollectionTab(job, source) {
  const pacing = job && typeof job === "object" ? job.pacing || {} : {};
  // The capability's need OUTRANKS the convenience flag. Honouring background_tab on a capability
  // that reads a feed would return a record that looks complete and has no posts in it — the
  // operator asked not to be interrupted, not to be given emptier data, and only one of those two
  // failures is visible to them.
  if (capabilityNeedsActiveTab(source)) return true;
  if (
    explicitFalse(job?.activate_tab) ||
    explicitFalse(job?.focus_collection_tab) ||
    explicitFalse(pacing?.activate_tab) ||
    explicitFalse(pacing?.focus_collection_tab) ||
    explicitFalse(source?.activate_tab) ||
    explicitFalse(source?.focus_collection_tab) ||
    explicitTrue(job?.background_tab) ||
    explicitTrue(job?.allow_background_tab) ||
    explicitTrue(pacing?.background_tab) ||
    explicitTrue(pacing?.allow_background_tab) ||
    explicitTrue(source?.background_tab) ||
    explicitTrue(source?.allow_background_tab)
  ) {
    return false;
  }
  return true;
}

function explicitTrue(value) {
  if (value === true) return true;
  const normalized = String(value || "").trim().toLowerCase();
  return normalized === "true" || normalized === "1" || normalized === "yes" || normalized === "on";
}

function explicitFalse(value) {
  if (value === false) return true;
  const normalized = String(value || "").trim().toLowerCase();
  return normalized === "false" || normalized === "0" || normalized === "no" || normalized === "off";
}

function canonicalSourceKey(url) {
  try {
    const parsed = new URL(String(url || "").trim());
    parsed.hash = "";
    for (const param of [
      "__cft__",
      "__tn__",
      "mibextid",
      "ref",
      "refsrc",
      "tracking",
      "utm_campaign",
      "utm_content",
      "utm_medium",
      "utm_source",
      "utm_term"
    ]) {
      parsed.searchParams.delete(param);
    }
    return parsed.toString().replace(/\/+$/, "").toLowerCase();
  } catch (error) {
    return String(url || "").trim().replace(/\/+$/, "").toLowerCase();
  }
}

function trimSlash(value) {
  return String(value || "").replace(/\/+$/, "");
}

function randomDelayMs(settings, pacing) {
  const min = Number(pacing.min_delay_seconds || settings.minDelaySeconds || 5);
  const max = Math.max(min, Number(pacing.max_delay_seconds || settings.maxDelaySeconds || 5));
  return Math.floor((min + Math.random() * (max - min)) * 1000);
}

function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function clampNumber(value, min, max, fallback) {
  const n = Number(value);
  if (!Number.isFinite(n)) return fallback;
  return Math.max(min, Math.min(max, n));
}

function inferPlatform(url) {
  const lower = String(url || "").toLowerCase();
  if (lower.includes("facebook.com")) return "facebook";
  if (lower.includes("linkedin.com")) return "linkedin";
  if (lower.includes("instagram.com")) return "instagram";
  if (lower.includes("tiktok.com")) return "tiktok";
  if (lower.includes("reddit.com")) return "reddit";
  if (lower.includes("youtube.com") || lower.includes("youtu.be")) return "youtube";
  if (lower.includes("x.com") || lower.includes("twitter.com")) return "x";
  return "web";
}

function isCompetitorSource(source) {
  const purpose = String(source.purpose || source.category || source.kind || "").toLowerCase();
  return purpose.includes("competitor") || source.is_competitor === true;
}

function safeSlug(value) {
  return String(value || "item").toLowerCase().replace(/[^a-z0-9._-]+/g, "_").replace(/^_+|_+$/g, "").slice(0, 80) || "item";
}

function escapeHTML(value) {
  return String(value || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}
